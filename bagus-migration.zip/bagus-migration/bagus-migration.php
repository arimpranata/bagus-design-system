<?php
/**
 * Plugin Name:       Bagus Migration
 * Description:       One-time move from Elementor to the Bagus Theme. Tools → Bagus: Convert pages rebuilds every Elementor page with blocks in the Bagus layout, and while Elementor is still active its CSS, JS, templates and popups are kept off the front end. After converting: deactivate Elementor and its add-ons, then deactivate and delete this plugin.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Bagus
 * License:           GPL-2.0-or-later
 * Text Domain:       bagus
 *
 * @package Bagus_Migration
 */

defined( 'ABSPATH' ) || exit;

/*
 * Plugins load before the theme. Bagus Theme 1.3.8 and older still ship the
 * same converter, so wait until the theme has loaded and only add the tools
 * when the theme does not already provide them (otherwise PHP would stop
 * with "Cannot redeclare").
 */
add_action(
	'after_setup_theme',
	function () {
		if ( function_exists( 'bagus_convert_elementor_page' ) || function_exists( 'bagus_takeover_builder' ) ) {
			return; // An older Bagus Theme already provides Tools → Bagus: Convert pages.
		}
		require __DIR__ . '/inc/takeover.php';
		require __DIR__ . '/inc/converter.php';
	},
	0
);
