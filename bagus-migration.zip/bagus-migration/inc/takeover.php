<?php
/**
 * Clean break from the old page builder.
 *
 * The theme never loads, extends or restyles code from the previous theme or
 * Elementor. If Elementor / its add-ons are still active while migrating, their
 * front-end CSS & JS are kept off the page while this plugin is active
 * so they cannot fight the new design or slow it down.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/** Handle prefixes that belong to page builders / their add-ons. */
function bagus_builder_handle_prefixes() {
	return apply_filters(
		'bagus_builder_handle_prefixes',
		array( 'elementor', 'e-', 'swiper', 'happy', 'ha-', 'qi-addons', 'she-header', 'ucaddon', 'unlimited-elements', 'font-awesome', 'hello-elementor', 'bagus-design-system', 'eael', 'jet-' )
	);
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( ! bagus_takeover_builder() ) {
			return;
		}
		if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$prefixes = bagus_builder_handle_prefixes();
		foreach ( array( wp_styles(), wp_scripts() ) as $deps ) {
			foreach ( (array) $deps->queue as $handle ) {
				foreach ( $prefixes as $p ) {
					if ( 0 === strpos( $handle, $p ) ) {
						$deps instanceof WP_Styles ? wp_dequeue_style( $handle ) : wp_dequeue_script( $handle );
						break;
					}
				}
			}
		}
	},
	9999
);

/**
 * When the builder plugin is deactivated, its pages fall back to the HTML saved
 * in post_content. Strip the builder's wrapper attributes so the theme's
 * typography (.prose) styles that content cleanly.
 */
add_filter(
	'the_content',
	function ( $html ) {
		if ( false === strpos( $html, 'elementor' ) || did_action( 'elementor/loaded' ) ) {
			return $html;
		}
		$html = preg_replace( '/\s(?:data-(?:id|element_type|e-type|settings|widget_type|elementor-[a-z-]+))="[^"]*"/i', '', $html );
		$html = preg_replace( '/\sclass="[^"]*\belementor[^"]*"/i', '', $html );
		return $html;
	},
	20
);

/* ---------------------------------------------------------------------------
 * Take over pages while Elementor is still active (1.1.1)
 * Elementor's own page templates ("Elementor Full Width" / "Canvas"), its
 * builder content, late widget styles and popups would otherwise replace the
 * theme's layout. Switch off with the bagus_migration_takeover filter.
 * ------------------------------------------------------------------------ */

/** Is the theme taking over builder pages? */
function bagus_takeover_builder() {
	if ( is_admin() || isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return false;
	}
	return (bool) apply_filters( 'bagus_migration_takeover', true );
}

/** Use the theme's templates instead of Elementor's page templates. */
add_filter(
	'template_include',
	function ( $template ) {
		if ( ! bagus_takeover_builder() ) {
			return $template;
		}
		$is_builder_tpl = false !== stripos( (string) $template, 'elementor' ) || false !== stripos( (string) $template, 'header-footer' ) || false !== stripos( (string) $template, 'canvas' );
		if ( is_singular() ) {
			$slug = get_page_template_slug( get_queried_object_id() );
			if ( $slug && ( 0 === strpos( $slug, 'elementor_' ) || false !== strpos( $slug, 'elementor' ) ) ) {
				$is_builder_tpl = true;
			}
		}
		if ( ! $is_builder_tpl ) {
			return $template;
		}
		$try = is_front_page() ? array( 'front-page.php' ) : ( is_page() ? array( 'page.php', 'index.php' ) : array( 'single.php', 'index.php' ) );
		$own = locate_template( $try );
		return $own ? $own : $template;
	},
	PHP_INT_MAX
);

/** Keep Elementor from swapping the post content for its builder output. */
add_action(
	'wp',
	function () {
		if ( ! bagus_takeover_builder() || ! class_exists( '\Elementor\Plugin' ) ) {
			return;
		}
		$el = \Elementor\Plugin::$instance;
		if ( isset( $el->frontend ) ) {
			remove_filter( 'the_content', array( $el->frontend, 'apply_builder_in_content' ), 9 );
		}
		// Elementor Pro theme-builder locations (header, footer, popups) are not printed.
		add_filter( 'elementor/theme/get_location_templates/template_id', '__return_false', 999 );
		add_filter( 'elementor_pro/theme_builder/get_location_templates/condition_sub_id', '__return_false', 999 );
	},
	1
);

/**
 * Folder names of Elementor & add-ons when a security plugin (WP Ghost) renames /wp-content/plugins/<name>/
 * to /core/modules/<hash>/ (measured on the five Bagus sites). Filterable.
 */
function bagus_builder_hashed_dirs() {
	return apply_filters( 'bagus_builder_hashed_dirs', array( 'f65f29574d', 'bf03816ef6', 'd275f7e416', '9392f6344c', '7b28f06fb0', '3e857f275e', 'bde8af3195' ) );
}

/** Builder assets enqueued late (during rendering / in the footer) are stripped too. */
function bagus_strip_builder_queue() {
	if ( ! bagus_takeover_builder() ) {
		return;
	}
	$prefixes = bagus_builder_handle_prefixes();
	foreach ( array( wp_styles(), wp_scripts() ) as $deps ) {
		foreach ( (array) $deps->queue as $handle ) {
			$src = isset( $deps->registered[ $handle ] ) ? (string) $deps->registered[ $handle ]->src : '';
			$hit = false;
			foreach ( $prefixes as $p ) {
				if ( 0 === strpos( $handle, $p ) ) { $hit = true; break; }
			}
			// Obfuscated plugin paths (e.g. /core/modules/<hash>/) still carry the plugin's folder files.
			if ( ! $hit && $src && preg_match( '#/(elementor|elementor-pro|pro-elements|happy-elementor-addons|qi-addons-for-elementor|unlimited-elements-for-elementor|powerpack-elements)/|/core/modules/(' . implode( '|', bagus_builder_hashed_dirs() ) . ')/#', $src ) ) {
				$hit = true;
			}
			if ( $hit ) {
				$deps instanceof WP_Styles ? wp_dequeue_style( $handle ) : wp_dequeue_script( $handle );
			}
		}
	}
}
add_action( 'wp_print_styles', 'bagus_strip_builder_queue', 1 );
add_action( 'wp_print_scripts', 'bagus_strip_builder_queue', 1 );
add_action( 'wp_print_footer_scripts', 'bagus_strip_builder_queue', 1 );

/** Safety net: any builder popup / location markup that still gets printed stays hidden. */
add_action(
	'wp_head',
	function () {
		if ( bagus_takeover_builder() ) {
			echo "<style id=\"bagus-builder-guard\">.elementor-location-popup,[data-elementor-type=\"popup\"],.elementor-popup-modal,[data-elementor-type=\"header\"],[data-elementor-type=\"footer\"]{display:none!important}</style>\n";
		}
	},
	99
);
