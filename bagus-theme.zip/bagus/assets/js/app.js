/**
 * Bagus theme entry (ES module, no build step, no dependencies).
 */

import { initReveal, initMagnetic } from './lib/motion.js';
import { initCarousels } from './lib/carousel.js';
import { initDrawer, initSheets } from './lib/overlays.js';
import { initLightbox } from './lib/lightbox.js';
import {
	initScrollState,
	initMenus,
	initSlideshows,
	initScrollSpy,
	initReadMore,
	initBookingForms,
	initLeadForms,
	initWelcome,
	initContentGalleries,
	initHeroVideo,
	initExpandPanels,
} from './lib/ui.js';

const run = (fn) => {
	try {
		fn();
	} catch (err) {
		console.error('[bagus]', err); // one failing feature never blocks the rest
	}
};

[
	initReveal,
	initScrollState,
	initMenus,
	initDrawer,
	initSheets,
	initContentGalleries,
	initCarousels,
	initLightbox,
	initSlideshows,
	initScrollSpy,
	initReadMore,
	initBookingForms,
	initLeadForms,
	initMagnetic,
	initWelcome,
	initHeroVideo,
	initExpandPanels,
].forEach(run);

window.bagusReady = true;
