<?php
/**
 * Header: skip link, sticky header, desktop nav, swipeable drawer.
 *
 * @package Bagus
 */

$contact = bagus_data( 'contact' );
$reserve = $contact['reserve_url'] ?? '';
?><!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'bagus' ); ?></a>
<div class="scroll-progress" aria-hidden="true"></div>

<header class="site-header" data-header>
	<div class="site-header__inner wrap">
		<?php bagus_logo( 'header' ); ?>

		<div class="site-header__actions">
			<button type="button" class="burger" id="drawer-open" aria-expanded="false" aria-controls="drawer">
				<span class="burger__label"><?php esc_html_e( 'Website Menu', 'bagus' ); ?></span>
				<span class="burger__lines" aria-hidden="true"><i></i><i></i><i></i></span>
			</button>
			<?php if ( $reserve ) : ?>
				<a class="btn btn--primary btn--sm site-header__reserve"<?php echo bagus_link_attrs( $reserve ); // phpcs:ignore ?>><span><?php esc_html_e( 'Reserve Now', 'bagus' ); ?></span></a>
			<?php endif; ?>
		</div>
	</div>
</header>

<dialog class="drawer" id="drawer" aria-labelledby="drawer-title">
	<div class="drawer__scroller">
		<div class="drawer__spacer" aria-hidden="true"></div>
		<nav class="drawer__sheet" aria-label="<?php esc_attr_e( 'Website Menu', 'bagus' ); ?>">
			<div class="drawer__head">
				<h2 class="drawer__title" id="drawer-title"><?php esc_html_e( 'Website Menu', 'bagus' ); ?></h2>
				<button type="button" class="icon-btn" id="drawer-close" aria-label="<?php esc_attr_e( 'Close menu', 'bagus' ); ?>" autofocus><?php echo bagus_icon( 'close' ); // phpcs:ignore ?></button>
			</div>
			<?php bagus_render_menu( 'drawer' ); ?>
			<div class="drawer__foot">
				<?php if ( $reserve ) : ?>
					<?php echo bagus_button( __( 'Reserve Now', 'bagus' ), $reserve, 'accent', 'calendar', array( 'class' => 'btn--block' ) ); // phpcs:ignore ?>
				<?php endif; ?>
				<ul class="icon-row">
					<?php foreach ( (array) ( bagus_data( 'hero' )['actions'] ?? array() ) as $a ) : ?>
						<li><a class="icon-row__link"<?php echo bagus_link_attrs( $a['url'] ); // phpcs:ignore ?>><?php echo bagus_icon( $a['icon'] ); // phpcs:ignore ?><span><?php echo esc_html( $a['label'] ); ?></span></a></li>
					<?php endforeach; ?>
				</ul>
				<?php get_search_form(); ?>
			</div>
		</nav>
	</div>
</dialog>

<main id="main" class="site-main">
