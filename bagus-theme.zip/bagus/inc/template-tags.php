<?php
/**
 * Template helpers.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/**
 * Resolve an image (attachment ID or URL) to src/srcset/width/height.
 * URLs that belong to the media library are mapped back to their attachment
 * so WordPress can serve responsive srcset + modern formats.
 *
 * @param int|string $image ID or URL.
 * @param string     $size  Image size.
 * @return array{src:string,srcset:string,width:int,height:int,id:int}
 */
function bagus_image_attrs( $image, $size = 'large' ) {
	$out = array( 'src' => '', 'srcset' => '', 'width' => 0, 'height' => 0, 'id' => 0 );
	if ( ! $image ) {
		return $out;
	}

	$id = 0;
	if ( is_numeric( $image ) ) {
		$id = (int) $image;
	} else {
		static $map = null;
		$out['src'] = $image;
		if ( null === $map ) {
			$map = get_transient( 'bagus_img_map' );
			$map = is_array( $map ) ? $map : array();
		}
		if ( array_key_exists( $image, $map ) ) {
			$id = (int) $map[ $image ];
		} else {
			// One lookup per URL, persisted once at shutdown (avoids a DB write per image).
			$id            = (int) attachment_url_to_postid( $image );
			$map[ $image ] = $id;
			if ( ! has_action( 'shutdown', 'bagus_save_img_map' ) ) {
				add_action( 'shutdown', 'bagus_save_img_map' );
			}
			$GLOBALS['bagus_img_map'] = $map;
		}
	}

	if ( $id ) {
		$src = wp_get_attachment_image_src( $id, $size );
		if ( $src ) {
			$out['id']     = $id;
			$out['src']    = $src[0];
			$out['width']  = (int) $src[1];
			$out['height'] = (int) $src[2];
			$out['srcset'] = (string) wp_get_attachment_image_srcset( $id, $size );
		}
	}
	return $out;
}

/** Persist the URL → attachment map collected during the request. */
function bagus_save_img_map() {
	if ( isset( $GLOBALS['bagus_img_map'] ) ) {
		set_transient( 'bagus_img_map', $GLOBALS['bagus_img_map'], WEEK_IN_SECONDS );
	}
}

/**
 * Output a responsive <img>. Lazy by default; pass ['loading'=>'eager','fetchpriority'=>'high'] for the LCP image.
 *
 * @param int|string $image Image ID or URL.
 * @param string     $alt   Alt text.
 * @param array      $attrs Extra attributes (class, sizes, loading, fetchpriority, width, height).
 * @param string     $size  Image size.
 * @return string
 */
function bagus_img( $image, $alt = '', $attrs = array(), $size = 'large' ) {
	$img = bagus_image_attrs( $image, $size );
	if ( ! $img['src'] ) {
		return '';
	}
	if ( $img['id'] && '' === $alt ) {
		$alt = (string) get_post_meta( $img['id'], '_wp_attachment_image_alt', true );
	}
	$attrs = array_merge(
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
			'sizes'    => '(min-width: 1024px) 50vw, 100vw',
		),
		$attrs
	);
	if ( 'eager' === $attrs['loading'] ) {
		unset( $attrs['loading'] );
	}
	if ( $img['width'] && empty( $attrs['width'] ) ) {
		$attrs['width']  = $img['width'];
		$attrs['height'] = $img['height'];
	}
	if ( ! $img['srcset'] ) {
		unset( $attrs['sizes'] );
	}

	$html = '<img src="' . esc_url( $img['src'] ) . '" alt="' . esc_attr( $alt ) . '"';
	if ( $img['srcset'] ) {
		$html .= ' srcset="' . esc_attr( $img['srcset'] ) . '"';
	}
	foreach ( $attrs as $k => $v ) {
		if ( '' === $v || null === $v ) {
			continue;
		}
		$html .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
	}
	return $html . '>';
}

/**
 * Is a URL external to this site?
 *
 * @param string $url URL.
 * @return bool
 */
function bagus_is_external( $url ) {
	$host = wp_parse_url( $url, PHP_URL_HOST );
	if ( ! $host ) {
		return false;
	}
	$home = wp_parse_url( home_url(), PHP_URL_HOST );
	return strtolower( preg_replace( '/^www\./', '', $host ) ) !== strtolower( preg_replace( '/^www\./', '', (string) $home ) );
}

/**
 * Link attributes: external links open in a new tab with rel="noopener".
 *
 * @param string $url URL.
 * @return string
 */
function bagus_link_attrs( $url ) {
	$attr = ' href="' . esc_url( $url ) . '"';
	if ( bagus_is_external( $url ) ) {
		$attr .= ' target="_blank" rel="noopener"';
	}
	return $attr;
}

/**
 * Button markup.
 *
 * @param string $label Label.
 * @param string $url   URL.
 * @param string $style primary|ghost|light|link.
 * @param string $icon  Optional icon key.
 * @param array  $extra Extra attributes.
 * @return string
 */
function bagus_button( $label, $url, $style = 'primary', $icon = '', $extra = array() ) {
	$class = 'btn btn--' . $style . ( isset( $extra['class'] ) ? ' ' . $extra['class'] : '' );
	unset( $extra['class'] );
	$attrs = '';
	foreach ( $extra as $k => $v ) {
		$attrs .= ' ' . esc_attr( $k ) . '="' . esc_attr( $v ) . '"';
	}
	$inner = ( $icon ? bagus_icon( $icon ) : '' ) . '<span>' . esc_html( $label ) . '</span>';
	if ( 'link' === $style ) {
		$inner .= bagus_icon( 'arrow-right' );
	}
	return '<a class="' . esc_attr( $class ) . '"' . bagus_link_attrs( $url ) . $attrs . ' data-magnetic>' . $inner . '</a>';
}

/**
 * Site logo (Customizer logo → preset logo → text).
 *
 * @param string $context header|footer.
 */
function bagus_logo( $context = 'header' ) {
	$brand = bagus_data( 'brand' );
	$name  = $brand['name'] ? $brand['name'] : get_bloginfo( 'name' );
	echo '<a class="brand brand--' . esc_attr( $context ) . '" href="' . esc_url( home_url( '/' ) ) . '" rel="home" aria-label="' . esc_attr( $name ) . '">';
	$logo_id = get_theme_mod( 'custom_logo' );
	if ( $logo_id ) {
		echo bagus_img( (int) $logo_id, $brand['logo_alt'] ?? $name, array( 'loading' => 'eager', 'sizes' => '160px', 'class' => 'brand__img' ), 'medium' ); // phpcs:ignore
	} elseif ( ! empty( $brand['logo'] ) ) {
		echo bagus_img( $brand['logo'], $brand['logo_alt'] ?? $name, array( 'loading' => 'eager', 'sizes' => '160px', 'class' => 'brand__img', 'width' => 254, 'height' => 150 ), 'medium' ); // phpcs:ignore
	} else {
		echo '<span class="brand__text">' . esc_html( $name ) . '</span>';
	}
	echo '</a>';
}

/**
 * Section heading helper.
 *
 * @param string $kicker Small text above.
 * @param string $title  Heading.
 * @param string $tag    Heading tag.
 * @param string $id     Heading id (for aria-labelledby).
 * @param string $align  start|center.
 */
function bagus_heading( $kicker, $title, $tag = 'h2', $id = '', $align = 'start' ) {
	echo '<header class="sec-head sec-head--' . esc_attr( $align ) . '">';
	if ( $kicker ) {
		echo '<p class="kicker" data-reveal="fade">' . esc_html( $kicker ) . '</p>';
	}
	printf(
		'<%1$s class="sec-title"%2$s data-split>%3$s</%1$s>',
		tag_escape( $tag ),
		$id ? ' id="' . esc_attr( $id ) . '"' : '',
		esc_html( $title )
	);
	echo '</header>';
}

/**
 * Swipe carousel wrapper (scroll-snap track + controls), see assets/js/carousel.js.
 *
 * @param string   $label    Accessible name.
 * @param string[] $slides   Slide inner HTML (already escaped).
 * @param array    $opts     variant (cards|media|full), autoplay (ms), class.
 */
function bagus_carousel( $label, $slides, $opts = array() ) {
	$opts  = array_merge( array( 'variant' => 'cards', 'autoplay' => 0, 'class' => '', 'lightbox' => false, 'progress' => false ), $opts );
	$total = count( $slides );
	if ( ! $total ) {
		return;
	}
	printf(
		'<section class="carousel carousel--%1$s %2$s" aria-roledescription="carousel" aria-label="%3$s"%4$s%5$s>',
		esc_attr( $opts['variant'] ),
		esc_attr( $opts['class'] ),
		esc_attr( $label ),
		$opts['autoplay'] ? ' data-autoplay="' . absint( $opts['autoplay'] ) . '"' : '',
		$opts['lightbox'] ? ' data-lightbox' : ''
	);
	if ( $total > 1 ) {
		echo '<div class="carousel__controls">';
		echo '<button type="button" class="carousel__btn" data-direction="previous" aria-label="' . esc_attr__( 'Previous slide', 'bagus' ) . '">' . bagus_icon( 'arrow-left' ) . '</button>'; // phpcs:ignore
		echo '<button type="button" class="carousel__btn" data-direction="next" aria-label="' . esc_attr__( 'Next slide', 'bagus' ) . '">' . bagus_icon( 'arrow-right' ) . '</button>'; // phpcs:ignore
		echo '</div>';
	}
	echo '<div class="carousel__track" tabindex="0" role="group" aria-label="' . esc_attr__( 'Slides', 'bagus' ) . '">';
	foreach ( $slides as $i => $html ) {
		/* translators: 1: slide number, 2: total slides */
		$pos = sprintf( __( '%1$d of %2$d', 'bagus' ), $i + 1, $total );
		/* translators: %d: slide number */
		$marker = sprintf( __( 'Go to slide %d', 'bagus' ), $i + 1 );
		echo '<div class="carousel__slide" role="group" aria-roledescription="slide" aria-label="' . esc_attr( $pos ) . '" data-marker-name="' . esc_attr( $marker ) . '">' . $html . '</div>'; // phpcs:ignore
	}
	echo '</div>';
	if ( $total > 1 && $opts['progress'] ) {
		echo '<div class="carousel__progress" aria-hidden="true"><span></span></div>';
	}
	if ( $total > 1 ) {
		echo '<p class="sr-only" role="status" aria-live="polite"></p>';
		echo '<nav class="carousel__markers" aria-label="' . esc_attr__( 'Choose a slide', 'bagus' ) . '"></nav>';
	}
	echo '</section>';
}

/** Posted-on meta. */
function bagus_posted_on() {
	printf(
		'<time class="entry-date" datetime="%1$s">%2$s</time>',
		esc_attr( get_the_date( DATE_W3C ) ),
		esc_html( get_the_date() )
	);
}

/** Breadcrumbs: Yoast / Rank Math if present, otherwise the theme's own (with schema in inc/seo.php). */
function bagus_breadcrumbs() {
	if ( is_front_page() ) {
		return;
	}
	if ( function_exists( 'yoast_breadcrumb' ) ) {
		yoast_breadcrumb( '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'bagus' ) . '">', '</nav>' );
		return;
	}
	if ( function_exists( 'rank_math_the_breadcrumbs' ) ) {
		echo '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'bagus' ) . '">';
		rank_math_the_breadcrumbs();
		echo '</nav>';
		return;
	}
	$items = bagus_breadcrumb_items();
	echo '<nav class="crumbs" aria-label="' . esc_attr__( 'Breadcrumb', 'bagus' ) . '"><ol>';
	$last = count( $items ) - 1;
	foreach ( $items as $i => $item ) {
		if ( $i === $last ) {
			echo '<li aria-current="page">' . esc_html( $item['name'] ) . '</li>';
		} else {
			echo '<li><a href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a></li>';
		}
	}
	echo '</ol></nav>';
}

/**
 * Breadcrumb trail as data (used for markup and JSON-LD).
 *
 * @return array<int,array{name:string,url:string}>
 */
function bagus_breadcrumb_items() {
	$items = array( array( 'name' => __( 'Home', 'bagus' ), 'url' => home_url( '/' ) ) );
	if ( is_singular() ) {
		$post = get_queried_object();
		if ( 'post' === $post->post_type && get_option( 'page_for_posts' ) ) {
			$items[] = array( 'name' => get_the_title( get_option( 'page_for_posts' ) ), 'url' => get_permalink( get_option( 'page_for_posts' ) ) );
		}
		foreach ( array_reverse( get_post_ancestors( $post ) ) as $ancestor ) {
			$items[] = array( 'name' => get_the_title( $ancestor ), 'url' => get_permalink( $ancestor ) );
		}
		$items[] = array( 'name' => get_the_title( $post ), 'url' => get_permalink( $post ) );
	} elseif ( is_home() ) {
		$items[] = array( 'name' => single_post_title( '', false ), 'url' => get_permalink( get_option( 'page_for_posts' ) ) );
	} elseif ( is_archive() ) {
		$items[] = array( 'name' => wp_strip_all_tags( get_the_archive_title() ), 'url' => '' );
	} elseif ( is_search() ) {
		/* translators: %s: search query */
		$items[] = array( 'name' => sprintf( __( 'Search: %s', 'bagus' ), get_search_query() ), 'url' => '' );
	} elseif ( is_404() ) {
		$items[] = array( 'name' => __( 'Page not found', 'bagus' ), 'url' => '' );
	}
	return $items;
}

/**
 * Split a post's blocks: a leading Gallery block with the "Page hero slideshow"
 * style becomes the page hero; everything else is rendered as content.
 *
 * @param int|WP_Post|null $post Post.
 * @return array{images:array<int,array{0:string,1:string}>,content:string}
 */
function bagus_split_hero( $post = null ) {
	$post   = get_post( $post );
	$blocks = parse_blocks( (string) $post->post_content );
	$images = array();
	foreach ( $blocks as $i => $block ) {
		if ( empty( $block['blockName'] ) ) {
			if ( '' === trim( (string) $block['innerHTML'] ) ) {
				continue;
			}
			break;
		}
		if ( 'core/gallery' === $block['blockName'] && false !== strpos( (string) ( $block['attrs']['className'] ?? '' ), 'is-style-hero' ) ) {
			$html = render_block( $block );
			if ( preg_match_all( '/<img[^>]+>/i', $html, $tags ) ) {
				foreach ( $tags[0] as $tag ) {
					preg_match( '/src="([^"]+)"/', $tag, $src );
					preg_match( '/alt="([^"]*)"/', $tag, $alt );
					if ( ! empty( $src[1] ) ) {
						$images[] = array( html_entity_decode( $src[1] ), isset( $alt[1] ) ? html_entity_decode( $alt[1] ) : '' );
					}
				}
			}
			unset( $blocks[ $i ] );
		}
		break;
	}
	return array( 'images' => $images, 'content' => serialize_blocks( $blocks ) );
}

/**
 * [bagus_section name="villas"] — reuse any homepage section on inner pages.
 */
add_shortcode(
	'bagus_section',
	function ( $atts ) {
		$atts = shortcode_atts( array( 'name' => '' ), $atts, 'bagus_section' );
		$name = sanitize_key( $atts['name'] );
		if ( ! $name || ! locate_template( 'template-parts/sections/' . $name . '.php' ) || ! bagus_data( $name ) ) {
			return '';
		}
		ob_start();
		echo '<div class="embedded-section">';
		get_template_part( 'template-parts/sections/' . $name, null, array( 'data' => bagus_data( $name ) ) );
		echo '</div>';
		return ob_get_clean();
	}
);
