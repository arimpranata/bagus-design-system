<?php
/**
 * Elementor → block editor converter (Tools → Bagus: Convert pages).
 *
 * Reads the `_elementor_data` JSON that Elementor stores for every page, so it
 * works even after Elementor has been deactivated. The page is rebuilt with
 * core blocks + the theme's block styles:
 *   - first slideshow / image run   → Gallery "Page hero slideshow"
 *   - photo + heading + text        → Media & Text (alternating sides)
 *   - image runs                    → Gallery "Swipe carousel" (≥ 12: "Photo grid")
 *   - "… includes:" + list + button → Cards in a "Swipe on mobile" Columns block
 *   - h3 + list groups              → Group "Facilities grid"
 *   - ≥ 3 section headings          → sticky chip tabs linking to each section
 *
 * The old content is kept as a revision, and the original Elementor data is
 * left untouched, so a page can always be restored.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/* --------------------------------------------------------------------------
 * 1. Elementor JSON → flat token list
 * ------------------------------------------------------------------------ */

/**
 * Flatten an Elementor element tree into tokens.
 *
 * Token shapes: ['img', url, alt] | ['h', level, text] | ['p', text] | ['li', text]
 *               | ['btn', text, url] | ['slideshow', [url…]] | ['html', html]
 *
 * @param array $elements Elementor elements.
 * @param array $tokens   Accumulator.
 * @return array
 */
function bagus_el_tokens( $elements, &$tokens = array() ) {
	foreach ( (array) $elements as $el ) {
		$s    = isset( $el['settings'] ) && is_array( $el['settings'] ) ? $el['settings'] : array();
		$type = $el['widgetType'] ?? ( $el['elType'] ?? '' );

		if ( ! empty( $s['background_slideshow_gallery'] ) ) {
			$tokens[] = array( 'slideshow', array_values( array_filter( wp_list_pluck( $s['background_slideshow_gallery'], 'url' ) ) ) );
		}

		switch ( $type ) {
			case 'heading':
				$level    = (int) preg_replace( '/\D/', '', $s['header_size'] ?? 'h2' );
				$tokens[] = array( 'h', $level ? $level : 2, bagus_el_text( $s['title'] ?? '' ) );
				break;

			case 'text-editor':
				bagus_el_html_tokens( (string) ( $s['editor'] ?? '' ), $tokens );
				break;

			case 'image':
				if ( ! empty( $s['image']['url'] ) ) {
					$tokens[] = array( 'img', $s['image']['url'], bagus_el_alt( $s['image'] ) );
				}
				break;

			case 'image-carousel':
			case 'image-gallery':
			case 'basic-gallery':
			case 'qi_addons_for_elementor_image_slider':
				foreach ( (array) ( $s['carousel'] ?? $s['wp_gallery'] ?? $s['gallery'] ?? $s['images'] ?? array() ) as $img ) {
					if ( ! empty( $img['url'] ) ) {
						$tokens[] = array( 'img', $img['url'], bagus_el_alt( $img ) );
					}
				}
				break;

			case 'gallery': // Elementor Pro gallery (single or multiple/filterable).
				if ( ! empty( $s['galleries'] ) ) {
					foreach ( $s['galleries'] as $g ) {
						$tokens[] = array( 'h', 2, bagus_el_text( $g['gallery_title'] ?? '' ) );
						foreach ( (array) ( $g['multiple_gallery'] ?? array() ) as $img ) {
							if ( ! empty( $img['url'] ) ) {
								$tokens[] = array( 'img', $img['url'], bagus_el_alt( $img ) );
							}
						}
					}
				} else {
					foreach ( (array) ( $s['gallery'] ?? array() ) as $img ) {
						if ( ! empty( $img['url'] ) ) {
							$tokens[] = array( 'img', $img['url'], bagus_el_alt( $img ) );
						}
					}
				}
				break;

			case 'button':
				$url = $s['link']['url'] ?? '';
				if ( $url && 0 !== strpos( $url, '#elementor-action' ) ) {
					$tokens[] = array( 'btn', bagus_el_text( $s['text'] ?? __( 'Read More', 'bagus' ) ), $url );
				}
				break;

			case 'icon-list':
				foreach ( (array) ( $s['icon_list'] ?? array() ) as $item ) {
					$t = bagus_el_text( $item['text'] ?? '' );
					if ( '' !== $t ) {
						$tokens[] = array( 'li', $t );
					}
				}
				break;

			case 'video':
				$url = $s['youtube_url'] ?? $s['vimeo_url'] ?? $s['external_url']['url'] ?? '';
				if ( $url ) {
					$tokens[] = array( 'btn', __( 'Video', 'bagus' ), $url );
				}
				break;

			case 'slides':
				foreach ( (array) ( $s['slides'] ?? array() ) as $slide ) {
					if ( ! empty( $slide['background_image']['url'] ) ) {
						$tokens[] = array( 'img', $slide['background_image']['url'], bagus_el_text( $slide['heading'] ?? '' ) );
					}
				}
				break;

			case 'html':
				// Custom HTML widgets are usually embeds/scripts; skip them.
				break;
		}

		if ( ! empty( $el['elements'] ) ) {
			bagus_el_tokens( $el['elements'], $tokens );
		}
	}
	return $tokens;
}

/** Plain text from Elementor HTML-ish strings. */
function bagus_el_text( $html ) {
	return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( (string) $html ), ENT_QUOTES, 'UTF-8' ) ) );
}

/** Alt text of an Elementor image setting (falls back to the attachment's alt). */
function bagus_el_alt( $img ) {
	if ( ! empty( $img['alt'] ) ) {
		return bagus_el_text( $img['alt'] );
	}
	if ( ! empty( $img['id'] ) ) {
		return (string) get_post_meta( (int) $img['id'], '_wp_attachment_image_alt', true );
	}
	return '';
}

/** Split text-editor HTML into paragraph / list-item / heading tokens. */
function bagus_el_html_tokens( $html, &$tokens ) {
	if ( '' === trim( $html ) ) {
		return;
	}
	if ( ! preg_match( '/<(p|ul|ol|h[1-6]|li)\b/i', $html ) ) {
		$html = wpautop( $html );
	}
	if ( preg_match_all( '/<(p|li|h[1-6])\b[^>]*>(.*?)<\/\1>/is', $html, $m, PREG_SET_ORDER ) ) {
		foreach ( $m as $part ) {
			$text = bagus_el_text( $part[2] );
			if ( '' === $text ) {
				continue;
			}
			$tag = strtolower( $part[1] );
			if ( 'li' === $tag ) {
				$tokens[] = array( 'li', $text );
			} elseif ( 'p' === $tag ) {
				$tokens[] = array( 'p', $text );
			} else {
				$tokens[] = array( 'h', (int) $tag[1], $text );
			}
		}
	}
}

/* --------------------------------------------------------------------------
 * 2. Tokens → block markup
 * ------------------------------------------------------------------------ */

/** Small block markup builders. */
function bagus_b_p( $t ) {
	return '<!-- wp:paragraph --><p>' . esc_html( $t ) . '</p><!-- /wp:paragraph -->';
}
function bagus_b_h( $t, $level = 2, $class = '', $anchor = '' ) {
	$attrs = array();
	if ( 2 !== $level ) {
		$attrs['level'] = $level;
	}
	if ( $class ) {
		$attrs['className'] = $class;
	}
	if ( $anchor ) {
		$attrs['anchor'] = $anchor;
	}
	return '<!-- wp:heading' . ( $attrs ? ' ' . wp_json_encode( $attrs ) : '' ) . ' --><h' . $level . ' class="wp-block-heading' . ( $class ? ' ' . esc_attr( $class ) : '' ) . '"' . ( $anchor ? ' id="' . esc_attr( $anchor ) . '"' : '' ) . '>' . esc_html( $t ) . '</h' . $level . '><!-- /wp:heading -->';
}
function bagus_b_list( $items ) {
	$out = '<!-- wp:list --><ul class="wp-block-list">';
	foreach ( $items as $i ) {
		$out .= '<!-- wp:list-item --><li>' . esc_html( $i ) . '</li><!-- /wp:list-item -->';
	}
	return $out . '</ul><!-- /wp:list -->';
}
function bagus_b_img( $src, $alt = '' ) {
	return '<!-- wp:image --><figure class="wp-block-image"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '"/></figure><!-- /wp:image -->';
}
function bagus_b_gallery( $imgs, $style = 'is-style-swipe' ) {
	$out = '<!-- wp:gallery {"className":"' . $style . '","linkTo":"none"} --><figure class="wp-block-gallery has-nested-images columns-default is-cropped ' . $style . '">';
	foreach ( $imgs as $img ) {
		$out .= bagus_b_img( $img[0], $img[1] );
	}
	return $out . '</figure><!-- /wp:gallery -->';
}
function bagus_b_buttons( $btns ) {
	$out = '<!-- wp:buttons --><div class="wp-block-buttons">';
	foreach ( $btns as $i => $b ) {
		$label = ( strtoupper( $b[0] ) === $b[0] || strtolower( $b[0] ) === $b[0] ) ? ucwords( strtolower( $b[0] ) ) : $b[0];
		$cls   = $i ? ' is-style-outline' : '';
		$out  .= '<!-- wp:button' . ( $i ? ' {"className":"is-style-outline"}' : '' ) . ' --><div class="wp-block-button' . $cls . '"><a class="wp-block-button__link wp-element-button" href="' . esc_url( $b[1] ) . '">' . esc_html( $label ) . '</a></div><!-- /wp:button -->';
	}
	return $out . '</div><!-- /wp:buttons -->';
}
function bagus_b_group( $inner, $class ) {
	return '<!-- wp:group {"className":"' . $class . '"} --><div class="wp-block-group ' . $class . '">' . $inner . '</div><!-- /wp:group -->';
}
function bagus_b_columns( $cols, $class = 'is-style-swipe' ) {
	$out = '<!-- wp:columns {"className":"' . $class . '"} --><div class="wp-block-columns ' . $class . '">';
	foreach ( $cols as $c ) {
		$out .= '<!-- wp:column --><div class="wp-block-column">' . $c . '</div><!-- /wp:column -->';
	}
	return $out . '</div><!-- /wp:columns -->';
}
function bagus_b_media_text( $src, $alt, $inner, $right ) {
	return '<!-- wp:media-text ' . ( $right ? '{"mediaPosition":"right","mediaType":"image"}' : '{"mediaType":"image"}' ) . ' --><div class="wp-block-media-text' . ( $right ? ' has-media-on-the-right' : '' ) . ' is-stacked-on-mobile"><figure class="wp-block-media-text__media"><img src="' . esc_url( $src ) . '" alt="' . esc_attr( $alt ) . '"/></figure><div class="wp-block-media-text__content">' . $inner . '</div></div><!-- /wp:media-text -->';
}

/**
 * Convert tokens to block markup.
 *
 * @param array  $tokens Tokens.
 * @param string $title  Page title (a matching H1 is dropped; the theme prints it).
 * @return string
 */
function bagus_tokens_to_blocks( $tokens, $title ) {
	$tokens = array_values(
		array_filter(
			$tokens,
			fn( $t ) => ! ( in_array( $t[0], array( 'p', 'h', 'li' ), true ) && '' === trim( (string) end( $t ) ) ) && ! ( 'slideshow' === $t[0] && empty( $t[1] ) )
		)
	);

	// Hero: first slideshow, else the leading run of images.
	$hero = array();
	foreach ( $tokens as $t ) {
		if ( 'slideshow' === $t[0] ) {
			$hero = array_map( fn( $u ) => array( $u, '' ), $t[1] );
			break;
		}
	}
	$i = 0;
	if ( ! $hero ) {
		while ( isset( $tokens[ $i ] ) && 'img' === $tokens[ $i ][0] ) {
			$hero[] = array( $tokens[ $i ][1], $tokens[ $i ][2] );
			$i++;
		}
	}
	$tokens = array_values( array_filter( array_slice( $tokens, $i ), fn( $t ) => 'slideshow' !== $t[0] ) );

	$out = array();
	if ( $hero ) {
		$out[] = bagus_b_gallery( array_slice( $hero, 0, 6 ), 'is-style-hero' );
	}
	$h2 = array_values( array_filter( $tokens, fn( $t ) => 'h' === $t[0] && 2 === $t[1] ) );
	if ( count( $h2 ) >= 3 ) {
		$rail = '<nav class="chip-rail" aria-label="' . esc_attr__( 'On this page', 'bagus' ) . '" data-scrollspy>';
		foreach ( $h2 as $h ) {
			$rail .= '<a class="chip" href="#' . esc_attr( sanitize_title( $h[2] ) ) . '">' . esc_html( $h[2] ) . '</a>';
		}
		$out[] = '<!-- wp:html -->' . $rail . '</nav><!-- /wp:html -->';
	}

	$n    = count( $tokens );
	$k    = 0;
	$flip = false;
	$seen = array();

	// Body until the next image or H2.
	$take_body = function ( $k ) use ( &$tokens, $n, $title ) {
		$body  = array();
		$lis   = array();
		$btns  = array();
		$cards = array();
		$flush = function () use ( &$body, &$lis, &$btns ) {
			if ( $lis ) {
				$body[] = bagus_b_list( $lis );
				$lis    = array();
			}
			if ( $btns ) {
				$body[] = bagus_b_buttons( $btns );
				$btns   = array();
			}
		};
		while ( $k < $n && 'img' !== $tokens[ $k ][0] && ! ( 'h' === $tokens[ $k ][0] && 2 === $tokens[ $k ][1] ) ) {
			$t = $tokens[ $k ];
			// "… includes:" + list (+ buttons) → card.
			if ( 'p' === $t[0] && ':' === substr( rtrim( $t[1] ), -1 ) && isset( $tokens[ $k + 1 ] ) && 'li' === $tokens[ $k + 1 ][0] ) {
				$flush();
				$j     = $k + 1;
				$items = array();
				while ( $j < $n && 'li' === $tokens[ $j ][0] ) {
					$items[] = $tokens[ $j ][1];
					$j++;
				}
				$cb = array();
				while ( $j < $n && 'btn' === $tokens[ $j ][0] ) {
					$cb[] = array( $tokens[ $j ][1], $tokens[ $j ][2] );
					$j++;
				}
				$cards[] = bagus_b_p( $t[1] ) . bagus_b_list( $items ) . ( $cb ? bagus_b_buttons( $cb ) : '' );
				$k       = $j;
				continue;
			}
			if ( $cards ) {
				$body[] = bagus_b_columns( array_map( fn( $c ) => bagus_b_group( $c, 'is-style-card' ), $cards ) );
				$cards  = array();
			}
			// h3 + list groups → facilities grid.
			if ( 'h' === $t[0] && 3 === $t[1] && isset( $tokens[ $k + 1 ] ) && 'li' === $tokens[ $k + 1 ][0] ) {
				$flush();
				$facs = array();
				while ( $k < $n && 'h' === $tokens[ $k ][0] && 3 === $tokens[ $k ][1] && isset( $tokens[ $k + 1 ] ) && 'li' === $tokens[ $k + 1 ][0] ) {
					$j     = $k + 1;
					$items = array();
					while ( $j < $n && 'li' === $tokens[ $j ][0] ) {
						$items[] = $tokens[ $j ][1];
						$j++;
					}
					$facs[] = bagus_b_group( bagus_b_h( $tokens[ $k ][2], 3 ) . bagus_b_list( $items ), 'facility' );
					$k      = $j;
				}
				$body[] = bagus_b_group( implode( '', $facs ), 'is-style-facilities' );
				continue;
			}
			if ( 'li' === $t[0] ) {
				if ( $btns ) {
					$flush();
				}
				$lis[] = $t[1];
			} elseif ( 'btn' === $t[0] ) {
				if ( $lis ) {
					$body[] = bagus_b_list( $lis );
					$lis    = array();
				}
				$btns[] = array( $t[1], $t[2] );
			} else {
				$flush();
				if ( 'p' === $t[0] ) {
					$body[] = bagus_b_p( $t[1] );
				} elseif ( 'h' === $t[0] ) {
					if ( 1 === $t[1] ) {
						if ( strtolower( $t[2] ) !== strtolower( $title ) ) {
							$body[] = bagus_b_h( $t[2], 2, 'is-style-divider' );
						}
					} else {
						$body[] = bagus_b_h( $t[2], $t[1] );
					}
				}
			}
			$k++;
		}
		if ( $cards ) {
			$body[] = bagus_b_columns( array_map( fn( $c ) => bagus_b_group( $c, 'is-style-card' ), $cards ) );
		}
		$flush();
		return array( implode( '', $body ), $k );
	};

	while ( $k < $n ) {
		$t = $tokens[ $k ];
		if ( 'img' === $t[0] ) {
			$j    = $k;
			$imgs = array();
			while ( $j < $n && 'img' === $tokens[ $j ][0] ) {
				$imgs[] = array( $tokens[ $j ][1], $tokens[ $j ][2] );
				$j++;
			}
			// image + h4/h5 pairs → linked cards row.
			if ( isset( $tokens[ $j ] ) && 'h' === $tokens[ $j ][0] && $tokens[ $j ][1] >= 4 && 1 === count( $imgs ) ) {
				$cards = array();
				$m     = $k;
				while ( isset( $tokens[ $m + 1 ] ) && 'img' === $tokens[ $m ][0] && 'h' === $tokens[ $m + 1 ][0] && $tokens[ $m + 1 ][1] >= 4 ) {
					$cards[] = bagus_b_img( $tokens[ $m ][1], $tokens[ $m ][2] ) . bagus_b_h( $tokens[ $m + 1 ][2], 3 );
					$m      += 2;
				}
				$out[] = bagus_b_columns( $cards );
				$k     = $m;
				continue;
			}
			if ( 1 === count( $imgs ) && isset( $tokens[ $j ] ) && 'h' === $tokens[ $j ][0] && 2 === $tokens[ $j ][1] ) {
				$h = $tokens[ $j ][2];
				list( $body, $k2 ) = $take_body( $j + 1 );
				if ( false !== strpos( $body, 'is-style-facilities' ) || false !== strpos( $body, 'wp-block-columns' ) ) {
					$out[] = bagus_b_img( $imgs[0][0], $imgs[0][1] );
					$out[] = bagus_b_h( $h, 2, 'is-style-divider', sanitize_title( $h ) );
					$out[] = $body;
				} else {
					$out[] = bagus_b_media_text( $imgs[0][0], $imgs[0][1], bagus_b_h( $h, 2, '', sanitize_title( $h ) ) . $body, $flip );
					$flip  = ! $flip;
				}
				$k = $k2;
				continue;
			}
			if ( count( $imgs ) >= 12 ) {
				$uniq = array();
				foreach ( $imgs as $img ) {
					if ( empty( $seen[ $img[0] ] ) ) {
						$seen[ $img[0] ] = true;
						$uniq[]          = $img;
					}
				}
				if ( $uniq ) {
					$out[] = bagus_b_gallery( $uniq, 'is-style-grid' );
				}
			} else {
				$out[] = count( $imgs ) > 1 ? bagus_b_gallery( $imgs ) : bagus_b_img( $imgs[0][0], $imgs[0][1] );
			}
			$k = $j;
			continue;
		}
		if ( 'h' === $t[0] && 2 === $t[1] ) {
			$out[] = bagus_b_h( $t[2], 2, 'is-style-divider', sanitize_title( $t[2] ) );
			$k++;
			continue;
		}
		list( $body, $k2 ) = $take_body( $k );
		$out[] = $body;
		$k     = $k2 === $k ? $k + 1 : $k2;
	}

	return implode( "\n", array_filter( $out ) );
}

/**
 * Convert one page. Returns the new block content (and saves it unless $dry).
 *
 * @param int  $post_id Page ID.
 * @param bool $dry     Only return the markup.
 * @return string|WP_Error
 */
function bagus_convert_elementor_page( $post_id, $dry = false ) {
	$raw = get_post_meta( $post_id, '_elementor_data', true );
	if ( ! $raw ) {
		return new WP_Error( 'bagus_no_elementor', __( 'This page has no Elementor data.', 'bagus' ) );
	}
	$data = is_array( $raw ) ? $raw : json_decode( is_string( $raw ) ? wp_unslash( $raw ) : '', true );
	if ( ! is_array( $data ) ) {
		$data = json_decode( (string) $raw, true );
	}
	if ( ! is_array( $data ) ) {
		return new WP_Error( 'bagus_bad_json', __( 'Elementor data could not be read.', 'bagus' ) );
	}
	$blocks = bagus_tokens_to_blocks( bagus_el_tokens( $data ), get_the_title( $post_id ) );
	if ( $dry ) {
		return $blocks;
	}
	$res = wp_update_post( array( 'ID' => $post_id, 'post_content' => wp_slash( $blocks ) ), true ); // Old content stays as a revision.
	if ( is_wp_error( $res ) ) {
		return $res;
	}
	update_post_meta( $post_id, '_elementor_edit_mode', '' ); // Elementor (if still active) no longer overrides the page.
	update_post_meta( $post_id, '_bagus_converted', current_time( 'mysql' ) );
	if ( 'page' === get_post_type( $post_id ) && 'elementor_header_footer' === get_post_meta( $post_id, '_wp_page_template', true ) ) {
		update_post_meta( $post_id, '_wp_page_template', 'default' );
	}
	return $blocks;
}

/* --------------------------------------------------------------------------
 * 3. Admin screen: Tools → Bagus: Convert pages
 * ------------------------------------------------------------------------ */

add_action(
	'admin_menu',
	function () {
		add_management_page( __( 'Bagus: Convert pages', 'bagus' ), __( 'Bagus: Convert pages', 'bagus' ), 'edit_pages', 'bagus-convert', 'bagus_convert_screen' );
	}
);

/** Render the converter screen. */
function bagus_convert_screen() {
	if ( ! current_user_can( 'edit_pages' ) ) {
		return;
	}
	$done = array();
	if ( isset( $_POST['bagus_convert'] ) && check_admin_referer( 'bagus_convert' ) ) {
		$ids = array_map( 'absint', (array) ( $_POST['ids'] ?? array() ) );
		foreach ( $ids as $id ) {
			if ( current_user_can( 'edit_post', $id ) ) {
				$r           = bagus_convert_elementor_page( $id );
				$done[ $id ] = is_wp_error( $r ) ? $r->get_error_message() : true;
			}
		}
	}
	$pages = get_posts(
		array(
			'post_type'      => array( 'page', 'post' ),
			'post_status'    => array( 'publish', 'draft', 'private' ),
			'posts_per_page' => -1,
			'meta_key'       => '_elementor_data', // phpcs:ignore WordPress.DB.SlowDBQuery
			'orderby'        => 'title',
			'order'          => 'ASC',
		)
	);
	echo '<div class="wrap"><h1>' . esc_html__( 'Bagus: Convert Elementor pages to blocks', 'bagus' ) . '</h1>';
	echo '<p>' . esc_html__( 'Rebuilds each selected page with blocks in the Bagus layout (photo-band hero, swipe galleries, photo & text rows, cards, facilities grid). The previous content is saved as a revision and the Elementor data is not deleted, so you can restore a page from its revisions at any time. Converted pages can be edited normally in the block editor.', 'bagus' ) . '</p>';
	if ( $done ) {
		echo '<div class="notice notice-success"><p>';
		foreach ( $done as $id => $r ) {
			echo esc_html( get_the_title( $id ) ) . ': ' . ( true === $r ? '<a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank">' . esc_html__( 'converted – view', 'bagus' ) . '</a>' : esc_html( $r ) ) . '<br>';
		}
		echo '</p></div>';
	}
	if ( ! $pages ) {
		echo '<p><em>' . esc_html__( 'No pages with Elementor data were found.', 'bagus' ) . '</em></p></div>';
		return;
	}
	echo '<form method="post">';
	wp_nonce_field( 'bagus_convert' );
	echo '<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" onclick="document.querySelectorAll(\'.bagus-id\').forEach(c=>c.checked=this.checked)"></td><th>' . esc_html__( 'Page', 'bagus' ) . '</th><th>' . esc_html__( 'Status', 'bagus' ) . '</th></tr></thead><tbody>';
	foreach ( $pages as $p ) {
		$conv = get_post_meta( $p->ID, '_bagus_converted', true );
		printf(
			'<tr><th class="check-column"><input class="bagus-id" type="checkbox" name="ids[]" value="%1$d" %4$s></th><td><strong><a href="%2$s" target="_blank">%3$s</a></strong> <code>/%5$s/</code></td><td>%6$s</td></tr>',
			(int) $p->ID,
			esc_url( get_permalink( $p ) ),
			esc_html( get_the_title( $p ) ),
			$conv ? '' : 'checked',
			esc_html( get_page_uri( $p ) ),
			$conv ? esc_html( sprintf( /* translators: %s: date */ __( 'Converted %s', 'bagus' ), $conv ) ) : esc_html__( 'Elementor', 'bagus' )
		);
	}
	echo '</tbody></table><p><button class="button button-primary" name="bagus_convert" value="1">' . esc_html__( 'Convert selected pages', 'bagus' ) . '</button></p></form></div>';
}

/* --------------------------------------------------------------------------
 * 4. WP-CLI: wp bagus convert [<id>…] [--all] [--dry-run]
 * ------------------------------------------------------------------------ */

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	WP_CLI::add_command(
		'bagus convert',
		function ( $args, $assoc ) {
			$ids = array_map( 'absint', $args );
			if ( ! empty( $assoc['all'] ) ) {
				$ids = get_posts( array( 'post_type' => array( 'page', 'post' ), 'posts_per_page' => -1, 'fields' => 'ids', 'meta_key' => '_elementor_data', 'post_status' => 'any' ) ); // phpcs:ignore
			}
			foreach ( $ids as $id ) {
				$r = bagus_convert_elementor_page( $id, ! empty( $assoc['dry-run'] ) );
				if ( is_wp_error( $r ) ) {
					WP_CLI::warning( get_the_title( $id ) . ': ' . $r->get_error_message() );
				} elseif ( ! empty( $assoc['dry-run'] ) ) {
					WP_CLI::line( $r );
				} else {
					WP_CLI::success( get_the_title( $id ) . ' converted.' );
				}
			}
		}
	);
}
