<?php
/**
 * Menus: one tree, two renderers (desktop dropdown + mobile drawer accordion).
 * Falls back to the preset menu so the site keeps its exact menu even before
 * a WordPress menu is assigned.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/**
 * Menu tree for a location.
 *
 * @param string $location Theme location.
 * @return array<int,array{title:string,url:string,current:bool,target:string,children:array}>
 */
function bagus_menu_tree( $location = 'primary' ) {
	static $cache = array();
	if ( isset( $cache[ $location ] ) ) {
		return $cache[ $location ];
	}

	$tree      = array();
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations[ $location ] ) ) {
		$items = wp_get_nav_menu_items( $locations[ $location ], array( 'update_post_term_cache' => false ) );
		if ( $items ) {
			_wp_menu_item_classes_by_context( $items );
			$by_id = array();
			foreach ( $items as $item ) {
				$by_id[ $item->ID ] = array(
					'title'    => $item->title,
					'url'      => $item->url,
					'target'   => $item->target,
					'current'  => (bool) array_intersect( (array) $item->classes, array( 'current-menu-item', 'current-menu-ancestor', 'current-menu-parent' ) ),
					'parent'   => (int) $item->menu_item_parent,
					'children' => array(),
				);
			}
			// Build the tree (supports 2 levels which is what the design shows).
			foreach ( $by_id as $id => &$node ) {
				if ( $node['parent'] && isset( $by_id[ $node['parent'] ] ) ) {
					$by_id[ $node['parent'] ]['children'][] = &$node;
				}
			}
			unset( $node );
			foreach ( $by_id as $node ) {
				if ( ! $node['parent'] ) {
					$tree[] = $node;
				}
			}
		}
	}

	if ( ! $tree && 'primary' === $location ) {
		$tree = bagus_normalize_menu( bagus_data( 'menu' ) );
	}

	return $cache[ $location ] = $tree;
}

/**
 * Normalize preset menu items and mark the current one.
 *
 * @param array $items Preset items.
 * @return array
 */
function bagus_normalize_menu( $items ) {
	$out     = array();
	$current = untrailingslashit( strtok( home_url( add_query_arg( array() ) ), '?' ) );
	foreach ( (array) $items as $item ) {
		$children = bagus_normalize_menu( $item['children'] ?? array() );
		$is_cur   = untrailingslashit( strtok( $item['url'], '#' ) ) === $current;
		foreach ( $children as $c ) {
			$is_cur = $is_cur || $c['current'];
		}
		$out[] = array(
			'title'    => $item['title'],
			'url'      => $item['url'],
			'target'   => '',
			'current'  => $is_cur,
			'children' => $children,
		);
	}
	return $out;
}

/**
 * Render a menu.
 *
 * @param string $variant desktop|drawer|footer.
 * @param string $location Theme location.
 */
function bagus_render_menu( $variant = 'desktop', $location = 'primary' ) {
	$tree = bagus_menu_tree( $location );
	if ( ! $tree ) {
		return;
	}
	echo '<ul class="menu menu--' . esc_attr( $variant ) . '">';
	foreach ( $tree as $i => $item ) {
		$has   = ! empty( $item['children'] ) && 'footer' !== $variant;
		$dummy = in_array( $item['url'], array( '', '#' ), true );
		$cls   = 'menu__item' . ( $has ? ' has-sub' : '' ) . ( $item['current'] ? ' is-current' : '' );
		echo '<li class="' . esc_attr( $cls ) . '"' . ( 'drawer' === $variant ? ' style="--i:' . (int) $i . '"' : '' ) . '>';

		$sub_id = 'sub-' . $variant . '-' . $i;
		if ( $has && $dummy ) {
			// Parent without its own page: the whole row is the toggle.
			echo '<button type="button" class="menu__link menu__toggle" aria-expanded="false" aria-controls="' . esc_attr( $sub_id ) . '">' . esc_html( $item['title'] ) . bagus_icon( 'chevron-down' ) . '</button>'; // phpcs:ignore
		} else {
			echo '<a class="menu__link" href="' . esc_url( $item['url'] ) . '"' . ( $item['target'] ? ' target="' . esc_attr( $item['target'] ) . '" rel="noopener"' : '' ) . ( $item['current'] ? ' aria-current="page"' : '' ) . '>' . esc_html( $item['title'] ) . '</a>';
			if ( $has ) {
				/* translators: %s: menu item */
				echo '<button type="button" class="menu__toggle menu__toggle--icon" aria-expanded="false" aria-controls="' . esc_attr( $sub_id ) . '" aria-label="' . esc_attr( sprintf( __( 'Show %s submenu', 'bagus' ), $item['title'] ) ) . '">' . bagus_icon( 'chevron-down' ) . '</button>'; // phpcs:ignore
			}
		}

		if ( $has ) {
			echo '<div class="menu__sub" id="' . esc_attr( $sub_id ) . '"><ul>';
			foreach ( $item['children'] as $child ) {
				echo '<li><a class="menu__sublink" href="' . esc_url( $child['url'] ) . '"' . ( $child['current'] ? ' aria-current="page"' : '' ) . '>' . esc_html( $child['title'] ) . '</a></li>';
			}
			echo '</ul></div>';
		}
		echo '</li>';
	}
	echo '</ul>';
}
