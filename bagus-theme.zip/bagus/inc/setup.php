<?php
/**
 * Theme setup: supports, menus, image sizes, block styles.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'after_setup_theme',
	function () {
		load_theme_textdomain( 'bagus', BAGUS_DIR . '/languages' );

		add_theme_support( 'title-tag' );           // Lets Yoast / Rank Math / core manage <title>.
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'responsive-embeds' );
		add_theme_support( 'align-wide' );
		add_theme_support( 'wp-block-styles' );
		add_theme_support( 'editor-styles' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
		add_theme_support( 'custom-logo', array( 'height' => 150, 'width' => 254, 'flex-height' => true, 'flex-width' => true ) );
		add_theme_support( 'customize-selective-refresh-widgets' );
		add_editor_style( 'assets/css/editor.css' );

		register_nav_menus(
			array(
				'primary' => __( 'Primary menu', 'bagus' ),
				'footer'  => __( 'Footer menu', 'bagus' ),
			)
		);

		add_image_size( 'bagus-card', 720, 900, true );
		add_image_size( 'bagus-wide', 1600, 900, true );
	}
);

/** Content width for embeds. */
add_action(
	'after_setup_theme',
	function () {
		$GLOBALS['content_width'] = 760;
	},
	0
);

/** Widget areas. */
add_action(
	'widgets_init',
	function () {
		register_sidebar(
			array(
				'name'          => __( 'Blog sidebar', 'bagus' ),
				'id'            => 'sidebar-1',
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
		register_sidebar(
			array(
				'name'          => __( 'Footer extra', 'bagus' ),
				'id'            => 'footer-1',
				'description'   => __( 'Optional widgets shown above the footer bottom bar.', 'bagus' ),
				'before_widget' => '<section id="%1$s" class="widget %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<h2 class="widget-title">',
				'after_title'   => '</h2>',
			)
		);
	}
);

/** Block styles that hook into the theme's own JS components. */
add_action(
	'init',
	function () {
		if ( ! function_exists( 'register_block_style' ) ) {
			return;
		}
		register_block_style( 'core/gallery', array( 'name' => 'swipe', 'label' => __( 'Swipe carousel', 'bagus' ) ) );
		register_block_style( 'core/gallery', array( 'name' => 'hero', 'label' => __( 'Page hero slideshow', 'bagus' ) ) );
		register_block_style( 'core/gallery', array( 'name' => 'grid', 'label' => __( 'Photo grid', 'bagus' ) ) );
		register_block_style( 'core/group', array( 'name' => 'facilities', 'label' => __( 'Facilities grid', 'bagus' ) ) );
		register_block_style( 'core/heading', array( 'name' => 'divider', 'label' => __( 'Centered with divider', 'bagus' ) ) );
		register_block_style( 'core/columns', array( 'name' => 'swipe', 'label' => __( 'Swipe on mobile', 'bagus' ) ) );
		register_block_style( 'core/group', array( 'name' => 'card', 'label' => __( 'Card', 'bagus' ) ) );
		register_block_style( 'core/heading', array( 'name' => 'kicker', 'label' => __( 'Kicker', 'bagus' ) ) );
		register_block_style( 'core/button', array( 'name' => 'ghost', 'label' => __( 'Ghost', 'bagus' ) ) );
	}
);

/**
 * On activation, assign the existing site menu to the primary location
 * (keeps the current bagusjati.com menu without any manual step).
 */
add_action(
	'after_switch_theme',
	function () {
		$locations = get_theme_mod( 'nav_menu_locations', array() );
		if ( ! empty( $locations['primary'] ) ) {
			return;
		}
		$best  = 0;
		$count = 0;
		foreach ( wp_get_nav_menus() as $menu ) {
			if ( $menu->count > $count ) {
				$best  = $menu->term_id;
				$count = $menu->count;
			}
		}
		if ( $best ) {
			$locations['primary'] = $best;
			set_theme_mod( 'nav_menu_locations', $locations );
		}
	}
);

/** Excerpt tweaks. */
add_filter( 'excerpt_length', fn() => 26 );
add_filter( 'excerpt_more', fn() => '…' );
