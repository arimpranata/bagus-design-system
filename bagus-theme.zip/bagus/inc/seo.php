<?php
/**
 * SEO (Google Search Essentials).
 *
 * - <title> is managed through `title-tag` so the existing Yoast SEO titles,
 *   descriptions, canonicals, Open Graph and schema keep working unchanged.
 * - When NO SEO plugin is active the theme outputs its own meta description,
 *   canonical (core), robots, Open Graph / Twitter cards and breadcrumbs schema.
 * - A LodgingBusiness/Resort entity is always added on the homepage (Yoast only
 *   outputs Organization/WebSite), linked to the plugin's Organization @id.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/** Is a dedicated SEO plugin handling meta tags? */
function bagus_seo_plugin_active() {
	return apply_filters(
		'bagus_seo_plugin_active',
		defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) || defined( 'AIOSEO_VERSION' ) || defined( 'SEOPRESS_VERSION' ) || defined( 'THE_SEO_FRAMEWORK_VERSION' ) || class_exists( 'Jetpack_SEO' )
	);
}

/** Meta description for the current view. */
function bagus_meta_description() {
	if ( is_singular() ) {
		$post = get_queried_object();
		$desc = has_excerpt( $post ) ? get_the_excerpt( $post ) : wp_trim_words( wp_strip_all_tags( strip_shortcodes( $post->post_content ) ), 30, '…' );
	}
	if ( is_front_page() && 'sections' === get_theme_mod( 'bagus_home_mode', 'sections' ) ) {
		$resort = bagus_data( 'resort' );
		$desc   = ! empty( $resort['paragraphs'][0] ) ? wp_trim_words( $resort['paragraphs'][0], 30, '…' ) : '';
	} elseif ( is_category() || is_tag() || is_tax() ) {
		$desc = term_description();
	}
	if ( empty( $desc ) ) {
		$desc = get_bloginfo( 'description' );
	}
	return trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $desc ) ) );
}

/** Fallback meta tags (only without an SEO plugin). */
add_action(
	'wp_head',
	function () {
		if ( bagus_seo_plugin_active() ) {
			return;
		}
		$desc  = bagus_meta_description();
		$title = wp_get_document_title();
		$url   = is_singular() ? get_permalink() : home_url( add_query_arg( array() ) );
		$img   = '';
		if ( is_singular() && has_post_thumbnail() ) {
			$img = get_the_post_thumbnail_url( null, 'full' );
		} else {
			$hero = bagus_data( 'hero' );
			$img  = bagus_image_attrs( $hero['image_id'] ?? ( $hero['image'] ?? '' ), 'full' )['src'];
		}

		if ( $desc ) {
			printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
		}
		if ( is_search() || is_404() ) {
			echo '<meta name="robots" content="noindex, follow">' . "\n";
		} else {
			echo '<meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">' . "\n";
		}
		if ( is_front_page() && ! is_singular() ) { // Core already prints it for singular views.
			printf( '<link rel="canonical" href="%s">' . "\n", esc_url( home_url( '/' ) ) );
		}
		$og = array(
			'og:locale'      => get_locale(),
			'og:type'        => is_singular( 'post' ) ? 'article' : 'website',
			'og:title'       => $title,
			'og:description' => $desc,
			'og:url'         => $url,
			'og:site_name'   => get_bloginfo( 'name' ),
			'og:image'       => $img,
		);
		foreach ( $og as $p => $v ) {
			if ( $v ) {
				printf( '<meta property="%s" content="%s">' . "\n", esc_attr( $p ), esc_attr( $v ) );
			}
		}
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
	},
	1
);

/** Print a JSON-LD block. */
function bagus_print_jsonld( $data ) {
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>' . "\n";
}

/** Structured data. */
add_action(
	'wp_head',
	function () {
		if ( ! apply_filters( 'bagus_schema_enabled', true ) ) {
			return;
		}

		// LodgingBusiness on the homepage (complements, never duplicates, the SEO plugin's graph).
		if ( is_front_page() ) {
			$brand   = bagus_data( 'brand' );
			$contact = bagus_data( 'contact' );
			$hero    = bagus_data( 'hero' );
			if ( ! empty( $contact['address'] ) || ! empty( $contact['phone'] ) ) {
				$type   = apply_filters( 'bagus_business_type', array( 'Resort', 'LodgingBusiness' ) );
				$schema = array(
					'@context'    => 'https://schema.org',
					'@type'       => $type,
					'@id'         => home_url( '/#lodging' ),
					'name'        => $brand['name'] ?? get_bloginfo( 'name' ),
					'description' => bagus_meta_description(),
					'url'         => home_url( '/' ),
					'image'       => bagus_image_attrs( $hero['image_id'] ?? ( $hero['image'] ?? '' ), 'full' )['src'],
					'telephone'   => $contact['phone'] ?? '',
					'email'       => $contact['emails'][0]['email'] ?? '',
					'address'     => array(
						'@type'           => 'PostalAddress',
						'streetAddress'   => $contact['street'] ?? $contact['address'] ?? '',
						'addressLocality' => $contact['locality'] ?? '',
						'addressRegion'   => $contact['region'] ?? '',
						'postalCode'      => $contact['postal'] ?? '',
						'addressCountry'  => $contact['country'] ?? '',
					),
					'hasMap'      => $contact['map_url'] ?? '',
					'sameAs'      => array_values( array_filter( wp_list_pluck( bagus_data( 'social' ), 'url' ) ) ),
				);
				if ( defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' ) ) {
					$schema['parentOrganization'] = array( '@id' => home_url( '/#organization' ) );
				}
				$villas = bagus_data( 'villas' );
				if ( ! empty( $villas['items'] ) ) {
					foreach ( $villas['items'] as $v ) {
						$schema['containsPlace'][] = array(
							'@type' => 'Accommodation',
							'name'  => $v['name'],
							'url'   => $v['url'],
							'image' => $v['images'][0][0] ?? '',
							'amenityFeature' => array_map(
								fn( $f ) => array( '@type' => 'LocationFeatureSpecification', 'name' => $f, 'value' => true ),
								$v['features']
							),
						);
					}
				}
				bagus_print_jsonld( array_filter( $schema ) );
			}
		}

		// Breadcrumbs only if no SEO plugin already provides them.
		if ( ! bagus_seo_plugin_active() && ! is_front_page() ) {
			$list = array();
			foreach ( bagus_breadcrumb_items() as $i => $item ) {
				$el = array( '@type' => 'ListItem', 'position' => $i + 1, 'name' => $item['name'] );
				if ( $item['url'] ) {
					$el['item'] = $item['url'];
				}
				$list[] = $el;
			}
			bagus_print_jsonld( array( '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => $list ) );
		}
	},
	20
);

/** Strip the generator tag (no version leakage). */
remove_action( 'wp_head', 'wp_generator' );
