<?php
/**
 * Native lead forms (mailing list + download gate) — replaces the old
 * page-builder forms without any plugin. Works without JavaScript
 * (admin-post.php + redirect) and is enhanced with fetch() in app.js.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/** Download files configured in the Customizer. */
function bagus_download_files() {
	$files = array();
	foreach ( array(
		'factsheet' => 'Factsheet',
		'brochure'  => 'E-Brochure',
		'press'     => 'Press Release',
	) as $key => $label ) {
		$url = get_theme_mod( 'bagus_file_' . $key, '' );
		if ( $url ) {
			$files[] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $files;
}

/**
 * Render a lead form.
 *
 * @param string $type newsletter|download.
 * @param string $id   Unique id prefix.
 */
function bagus_lead_form( $type = 'newsletter', $id = 'lead' ) {
	$status = isset( $_GET['bagus_lead'] ) ? sanitize_key( wp_unslash( $_GET['bagus_lead'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	?>
	<form class="lead-form lead-form--<?php echo esc_attr( $type ); ?>" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" data-lead-form data-ajax="<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>">
		<input type="hidden" name="action" value="bagus_lead">
		<input type="hidden" name="type" value="<?php echo esc_attr( $type ); ?>">
		<input type="hidden" name="back" value="<?php echo esc_url( home_url( add_query_arg( array() ) ) ); ?>">
		<?php wp_nonce_field( 'bagus_lead', '_bagus_nonce' ); ?>
		<div class="hp" aria-hidden="true"><label>Website <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
		<?php if ( 'contact' === $type ) : ?>
			<div class="field-grid">
				<p class="field"><label for="<?php echo esc_attr( $id ); ?>-name"><?php esc_html_e( 'Name', 'bagus' ); ?></label><input id="<?php echo esc_attr( $id ); ?>-name" type="text" name="name" required autocomplete="name"></p>
				<p class="field"><label for="<?php echo esc_attr( $id ); ?>-email"><?php esc_html_e( 'Email', 'bagus' ); ?></label><input id="<?php echo esc_attr( $id ); ?>-email" type="email" name="email" required autocomplete="email" inputmode="email"></p>
				<p class="field field--full"><label for="<?php echo esc_attr( $id ); ?>-subject"><?php esc_html_e( 'Subject', 'bagus' ); ?></label>
					<select id="<?php echo esc_attr( $id ); ?>-subject" name="subject">
						<?php foreach ( apply_filters( 'bagus_contact_subjects', array( __( 'General Information', 'bagus' ), __( 'Reservation', 'bagus' ), __( 'Wedding & Event', 'bagus' ), __( 'Group Retreat', 'bagus' ) ) ) as $subject ) : ?>
							<option><?php echo esc_html( $subject ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p class="field field--full"><label for="<?php echo esc_attr( $id ); ?>-message"><?php esc_html_e( 'Message', 'bagus' ); ?></label><textarea id="<?php echo esc_attr( $id ); ?>-message" name="message" rows="6" required></textarea></p>
			</div>
			<button type="submit" class="btn btn--primary"><span><?php esc_html_e( 'Send Message', 'bagus' ); ?></span><?php echo bagus_icon( 'arrow-right' ); // phpcs:ignore ?></button>
		<?php else : ?>
			<label class="sr-only" for="<?php echo esc_attr( $id ); ?>-email"><?php esc_html_e( 'Email', 'bagus' ); ?></label>
			<div class="lead-form__row">
				<input id="<?php echo esc_attr( $id ); ?>-email" type="email" name="email" required autocomplete="email" inputmode="email" placeholder="<?php esc_attr_e( 'Email', 'bagus' ); ?>">
				<button type="submit" class="btn btn--primary"><span><?php echo 'newsletter' === $type ? esc_html__( 'Join', 'bagus' ) : esc_html__( 'Submit', 'bagus' ); ?></span></button>
			</div>
		<?php endif; ?>
		<p class="lead-form__msg" role="status" aria-live="polite"><?php
		if ( 'ok' === $status ) {
			esc_html_e( 'Thank you! Your e-mail has been received.', 'bagus' );
		} elseif ( 'error' === $status ) {
			esc_html_e( 'Please enter a valid e-mail address.', 'bagus' );
		}
		?></p>
		<?php if ( 'download' === $type ) : ?>
			<ul class="lead-form__files" <?php echo 'ok' === $status ? '' : 'hidden'; ?>>
				<?php foreach ( bagus_download_files() as $file ) : ?>
					<li><a class="btn btn--ghost" href="<?php echo esc_url( $file['url'] ); ?>" download target="_blank" rel="noopener"><?php echo bagus_icon( 'download' ); // phpcs:ignore ?><span><?php echo esc_html( $file['label'] ); ?></span></a></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</form>
	<?php
}

/**
 * Handle a submission. Returns [ok(bool), message(string)].
 *
 * @return array
 */
function bagus_handle_lead() {
	// Nonces are only meaningful for logged-in users; for visitors they would break
	// behind page caches, so visitors are protected by the honeypot + rate limit.
	if ( is_user_logged_in() && ( ! isset( $_POST['_bagus_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_bagus_nonce'] ) ), 'bagus_lead' ) ) ) {
		return array( false, __( 'Session expired, please reload the page.', 'bagus' ) );
	}
	if ( ! empty( $_POST['website'] ) ) { // Honeypot.
		return array( true, '' );
	}
	$email = isset( $_POST['email'] ) ? sanitize_email( wp_unslash( $_POST['email'] ) ) : '';
	$type  = isset( $_POST['type'] ) && in_array( $_POST['type'], array( 'download', 'contact' ), true ) ? sanitize_key( $_POST['type'] ) : 'newsletter';
	$name  = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
	$subj  = isset( $_POST['subject'] ) ? sanitize_text_field( wp_unslash( $_POST['subject'] ) ) : '';
	$msg   = isset( $_POST['message'] ) ? sanitize_textarea_field( wp_unslash( $_POST['message'] ) ) : '';
	if ( ! is_email( $email ) ) {
		return array( false, __( 'Please enter a valid e-mail address.', 'bagus' ) );
	}

	// Simple rate limit per IP.
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'bagus_lead_' . md5( $ip );
	if ( (int) get_transient( $key ) > 5 ) {
		return array( false, __( 'Too many attempts, please try again later.', 'bagus' ) );
	}
	set_transient( $key, (int) get_transient( $key ) + 1, HOUR_IN_SECONDS );

	$leads   = get_option( 'bagus_leads', array() );
	$leads   = is_array( $leads ) ? $leads : array();
	$leads[] = array( 'email' => $email, 'type' => $type, 'date' => current_time( 'mysql' ), 'name' => $name, 'subject' => $subj, 'message' => $msg );
	update_option( 'bagus_leads', array_slice( $leads, -2000 ), false );

	$to = get_theme_mod( 'bagus_leads_email', '' );
	wp_mail(
		$to ? $to : get_option( 'admin_email' ),
		/* translators: 1: site name, 2: form type */
		sprintf( __( '[%1$s] New %2$s sign-up', 'bagus' ), get_bloginfo( 'name' ), $type ),
		/* translators: %s: email */
		sprintf( __( "E-mail: %s\nForm: %s\nPage: %s", 'bagus' ), $email, $type, isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : '' )
			. ( $name ? "\nName: " . $name : '' ) . ( $subj ? "\nSubject: " . $subj : '' ) . ( $msg ? "\n\n" . $msg : '' ),
		array( 'Reply-To: ' . ( $name ? $name . ' ' : '' ) . '<' . $email . '>' )
	);

	if ( 'contact' === $type ) {
		return array( true, __( 'Thank you! Your message has been sent. We will get back to you as soon as possible.', 'bagus' ) );
	}
	return array( true, 'download' === $type ? __( 'Thank you! Your downloads are ready below.', 'bagus' ) : __( 'Thank you! Your e-mail has been received.', 'bagus' ) );
}

/** No-JS submit. */
function bagus_lead_post() {
	list( $ok ) = bagus_handle_lead();
	$back       = isset( $_POST['back'] ) ? esc_url_raw( wp_unslash( $_POST['back'] ) ) : home_url( '/' ); // phpcs:ignore WordPress.Security.NonceVerification
	$anchor     = array( 'download' => '#downloads', 'contact' => '#contact-form-title' )[ sanitize_key( $_POST['type'] ?? '' ) ] ?? '#newsletter'; // phpcs:ignore
	wp_safe_redirect( add_query_arg( 'bagus_lead', $ok ? 'ok' : 'error', $back ) . $anchor );
	exit;
}
add_action( 'admin_post_bagus_lead', 'bagus_lead_post' );
add_action( 'admin_post_nopriv_bagus_lead', 'bagus_lead_post' );

/** fetch() submit. */
function bagus_lead_ajax() {
	list( $ok, $msg ) = bagus_handle_lead();
	$files            = ( $ok && isset( $_POST['type'] ) && 'download' === $_POST['type'] ) ? bagus_download_files() : array(); // phpcs:ignore WordPress.Security.NonceVerification
	wp_send_json( array( 'ok' => $ok, 'message' => $msg, 'files' => $files ), $ok ? 200 : 400 );
}
add_action( 'wp_ajax_bagus_lead', 'bagus_lead_ajax' );
add_action( 'wp_ajax_nopriv_bagus_lead', 'bagus_lead_ajax' );

/** Tools → Bagus leads (view + CSV export). */
add_action(
	'admin_menu',
	function () {
		add_management_page(
			__( 'Bagus leads', 'bagus' ),
			__( 'Bagus leads', 'bagus' ),
			'manage_options',
			'bagus-leads',
			function () {
				$leads = array_reverse( (array) get_option( 'bagus_leads', array() ) );
				echo '<div class="wrap"><h1>' . esc_html__( 'Bagus leads', 'bagus' ) . '</h1>';
				$csv = 'email,type,date' . "\n";
				foreach ( $leads as $l ) {
					$csv .= sprintf( "%s,%s,%s\n", $l['email'], $l['type'], $l['date'] );
				}
				echo '<p><a class="button" download="leads.csv" href="data:text/csv;charset=utf-8,' . rawurlencode( $csv ) . '">' . esc_html__( 'Export CSV', 'bagus' ) . '</a></p>';
				echo '<table class="widefat striped"><thead><tr><th>Email</th><th>Form</th><th>Date</th><th>Name</th><th>Message</th></tr></thead><tbody>';
				foreach ( $leads as $l ) {
					printf( '<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>', esc_html( $l['email'] ), esc_html( $l['type'] ), esc_html( $l['date'] ), esc_html( $l['name'] ?? '' ), esc_html( trim( ( $l['subject'] ?? '' ) . ' ' . ( $l['message'] ?? '' ) ) ) );
				}
				echo '</tbody></table></div>';
			}
		);
	}
);

/** [bagus_contact_form subject="Wedding"] — native contact form anywhere in content. */
add_shortcode(
	'bagus_contact_form',
	function ( $atts ) {
		static $n = 0;
		$n++;
		$atts = shortcode_atts( array( 'subject' => '' ), $atts, 'bagus_contact_form' );
		if ( $atts['subject'] ) {
			$subject = sanitize_text_field( $atts['subject'] );
			add_filter( 'bagus_contact_subjects', $f = function ( $list ) use ( $subject ) {
				return array_values( array_unique( array_merge( array( $subject ), $list ) ) );
			} );
		}
		ob_start();
		echo '<div class="contact-form-card contact-form-card--inline">';
		bagus_lead_form( 'contact', 'cf' . $n );
		echo '</div>';
		if ( isset( $f ) ) {
			remove_filter( 'bagus_contact_subjects', $f );
		}
		return ob_get_clean();
	}
);
