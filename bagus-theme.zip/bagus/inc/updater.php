<?php
/**
 * Theme self-update.
 *
 * Reads theme-update.json from the public GitHub repository arimpranata/bagus-design-system:
 *   { "version": "1.2.0", "download_url": "https://…/bagus-theme.zip", "requires": "6.4", "requires_php": "7.4" }
 * When "version" is newer, WordPress shows "Update available" under Appearance → Themes and can install it
 * (automatically when the theme's auto-update toggle is on). Override with define( 'BAGUS_THEME_UPDATE_URL', … ).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

if ( ! defined( 'BAGUS_THEME_UPDATE_URL' ) ) {
	define( 'BAGUS_THEME_UPDATE_URL', 'https://raw.githubusercontent.com/arimpranata/bagus-design-system/main/theme-update.json' );
}

/**
 * Update info, cached 6 h (a failed check is cached 1 h).
 *
 * @param bool $force Skip the cache.
 * @return array|null
 */
function bagus_theme_remote_info( $force = false ) {
	$key = 'bagus_theme_update_info';
	if ( ! $force ) {
		$cached = get_site_transient( $key );
		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : null;
		}
	}
	$res  = wp_remote_get( BAGUS_THEME_UPDATE_URL, array( 'timeout' => 8 ) );
	$info = null;
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$d = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $d ) && ! empty( $d['version'] ) && ! empty( $d['download_url'] )
			&& preg_match( '/^\d+(\.\d+){0,3}$/', (string) $d['version'] ) && 0 === strpos( (string) $d['download_url'], 'https://' ) ) {
			$info = array(
				'version'      => (string) $d['version'],
				'download_url' => esc_url_raw( (string) $d['download_url'] ),
				'requires'     => isset( $d['requires'] ) ? sanitize_text_field( (string) $d['requires'] ) : '',
				'requires_php' => isset( $d['requires_php'] ) ? sanitize_text_field( (string) $d['requires_php'] ) : '',
			);
		}
	}
	set_site_transient( $key, $info ? $info : 'none', $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $info;
}

add_filter( 'pre_set_site_transient_update_themes', 'bagus_theme_check_update' );
/**
 * Tell WordPress about a newer theme version.
 *
 * @param object $transient Update transient.
 * @return object
 */
function bagus_theme_check_update( $transient ) {
	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}
	$slug = get_template();
	$cur  = wp_get_theme( $slug )->get( 'Version' );
	$info = bagus_theme_remote_info();
	$item = array(
		'theme'        => $slug,
		'new_version'  => $info ? $info['version'] : $cur,
		'url'          => 'https://github.com/arimpranata/Bagus-Theme',
		'package'      => $info ? $info['download_url'] : '',
		'requires'     => $info ? $info['requires'] : '',
		'requires_php' => $info ? $info['requires_php'] : '',
	);
	if ( $info && version_compare( $info['version'], $cur, '>' ) ) {
		$transient->response[ $slug ] = $item;
		unset( $transient->no_update[ $slug ] );
	} else {
		$transient->no_update[ $slug ] = $item; // shows the auto-update toggle
		unset( $transient->response[ $slug ] );
	}
	return $transient;
}

add_filter( 'upgrader_source_selection', 'bagus_theme_fix_source_dir', 10, 4 );
/**
 * Keep the theme folder name whatever the zip's top folder is called.
 *
 * @param string $source        Unpacked source.
 * @param string $remote_source Remote source.
 * @param object $upgrader      Upgrader.
 * @param array  $hook_extra    Extra.
 * @return string|WP_Error
 */
function bagus_theme_fix_source_dir( $source, $remote_source, $upgrader, $hook_extra = array() ) {
	global $wp_filesystem;
	if ( empty( $hook_extra['theme'] ) || get_template() !== $hook_extra['theme'] || ! $wp_filesystem ) {
		return $source;
	}
	$wanted = trailingslashit( $remote_source ) . get_template() . '/';
	if ( untrailingslashit( $source ) === untrailingslashit( $wanted ) ) {
		return $source;
	}
	return $wp_filesystem->move( $source, $wanted, true ) ? $wanted : new WP_Error( 'bagus_rename', 'Bagus theme: could not rename the update folder.' );
}

add_action( 'upgrader_process_complete', 'bagus_theme_clear_update_cache' );
/** Fresh check after any update. */
function bagus_theme_clear_update_cache() {
	delete_site_transient( 'bagus_theme_update_info' );
}
