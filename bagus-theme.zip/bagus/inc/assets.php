<?php
/**
 * Front-end assets: design tokens, fonts, CSS and the motion library.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/**
 * Font choices offered in the Customizer (Google Fonts families).
 *
 * @return array<string,array{0:string,1:string}> key => [CSS family stack, Google query]
 */
function bagus_fonts() {
	return apply_filters(
		'bagus_fonts',
		array(
			'cormorant'  => array( '"Cormorant Garamond", Georgia, serif', 'Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400' ),
			'cinzel'     => array( 'Cinzel, "Times New Roman", serif', 'Cinzel:wght@400;500;600;700' ),
			'fraunces'   => array( 'Fraunces, Georgia, serif', 'Fraunces:opsz,wght@9..144,300..600' ),
			'playfair'   => array( '"Playfair Display", Georgia, serif', 'Playfair+Display:ital,wght@0,400..700;1,400' ),
			'dm-serif'   => array( '"DM Serif Display", Georgia, serif', 'DM+Serif+Display:ital@0;1' ),
			'jost'       => array( 'Jost, system-ui, sans-serif', 'Jost:wght@300..600' ),
			'manrope'    => array( 'Manrope, system-ui, sans-serif', 'Manrope:wght@300..700' ),
			'montserrat' => array( 'Montserrat, system-ui, sans-serif', 'Montserrat:wght@300..600' ),
			'inter'      => array( 'Inter, system-ui, sans-serif', 'Inter:wght@300..700' ),
			'system'     => array( 'system-ui, -apple-system, "Segoe UI", Roboto, sans-serif', '' ),
		)
	);
}

/**
 * Colour tokens from the Customizer.
 *
 * @return array<string,string>
 */
function bagus_colors() {
	$defaults = array(
		'primary'   => '#5e6c37', // Jungle green (buttons, icon tiles, headings).
		'secondary' => '#7a5a3a', // Teak brown (header, kickers).
		'accent'    => '#c4a168', // Temple gold (dividers, highlights).
		'ink'       => '#2b2824', // Text.
		'surface'   => '#f8f5ef', // Rice-paper background.
		'dark'      => '#2a2b28', // Charcoal (footer, dark bands).
	);
	// The active preset may bring its own colours (Customizer values still win).
	$preset_colors = function_exists( 'bagus_data' ) ? (array) bagus_data( 'colors' ) : array();
	foreach ( $preset_colors as $k => $v ) {
		if ( isset( $defaults[ $k ] ) && sanitize_hex_color( $v ) ) {
			$defaults[ $k ] = $v;
		}
	}
	$out = array();
	foreach ( $defaults as $k => $v ) {
		$val       = sanitize_hex_color( get_theme_mod( 'bagus_color_' . $k, $v ) );
		$out[ $k ] = $val ? $val : $v;
	}
	return apply_filters( 'bagus_colors', $out );
}

/** Google Fonts URL for the selected pair (or empty string for system fonts). */
function bagus_fonts_url() {
	$fonts    = bagus_fonts();
	$families = array();
	foreach ( array( get_theme_mod( 'bagus_font_heading', 'cinzel' ), get_theme_mod( 'bagus_font_body', 'jost' ) ) as $key ) {
		if ( isset( $fonts[ $key ] ) && $fonts[ $key ][1] ) {
			$families[] = 'family=' . $fonts[ $key ][1];
		}
	}
	if ( ! $families ) {
		return '';
	}
	return 'https://fonts.googleapis.com/css2?' . implode( '&', array_unique( $families ) ) . '&display=swap';
}

/** Inline :root tokens. Everything else in main.css derives from these. */
function bagus_tokens_css() {
	$c     = bagus_colors();
	$fonts = bagus_fonts();
	$h     = $fonts[ get_theme_mod( 'bagus_font_heading', 'cinzel' ) ][0] ?? $fonts['cinzel'][0];
	$b     = $fonts[ get_theme_mod( 'bagus_font_body', 'jost' ) ][0] ?? $fonts['jost'][0];
	$r     = absint( get_theme_mod( 'bagus_radius', 6 ) );

	return sprintf(
		':root{--c-primary:%1$s;--c-accent:%2$s;--c-ink:%3$s;--c-surface:%4$s;--c-dark:%5$s;--f-head:%6$s;--f-body:%7$s;--radius:%8$dpx;--c-secondary:%9$s;' .
		'--wp--preset--color--primary:var(--c-primary);--wp--preset--color--accent:var(--c-accent);--wp--preset--color--ink:var(--c-ink);--wp--preset--color--surface:var(--c-surface);--wp--preset--color--dark:var(--c-dark)}',
		$c['primary'],
		$c['accent'],
		$c['ink'],
		$c['surface'],
		$c['dark'],
		$h,
		$b,
		$r,
		$c['secondary']
	);
}

add_action(
	'wp_enqueue_scripts',
	function () {
		$fonts_url = bagus_fonts_url();
		if ( $fonts_url ) {
			wp_enqueue_style( 'bagus-fonts', $fonts_url, array(), null ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
		}

		$css = BAGUS_DIR . '/assets/css/main.css';
		wp_enqueue_style( 'bagus', BAGUS_URI . '/assets/css/main.css?b=' . ( file_exists( $css ) ? filemtime( $css ) : BAGUS_VERSION ), array(), BAGUS_VERSION . '.' . ( file_exists( $css ) ? filemtime( $css ) : '' ) );
		wp_add_inline_style( 'bagus', bagus_tokens_css() );

		// One bundled file (assets/js/app.min.js, built from app.js + lib/*.js with
		// `npx esbuild assets/js/app.js --bundle --minify --format=esm --outfile=assets/js/app.min.js`).
		// Separate module imports carry no version, so hosts/CDNs kept serving stale copies after updates.
		$js_file = file_exists( BAGUS_DIR . '/assets/js/app.min.js' ) ? 'app.min.js' : 'app.js';
		$js      = BAGUS_DIR . '/assets/js/' . $js_file;
		wp_enqueue_script_module(
			'bagus-app',
			BAGUS_URI . '/assets/js/' . $js_file . '?b=' . ( file_exists( $js ) ? filemtime( $js ) : BAGUS_VERSION ),
			array(),
			BAGUS_VERSION . '.' . ( file_exists( $js ) ? filemtime( $js ) : '' )
		);

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		// The theme does not need jQuery / block library on the front page sections.
		if ( is_front_page() && 'sections' === get_theme_mod( 'bagus_home_mode', 'sections' ) ) {
			wp_dequeue_style( 'wp-block-library' );
			wp_dequeue_style( 'wp-block-library-theme' );
			wp_dequeue_style( 'global-styles' );
			wp_dequeue_style( 'classic-theme-styles' );
		}
	},
	20
);

/** Older WP (< 6.5) without the Script Modules API: print a module tag manually. */
if ( ! function_exists( 'wp_enqueue_script_module' ) ) {
	function wp_enqueue_script_module( $id, $src, $deps = array(), $ver = false ) { // phpcs:ignore
		add_action(
			'wp_footer',
			function () use ( $src, $ver ) {
				printf( '<script type="module" src="%s"></script>' . "\n", esc_url( add_query_arg( 'ver', $ver, $src ) ) );
			},
			99
		);
	}
}

/**
 * Flag JS early so reveal states never flash; if the module fails to boot
 * within 3.5s everything is revealed (content is never stuck hidden).
 */
add_action(
	'wp_head',
	function () {
		echo "<script>document.documentElement.classList.add('js');setTimeout(function(){if(!window.bagusReady)document.documentElement.classList.add('reveal-all')},3500)</script>\n";
	},
	0
);

/** Resource hints + LCP hero preload (Core Web Vitals). */
add_action(
	'wp_head',
	function () {
		if ( bagus_fonts_url() ) {
			echo '<link rel="preconnect" href="https://fonts.googleapis.com">' . "\n";
			echo '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
		}
		$theme = bagus_colors()['primary'];
		printf( '<meta name="theme-color" content="%s">' . "\n", esc_attr( $theme ) );

		if ( is_front_page() && 'sections' === get_theme_mod( 'bagus_home_mode', 'sections' ) ) {
			$hero = bagus_data( 'hero' );
			$img  = bagus_image_attrs( $hero['image_id'] ?? ( $hero['image'] ?? '' ), 'full' );
			if ( $img['src'] ) {
				printf(
					'<link rel="preload" as="image" href="%s"%s%s fetchpriority="high">' . "\n",
					esc_url( $img['src'] ),
					$img['srcset'] ? ' imagesrcset="' . esc_attr( $img['srcset'] ) . '"' : '',
					$img['srcset'] ? ' imagesizes="100vw"' : ''
				);
			}
		}
	},
	2
);

/** Tag the Google Fonts stylesheet so it doesn't block rendering on slow links. */
add_filter(
	'style_loader_tag',
	function ( $html, $handle ) {
		if ( 'bagus-fonts' === $handle ) {
			$html = str_replace( "media='all'", "media='print' onload=\"this.media='all'\"", $html );
			$html .= '<noscript>' . str_replace( array( "media='print' onload=\"this.media='all'\"" ), "media='all'", $html ) . '</noscript>';
		}
		return $html;
	},
	10,
	2
);

/** Editor: same tokens so blocks preview with the brand colours. */
add_action(
	'enqueue_block_editor_assets',
	function () {
		$fonts_url = bagus_fonts_url();
		if ( $fonts_url ) {
			wp_enqueue_style( 'bagus-editor-fonts', $fonts_url, array(), null ); // phpcs:ignore
		}
		wp_register_style( 'bagus-editor-tokens', false, array(), BAGUS_VERSION );
		wp_enqueue_style( 'bagus-editor-tokens' );
		wp_add_inline_style( 'bagus-editor-tokens', bagus_tokens_css() );
	}
);
