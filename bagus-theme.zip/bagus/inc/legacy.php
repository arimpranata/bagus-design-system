<?php
/**
 * Clean break from the old page builder.
 *
 * The theme never loads, extends or restyles code from the previous theme or
 * Elementor. If Elementor / its add-ons are still active while migrating, their
 * front-end CSS & JS are kept off the page (Customizer → Bagus → Performance)
 * so they cannot fight the new design or slow it down.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/** Handle prefixes that belong to page builders / their add-ons. */
function bagus_builder_handle_prefixes() {
	return apply_filters(
		'bagus_builder_handle_prefixes',
		array( 'elementor', 'e-', 'swiper', 'happy', 'ha-', 'qi-addons', 'she-header', 'ucaddon', 'unlimited-elements', 'font-awesome', 'hello-elementor', 'bagus-design-system', 'eael', 'jet-' )
	);
}

add_action(
	'wp_enqueue_scripts',
	function () {
		if ( is_admin() || ! get_theme_mod( 'bagus_strip_builder_assets', true ) ) {
			return;
		}
		if ( isset( $_GET['elementor-preview'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}
		$prefixes = bagus_builder_handle_prefixes();
		foreach ( array( wp_styles(), wp_scripts() ) as $deps ) {
			foreach ( (array) $deps->queue as $handle ) {
				foreach ( $prefixes as $p ) {
					if ( 0 === strpos( $handle, $p ) ) {
						$deps instanceof WP_Styles ? wp_dequeue_style( $handle ) : wp_dequeue_script( $handle );
						break;
					}
				}
			}
		}
	},
	9999
);

/**
 * When the builder plugin is deactivated, its pages fall back to the HTML saved
 * in post_content. Strip the builder's wrapper attributes so the theme's
 * typography (.prose) styles that content cleanly.
 */
add_filter(
	'the_content',
	function ( $html ) {
		if ( false === strpos( $html, 'elementor' ) || did_action( 'elementor/loaded' ) ) {
			return $html;
		}
		$html = preg_replace( '/\s(?:data-(?:id|element_type|e-type|settings|widget_type|elementor-[a-z-]+))="[^"]*"/i', '', $html );
		$html = preg_replace( '/\sclass="[^"]*\belementor[^"]*"/i', '', $html );
		return $html;
	},
	20
);
