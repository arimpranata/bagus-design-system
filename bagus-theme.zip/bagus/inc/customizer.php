<?php
/**
 * Customizer: brand colours, typography, content preset, contact info,
 * homepage sections and downloads. Everything is optional — sensible
 * defaults come from the active preset.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'customize_register',
	function ( WP_Customize_Manager $wp ) {

		$wp->add_panel( 'bagus', array( 'title' => __( 'Bagus Theme', 'bagus' ), 'priority' => 25 ) );

		/* ---------- Colours ---------- */
		$wp->add_section( 'bagus_colors', array( 'title' => __( 'Colours', 'bagus' ), 'panel' => 'bagus' ) );
		$colors = array(
			'primary'   => array( __( 'Primary (buttons, icon tiles, headings)', 'bagus' ), '#5e6c37' ),
			'secondary' => array( __( 'Secondary (header, kickers)', 'bagus' ), '#7a5a3a' ),
			'accent'    => array( __( 'Accent (dividers, highlights)', 'bagus' ), '#c4a168' ),
			'ink'       => array( __( 'Text', 'bagus' ), '#2b2824' ),
			'surface'   => array( __( 'Background', 'bagus' ), '#f8f5ef' ),
			'dark'      => array( __( 'Dark sections & footer', 'bagus' ), '#2a2b28' ),
		);
		foreach ( $colors as $key => $c ) {
			$pc = (array) bagus_data( 'colors' );
			$wp->add_setting( 'bagus_color_' . $key, array( 'default' => isset( $pc[ $key ] ) ? $pc[ $key ] : $c[1], 'sanitize_callback' => 'sanitize_hex_color' ) );
			$wp->add_control( new WP_Customize_Color_Control( $wp, 'bagus_color_' . $key, array( 'label' => $c[0], 'section' => 'bagus_colors' ) ) );
		}
		$wp->add_setting( 'bagus_radius', array( 'default' => 6, 'sanitize_callback' => 'absint' ) );
		$wp->add_control( 'bagus_radius', array( 'label' => __( 'Corner radius (px)', 'bagus' ), 'section' => 'bagus_colors', 'type' => 'range', 'input_attrs' => array( 'min' => 0, 'max' => 32 ) ) );

		/* ---------- Typography ---------- */
		$wp->add_section( 'bagus_type', array( 'title' => __( 'Typography', 'bagus' ), 'panel' => 'bagus' ) );
		$choices = array();
		foreach ( bagus_fonts() as $key => $f ) {
			$choices[ $key ] = ucwords( str_replace( '-', ' ', $key ) );
		}
		$wp->add_setting( 'bagus_font_heading', array( 'default' => 'cinzel', 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control( 'bagus_font_heading', array( 'label' => __( 'Heading font', 'bagus' ), 'section' => 'bagus_type', 'type' => 'select', 'choices' => $choices ) );
		$wp->add_setting( 'bagus_font_body', array( 'default' => 'jost', 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control( 'bagus_font_body', array( 'label' => __( 'Body font', 'bagus' ), 'section' => 'bagus_type', 'type' => 'select', 'choices' => $choices ) );

		/* ---------- Content & homepage ---------- */
		$wp->add_section( 'bagus_home', array( 'title' => __( 'Homepage & content preset', 'bagus' ), 'panel' => 'bagus' ) );
		$presets = array( '' => __( 'Blank', 'bagus' ) );
		foreach ( bagus_presets() as $slug => $file ) {
			$presets[ $slug ] = ucwords( str_replace( array( '-', '_' ), ' ', $slug ) );
		}
		$wp->add_setting( 'bagus_preset', array( 'default' => bagus_default_preset(), 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control( 'bagus_preset', array( 'label' => __( 'Content preset', 'bagus' ), 'description' => __( 'Texts, images and links for the homepage sections, footer and fallback menu.', 'bagus' ), 'section' => 'bagus_home', 'type' => 'select', 'choices' => $presets ) );

		$wp->add_setting( 'bagus_home_mode', array( 'default' => 'sections', 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control(
			'bagus_home_mode',
			array(
				'label'   => __( 'Homepage layout', 'bagus' ),
				'section' => 'bagus_home',
				'type'    => 'radio',
				'choices' => array(
					'sections' => __( 'Theme sections (from preset)', 'bagus' ),
					'content'  => __( 'Page content (block editor)', 'bagus' ),
				),
			)
		);

		$sections = array(
			'hero'       => __( 'Hero', 'bagus' ),
			'quicklinks' => __( 'Quick links', 'bagus' ),
			'booking'    => __( 'Booking bar', 'bagus' ),
			'resort'     => __( 'About / The Resort', 'bagus' ),
			'villas'     => __( 'Villas / Rooms', 'bagus' ),
			'retreat'    => __( 'Group Retreat', 'bagus' ),
			'packages'   => __( 'Packages', 'bagus' ),
			'farm'       => __( 'Organic Farm', 'bagus' ),
			'wedding'    => __( 'Wedding & Event', 'bagus' ),
			'reviews'    => __( 'Guest reviews', 'bagus' ),
			'discovery'  => __( 'Sister properties (footer)', 'bagus' ),
			'welcome'    => __( 'Welcome / promo sheet', 'bagus' ),
		);
		foreach ( $sections as $key => $label ) {
			$wp->add_setting( 'bagus_show_' . $key, array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
			/* translators: %s: section name */
			$wp->add_control( 'bagus_show_' . $key, array( 'label' => sprintf( __( 'Show: %s', 'bagus' ), $label ), 'section' => 'bagus_home', 'type' => 'checkbox' ) );
		}

		$wp->add_setting( 'bagus_welcome_trigger', array( 'default' => 'scroll', 'sanitize_callback' => 'sanitize_key' ) );
		$wp->add_control(
			'bagus_welcome_trigger',
			array(
				'label'   => __( 'Welcome / promo popup appears', 'bagus' ),
				'section' => 'bagus_home',
				'type'    => 'radio',
				'choices' => array(
					'scroll' => __( 'After the visitor scrolls 30% (recommended for SEO)', 'bagus' ),
					'delay'  => __( 'A few seconds after the page opens', 'bagus' ),
				),
			)
		);

		/* ---------- Hero ---------- */
		$wp->add_section( 'bagus_hero', array( 'title' => __( 'Hero', 'bagus' ), 'panel' => 'bagus' ) );
		$wp->add_setting( 'bagus_hero_image', array( 'default' => 0, 'sanitize_callback' => 'absint' ) );
		$wp->add_control( new WP_Customize_Media_Control( $wp, 'bagus_hero_image', array( 'label' => __( 'Hero image (overrides preset)', 'bagus' ), 'section' => 'bagus_hero', 'mime_type' => 'image' ) ) );
		foreach ( array(
			'bagus_hero_title'    => __( 'Title (H1)', 'bagus' ),
			'bagus_hero_subtitle' => __( 'Subtitle', 'bagus' ),
			'bagus_hero_location' => __( 'Location line', 'bagus' ),
			'bagus_hero_motto'    => __( 'Motto (marquee)', 'bagus' ),
		) as $id => $label ) {
			$wp->add_setting( $id, array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
			$wp->add_control( $id, array( 'label' => $label, 'section' => 'bagus_hero', 'type' => 'text', 'description' => __( 'Leave empty to use the preset.', 'bagus' ) ) );
		}

		$wp->add_setting( 'bagus_hero_video', array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
		$wp->add_control( 'bagus_hero_video', array( 'label' => __( 'Hero background video (YouTube link or .mp4 URL)', 'bagus' ), 'description' => __( 'Plays muted and looped behind the hero; the hero image is shown first and on slow connections. An uploaded MP4 loads faster than YouTube.', 'bagus' ), 'section' => 'bagus_hero', 'type' => 'url' ) );

		/* ---------- Contact & booking ---------- */
		$wp->add_section( 'bagus_contact', array( 'title' => __( 'Contact & booking', 'bagus' ), 'panel' => 'bagus', 'description' => __( 'Leave empty to use the preset values.', 'bagus' ) ) );
		$fields = array(
			'bagus_reserve_url'    => array( __( 'Reserve Now URL', 'bagus' ), 'esc_url_raw' ),
			'bagus_booking_action' => array( __( 'Booking engine URL (availability form)', 'bagus' ), 'esc_url_raw' ),
			'bagus_whatsapp_url'   => array( __( 'WhatsApp URL', 'bagus' ), 'esc_url_raw' ),
			'bagus_map_url'        => array( __( 'Map / directions URL', 'bagus' ), 'esc_url_raw' ),
			'bagus_contact_url'    => array( __( 'Contact page URL', 'bagus' ), 'esc_url_raw' ),
			'bagus_tour_url'       => array( __( 'Virtual tour URL', 'bagus' ), 'esc_url_raw' ),
			'bagus_phone'          => array( __( 'Phone (E.164, e.g. +62361901888)', 'bagus' ), 'sanitize_text_field' ),
			'bagus_phone_label'    => array( __( 'Phone (display)', 'bagus' ), 'sanitize_text_field' ),
			'bagus_address'        => array( __( 'Address', 'bagus' ), 'sanitize_text_field' ),
		);
		foreach ( $fields as $id => $f ) {
			$wp->add_setting( $id, array( 'default' => '', 'sanitize_callback' => $f[1] ) );
			$wp->add_control( $id, array( 'label' => $f[0], 'section' => 'bagus_contact', 'type' => 'esc_url_raw' === $f[1] ? 'url' : 'text' ) );
		}

		$wp->add_setting( 'bagus_footer_credit', array( 'default' => '', 'sanitize_callback' => 'sanitize_text_field' ) );
		$wp->add_control( 'bagus_footer_credit', array( 'label' => __( 'Footer credit (bottom right)', 'bagus' ), 'section' => 'bagus_contact', 'type' => 'text', 'description' => __( 'Leave empty to use the preset.', 'bagus' ) ) );

		/* ---------- Downloads (Factsheet / E-Brochure / Press Release) ---------- */
		$wp->add_section( 'bagus_downloads', array( 'title' => __( 'Downloads & leads', 'bagus' ), 'panel' => 'bagus', 'description' => __( 'Files revealed after a visitor leaves their e-mail. Leads are e-mailed to the address below and listed under Tools → Bagus leads.', 'bagus' ) ) );
		foreach ( array(
			'factsheet' => 'Factsheet',
			'brochure'  => 'E-Brochure',
			'press'     => 'Press Release',
		) as $key => $label ) {
			$wp->add_setting( 'bagus_file_' . $key, array( 'default' => '', 'sanitize_callback' => 'esc_url_raw' ) );
			$wp->add_control( 'bagus_file_' . $key, array( 'label' => $label . ' URL', 'section' => 'bagus_downloads', 'type' => 'url' ) );
		}
		$wp->add_setting( 'bagus_leads_email', array( 'default' => '', 'sanitize_callback' => 'sanitize_email' ) );
		$wp->add_control( 'bagus_leads_email', array( 'label' => __( 'Send leads to (defaults to admin e-mail)', 'bagus' ), 'section' => 'bagus_downloads', 'type' => 'email' ) );

		/* ---------- Performance ---------- */
		$wp->add_section( 'bagus_perf', array( 'title' => __( 'Performance', 'bagus' ), 'panel' => 'bagus' ) );
		$wp->add_setting( 'bagus_strip_builder_assets', array( 'default' => true, 'sanitize_callback' => 'wp_validate_boolean' ) );
		$wp->add_control( 'bagus_strip_builder_assets', array( 'label' => __( 'Do not load leftover page-builder CSS/JS (Elementor & add-ons) on the front end', 'bagus' ), 'section' => 'bagus_perf', 'type' => 'checkbox' ) );
	}
);

/** Clear cached image lookups when the Customizer is saved or the theme changes. */
add_action( 'customize_save_after', fn() => delete_transient( 'bagus_img_map' ) );
add_action( 'after_switch_theme', fn() => delete_transient( 'bagus_img_map' ) );
