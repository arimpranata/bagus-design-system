<?php
/**
 * Inline SVG icon set (no icon fonts, no external requests).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/**
 * Return an inline SVG icon. Decorative by default (aria-hidden).
 *
 * @param string $name  Icon key.
 * @param string $class Extra class.
 * @return string
 */
function bagus_icon( $name, $class = '' ) {
	static $paths = null;
	if ( null === $paths ) {
		$paths = array(
			'menu'      => '<path d="M4 7h16M4 12h16M4 17h10"/>',
			'close'     => '<path d="M6 6l12 12M18 6L6 18"/>',
			'arrow-right' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'arrow-left'  => '<path d="M19 12H5M11 6l-6 6 6 6"/>',
			'chevron-down'=> '<path d="M6 9l6 6 6-6"/>',
			'chevron-right'=> '<path d="M9 6l6 6-6 6"/>',
			'external'  => '<path d="M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5"/>',
			'whatsapp'  => '<path d="M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.3z"/><path d="M9 8.6c.2-.5.5-.6.8-.6h.5c.2 0 .4.1.5.4l.7 1.6c.1.2 0 .5-.1.7l-.5.6c.6 1.2 1.6 2.2 2.8 2.8l.6-.5c.2-.2.5-.2.7-.1l1.6.7c.3.1.4.3.4.5v.5c0 .3-.1.6-.6.8-1.4.7-3.7-.1-5.5-1.9S8.3 10 9 8.6z"/>',
			'pin'       => '<path d="M12 21s-7-6.2-7-11.5A7 7 0 0 1 19 9.5C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
			'mail'      => '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6.5L12 13l8.5-6.5"/>',
			'phone'     => '<path d="M5 3h3l2 5-2.5 1.5a11 11 0 0 0 7 7L16 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 5a2 2 0 0 1 2-2z"/>',
			'tour'      => '<path d="M12 4a8 8 0 1 0 0 16"/><path d="M12 4c2.2 0 4 3.6 4 8s-1.8 8-4 8"/><path d="M4.5 9h11M4.5 15h7"/><path d="M17 15l3 3-3 3" transform="translate(0 -3)"/>',
			'calendar'  => '<rect x="3.5" y="5" width="17" height="15" rx="2"/><path d="M3.5 10h17M8 3v4M16 3v4"/>',
			'bed'       => '<path d="M3 18V7M3 14h18v4M21 14v-2a3 3 0 0 0-3-3h-7v5"/><circle cx="7" cy="11" r="1.6"/>',
			'activity'  => '<circle cx="13.5" cy="4.5" r="1.8"/><path d="M8 21l3-6 3 2v5M6 11l3-3 4 1 3 3 3 1M11 15l-1-5"/>',
			'package'   => '<path d="M3.5 8.5h17v4h-17zM5 12.5V20h14v-7.5M12 8.5V20"/><path d="M12 8.5c-1.5-3-5-3.5-5-1.5s3 1.5 5 1.5zm0 0c1.5-3 5-3.5 5-1.5s-3 1.5-5 1.5z"/>',
			'dining'    => '<path d="M7 3v8M5 3v5a2 2 0 0 0 4 0V3M7 11v10M17 21V3c-2 1-3.5 3.5-3.5 7v3H17"/>',
			'offer'     => '<path d="M3 12V4h8l10 10-8 8z"/><circle cx="7.5" cy="8.5" r="1.5"/>',
			'spa'       => '<path d="M12 20c-4 0-8-2.5-8-7 3 0 6 1.5 8 4 2-2.5 5-4 8-4 0 4.5-4 7-8 7z"/><path d="M12 17c-2-2-2.5-6 0-10 2.5 4 2 8 0 10z"/>',
			'yoga'      => '<circle cx="12" cy="4.5" r="1.8"/><path d="M12 7.5v6M6 10.5l6 2 6-2M4 20c2-1 4-1.5 8-1.5s6 .5 8 1.5M8.5 17.5L12 13.5l3.5 4"/>',
			'leaf'      => '<path d="M5 19c0-8 5-14 15-14 0 9-5 14-13 14"/><path d="M5 19c3-4 6-7 10-9"/>',
			'check'     => '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
			'star'      => '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z" fill="currentColor" stroke="none"/>',
			'quote'     => '<path d="M9.5 7C6.5 8 5 10.3 5 13.5V17h4.5v-4.5H7.3c.1-1.9 1-3.2 2.7-3.9zM18.5 7c-3 1-4.5 3.3-4.5 6.5V17h4.5v-4.5h-2.2c.1-1.9 1-3.2 2.7-3.9z" fill="currentColor" stroke="none"/>',
			'download'  => '<path d="M12 4v11M7 10l5 5 5-5M5 20h14"/>',
			'search'    => '<circle cx="11" cy="11" r="6.5"/><path d="M20 20l-4.3-4.3"/>',
			'home'      => '<path d="M4 11l8-6.5 8 6.5M6 9.5V20h12V9.5"/>',
			'expand'    => '<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
			'pause'     => '<path d="M9 5v14M15 5v14"/>',
			'play'      => '<path d="M7 5l12 7-12 7z"/>',
			'wifi'      => '<path d="M2.5 9a14 14 0 0 1 19 0M5.5 12.2a9.5 9.5 0 0 1 13 0M8.6 15.4a5 5 0 0 1 6.8 0"/><circle cx="12" cy="18.6" r="1.1" fill="currentColor"/>',
			'net'       => '<path d="M4 20V9.5C4 6 7.6 3.5 12 3.5S20 6 20 9.5V20"/><path d="M4 12h16M4 16h16M9 4.2V20M15 4.2V20"/>',
			'ruler'     => '<path d="M4 4h6M4 4v6M20 20h-6M20 20v-6M4 4l6.5 6.5M20 20l-6.5-6.5M14 4h6v6M10 20H4v-6"/>',
			'sofa'      => '<path d="M5 11V8a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3"/><path d="M3 12.5a1.5 1.5 0 0 1 3 0V14h12v-1.5a1.5 1.5 0 0 1 3 0V18H3z"/><path d="M5 18v2M19 18v2"/>',
			'pool'      => '<path d="M3 17c1.5 0 1.5 1 3 1s1.5-1 3-1 1.5 1 3 1 1.5-1 3-1 1.5 1 3 1 1.5-1 3-1M3 20.5c1.5 0 1.5 1 3 1s1.5-1 3-1 1.5 1 3 1 1.5-1 3-1 1.5 1 3 1 1.5-1 3-1"/><path d="M8 14V5.5a2 2 0 0 1 4 0M16 14V5.5a2 2 0 0 0-4 0M8 8.5h8M8 11.5h8"/>',
			'view'      => '<path d="M2.5 19l6-9 4 6 3-4 6 7z"/><circle cx="17" cy="6.5" r="2"/>',
			'terrace'   => '<path d="M3 9h18M5 9l1.5-4h11L19 9M12 9v11M7 20h10M6 14h12"/>',
			'nosmoke'   => '<circle cx="12" cy="12" r="8.5"/><path d="M6 6l12 12M7 13.5h6M15.5 13.5H17"/>',
			'shower'    => '<path d="M5 20V7a3 3 0 0 1 6 0v1M8 8h6M9 11v1M12 11v1M15 11v1M10 14v1M13 14v1M16 14v1"/>',
			'bath'      => '<path d="M3 12h18v2a5 5 0 0 1-5 5H8a5 5 0 0 1-5-5zM6 12V6a2 2 0 0 1 4 0M7 19l-1 2M17 19l1 2"/>',
			'book-open' => '<path d="M12 6.5C10 5 7 4.5 3.5 5v13c3.5-.5 6.5 0 8.5 1.5 2-1.5 5-2 8.5-1.5V5C17 4.5 14 5 12 6.5zM12 6.5v13"/>',
			'cloche'    => '<path d="M3 18h18M4.5 18a7.5 7.5 0 0 1 15 0M12 8V6.5M10.5 6.5h3"/>',
			'sun'       => '<circle cx="12" cy="12" r="3.8"/><path d="M12 2.5v2.5M12 19v2.5M2.5 12H5M19 12h2.5M5.3 5.3l1.8 1.8M16.9 16.9l1.8 1.8M5.3 18.7l1.8-1.8M16.9 7.1l1.8-1.8"/>',
			'star-line' => '<path d="M12 3.5l2.6 5.3 5.9.9-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.9z"/>',
			'walker'    => '<circle cx="13" cy="4.5" r="1.8"/><path d="M10 21l2.2-5.5L15 18v3M8.5 12.5L10 8.8l3.5-.8 2.5 3.5 2.5 1M12.2 15.5L11 9"/>',
			'clock'     => '<circle cx="12" cy="12" r="8.5"/><path d="M12 7.5V12l3 2"/>',
			'facebook'  => '<path d="M14 21v-7.5h2.6l.4-3H14V8.7c0-.9.3-1.5 1.5-1.5H17V4.5c-.3 0-1.2-.1-2.3-.1-2.3 0-3.7 1.4-3.7 3.9v2.2H8.5v3H11V21"/>',
			'instagram' => '<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.2" cy="6.8" r="1" fill="currentColor"/>',
			'youtube'   => '<rect x="2.5" y="5.5" width="19" height="13" rx="3.5"/><path d="M10 9.2v5.6l4.8-2.8z" fill="currentColor"/>',
			'tiktok'    => '<path d="M14 3.5v11a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 3.5c.4 2.6 2 4.2 4.5 4.5"/>',
			'douyin'    => '<path d="M14 3.5v11a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 3.5c.4 2.6 2 4.2 4.5 4.5"/><path d="M16.5 14.5a6 6 0 0 1-6 6" opacity=".5"/>',
			'xiaohongshu' => '<rect x="3.5" y="3.5" width="17" height="17" rx="4"/><path d="M7.5 9.5v5M10 9.5v5M12.5 9.5h4v5h-4zM14.5 9.5v5"/>',
		);
	}
	if ( ! isset( $paths[ $name ] ) ) {
		$name = 'chevron-right';
	}
	return sprintf(
		'<svg class="icon icon-%1$s %2$s" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%3$s</svg>',
		esc_attr( $name ),
		esc_attr( $class ),
		$paths[ $name ] // phpcs:ignore -- static, trusted markup.
	);
}

/**
 * Pick an amenity icon from a feature label ("Free Wi-Fi" → wifi, "Pool Size …" → pool).
 *
 * @param string $label Feature text.
 * @return string Icon key.
 */
function bagus_feature_icon( $label ) {
	$map = apply_filters(
		'bagus_feature_icons',
		array(
			'wi-fi|wifi|internet'          => 'wifi',
			'mosquito'                     => 'net',
			'pool'                         => 'pool',
			'living'                       => 'sofa',
			'size|m2|m²|sqm'               => 'ruler',
			'bed'                          => 'bed',
			'view'                         => 'view',
			'terrace|terace|balcony|sofa'  => 'terrace',
			'smok'                         => 'nosmoke',
			'jacuzzi|bathtub|bath'         => 'bath',
			'shower'                       => 'shower',
		)
	);
	foreach ( $map as $pattern => $icon ) {
		if ( preg_match( '/' . $pattern . '/i', $label ) ) {
			return $icon;
		}
	}
	return 'check';
}
