<?php
/**
 * Content presets & data access.
 *
 * A preset is a PHP file returning an array (see presets/bagusjati.php).
 * Presets are discovered in the parent theme's /presets folder, the child
 * theme's /presets folder, and through the `bagus_presets` filter.
 * Customizer values (contact info, hero, toggles) override preset values.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

/**
 * List available presets: slug => absolute file path.
 *
 * @return array<string,string>
 */
function bagus_presets() {
	$found = array();
	$dirs  = array_unique( array( get_template_directory() . '/presets', get_stylesheet_directory() . '/presets' ) );
	foreach ( $dirs as $dir ) {
		foreach ( (array) glob( $dir . '/*.php' ) as $file ) {
			$found[ basename( $file, '.php' ) ] = $file;
		}
	}
	return apply_filters( 'bagus_presets', $found );
}

/**
 * Preset that matches this site's domain (bagusagropelaga.com -> bagusagropelaga), else bagusjati.
 *
 * @return string
 */
function bagus_default_preset() {
	$host    = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	$host    = preg_replace( '/^www\./', '', $host );
	$slug    = sanitize_key( preg_replace( '/\.[a-z.]+$/', '', $host ) );
	$presets = bagus_presets();
	return isset( $presets[ $slug ] ) ? $slug : 'bagusjati';
}

/**
 * Generic, brand-free defaults so the theme works for any site.
 *
 * @return array
 */
function bagus_blank_preset() {
	return array(
		'label'   => __( 'Blank (use your own content)', 'bagus' ),
		'brand'   => array( 'name' => get_bloginfo( 'name' ), 'tagline' => get_bloginfo( 'description' ), 'logo' => '', 'logo_alt' => get_bloginfo( 'name' ) ),
		'contact' => array( 'emails' => array() ),
		'social'  => array(),
		'review_sites' => array(),
		'menu'    => array(),
		'hero'    => array( 'title' => get_bloginfo( 'name' ), 'subtitle' => get_bloginfo( 'description' ), 'actions' => array() ),
	);
}

/**
 * Full site data (preset merged with Customizer overrides). Cached per request.
 *
 * @param string|null $key Optional top-level key.
 * @return mixed
 */
function bagus_data( $key = null ) {
	static $data = null;

	if ( null === $data ) {
		$presets = bagus_presets();
		$slug    = get_theme_mod( 'bagus_preset', bagus_default_preset() );
		$data    = ( $slug && isset( $presets[ $slug ] ) ) ? (array) include $presets[ $slug ] : array();
		$data    = array_replace_recursive( bagus_blank_preset(), $data );

		// Customizer overrides (only when a value is set).
		$map = array(
			'contact.reserve_url'  => 'bagus_reserve_url',
			'contact.whatsapp_url' => 'bagus_whatsapp_url',
			'contact.map_url'      => 'bagus_map_url',
			'contact.contact_url'  => 'bagus_contact_url',
			'contact.tour_url'     => 'bagus_tour_url',
			'contact.phone'        => 'bagus_phone',
			'contact.phone_label'  => 'bagus_phone_label',
			'contact.address'      => 'bagus_address',
			'booking.action'       => 'bagus_booking_action',
			'hero.title'           => 'bagus_hero_title',
			'hero.subtitle'        => 'bagus_hero_subtitle',
			'hero.location'        => 'bagus_hero_location',
			'hero.motto'           => 'bagus_hero_motto',
			'hero.video'           => 'bagus_hero_video',
		);
		foreach ( $map as $path => $mod ) {
			$val = get_theme_mod( $mod, '' );
			if ( '' !== $val && null !== $val ) {
				list( $a, $b )  = explode( '.', $path );
				$data[ $a ][ $b ] = $val;
			}
		}
		$hero_id = absint( get_theme_mod( 'bagus_hero_image', 0 ) );
		if ( $hero_id ) {
			$data['hero']['image_id'] = $hero_id;
		}

		$data = apply_filters( 'bagus_data', $data );
	}

	if ( null === $key ) {
		return $data;
	}
	return isset( $data[ $key ] ) ? $data[ $key ] : array();
}

/**
 * Is a homepage section enabled? (Customizer toggle, default on when it has data.)
 *
 * @param string $section Section slug.
 * @return bool
 */
function bagus_section_enabled( $section ) {
	$data = bagus_data( $section );
	if ( empty( $data ) ) {
		return false;
	}
	return (bool) get_theme_mod( 'bagus_show_' . $section, true );
}

/**
 * Ordered list of homepage sections (filterable so child themes can reorder/add).
 *
 * @return string[]
 */
function bagus_home_sections() {
	return apply_filters(
		'bagus_home_sections',
		array( 'hero', 'quicklinks', 'booking', 'resort', 'villas', 'retreat', 'packages', 'farm', 'wedding', 'reviews' )
	);
}
