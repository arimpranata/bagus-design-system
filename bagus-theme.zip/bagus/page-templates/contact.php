<?php
/**
 * Template Name: Contact
 * Template Post Type: page
 *
 * Contact cards (from the Customizer/preset), a native contact form and any
 * page content below.
 *
 * @package Bagus
 */

get_header();

$contact = bagus_data( 'contact' );
$hero    = bagus_data( 'hero' );

while ( have_posts() ) :
	the_post();
	$split = bagus_split_hero();
	get_template_part( 'template-parts/page-hero', null, array( 'subtitle' => has_excerpt() ? get_the_excerpt() : '', 'images' => $split['images'] ) );
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-flow page-body' ); ?>>
		<div class="wrap contact-grid">
			<aside class="contact-cards" aria-label="<?php esc_attr_e( 'Contact details', 'bagus' ); ?>">
				<?php if ( ! empty( $contact['address'] ) ) : ?>
					<div class="contact-card" data-reveal="up">
						<span class="contact-card__icon"><?php echo bagus_icon( 'pin' ); // phpcs:ignore ?></span>
						<div>
							<h2 class="contact-card__title"><?php esc_html_e( 'Address', 'bagus' ); ?></h2>
							<address><?php echo esc_html( $contact['address'] ); ?></address>
							<?php if ( ! empty( $contact['map_url'] ) ) : ?>
								<?php echo bagus_button( __( 'Get directions', 'bagus' ), $contact['map_url'], 'link' ); // phpcs:ignore ?>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $contact['phone'] ) ) : ?>
					<div class="contact-card" data-reveal="up">
						<span class="contact-card__icon"><?php echo bagus_icon( 'phone' ); // phpcs:ignore ?></span>
						<div>
							<h2 class="contact-card__title"><?php esc_html_e( 'Phone', 'bagus' ); ?></h2>
							<p><a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone_label'] ?? $contact['phone'] ); ?></a><?php echo ! empty( $contact['fax_label'] ) ? '<br>' . esc_html__( 'Fax', 'bagus' ) . ' ' . esc_html( $contact['fax_label'] ) : ''; ?></p>
							<?php if ( ! empty( $contact['whatsapp_url'] ) ) : ?>
								<?php echo bagus_button( __( 'Chat on WhatsApp', 'bagus' ), $contact['whatsapp_url'], 'link' ); // phpcs:ignore ?>
							<?php endif; ?>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $contact['emails'] ) ) : ?>
					<div class="contact-card" data-reveal="up">
						<span class="contact-card__icon"><?php echo bagus_icon( 'mail' ); // phpcs:ignore ?></span>
						<div>
							<h2 class="contact-card__title"><?php esc_html_e( 'E-mail', 'bagus' ); ?></h2>
							<dl class="contact-card__mails">
								<?php foreach ( $contact['emails'] as $m ) : ?>
									<div><dt><?php echo esc_html( $m['label'] ); ?></dt><dd><a href="mailto:<?php echo esc_attr( $m['email'] ); ?>"><?php echo esc_html( $m['email'] ); ?></a></dd></div>
								<?php endforeach; ?>
							</dl>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $contact['tour_url'] ) ) : ?>
					<a class="contact-tour" data-reveal="up"<?php echo bagus_link_attrs( $contact['tour_url'] ); // phpcs:ignore ?>>
						<?php echo bagus_img( $hero['image_id'] ?? ( $hero['image'] ?? '' ), '', array( 'sizes' => '(min-width: 1024px) 400px, 100vw' ), 'bagus-wide' ); // phpcs:ignore ?>
						<span><?php echo bagus_icon( 'tour' ); // phpcs:ignore ?><?php esc_html_e( 'Virtual Tour', 'bagus' ); ?></span>
					</a>
				<?php endif; ?>
			</aside>
			<section class="contact-form-card" aria-labelledby="contact-form-title" data-reveal="up">
				<h2 class="contact-form-card__title" id="contact-form-title"><?php esc_html_e( 'Send us a message', 'bagus' ); ?></h2>
				<?php bagus_lead_form( 'contact', 'contact' ); ?>
			</section>
		</div>
		<?php if ( trim( $split['content'] ) ) : ?>
			<div class="wrap prose entry-content"><?php echo apply_filters( 'the_content', $split['content'] ); // phpcs:ignore ?></div>
		<?php endif; ?>
	</article>
	<?php
endwhile;

get_footer();
