<?php
/**
 * Template Name: Canvas (no title)
 * Template Post Type: page
 *
 * Header + footer only; the page content controls everything in between
 * (use full-width blocks and the theme's block styles).
 *
 * @package Bagus
 */

get_header();

while ( have_posts() ) :
	the_post();
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'canvas prose entry-content' ); ?>>
		<?php the_title( '<h1 class="sr-only">', '</h1>' ); ?>
		<?php the_content(); ?>
	</article>
	<?php
endwhile;

get_footer();
