<?php
/**
 * Template Name: Full width
 * Template Post Type: page, post
 *
 * Wide canvas for block layouts (alignwide/alignfull work edge to edge).
 *
 * @package Bagus
 */

get_header();

while ( have_posts() ) :
	the_post();
	$split = bagus_split_hero();
	get_template_part( 'template-parts/page-hero', null, array( 'images' => $split['images'] ) );
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-flow' ); ?>>
		<div class="wrap wrap--wide prose entry-content"><?php echo apply_filters( 'the_content', $split['content'] ); // phpcs:ignore ?></div>
	</article>
	<?php
endwhile;

get_footer();
