<?php
/**
 * Front page. "Theme sections" mode renders the preset sections (default);
 * "Page content" mode renders the static front page from the block editor.
 *
 * @package Bagus
 */

get_header();

if ( 'sections' === get_theme_mod( 'bagus_home_mode', 'sections' ) ) {
	// Hero + booking share one wrapper so phones can stack them as
	// video → booking card → hero text/contacts/icons (CSS only, no duplicate markup).
	$bagus_sections = array_values( array_filter( bagus_home_sections(), 'bagus_section_enabled' ) );
	$bagus_open     = 'hero' === ( $bagus_sections[0] ?? '' );
	$bagus_close_at = in_array( 'booking', $bagus_sections, true ) ? 'booking' : 'hero';
	if ( $bagus_open ) {
		echo '<div class="hero-stack">';
	}
	foreach ( $bagus_sections as $section ) {
		get_template_part( 'template-parts/sections/' . $section, null, array( 'data' => bagus_data( $section ) ) );
		if ( $bagus_open && $section === $bagus_close_at ) {
			echo '</div>';
			$bagus_open = false;
		}
	}
	if ( $bagus_open ) {
		echo '</div>';
	}
} else {
	while ( have_posts() ) {
		the_post();
		echo '<article class="wrap wrap--content prose entry-content page-flow">';
		the_title( '<h1 class="entry-title sr-only">', '</h1>' );
		the_content();
		echo '</article>';
	}
}

get_footer();
