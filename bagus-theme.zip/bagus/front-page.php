<?php
/**
 * Front page. "Theme sections" mode renders the preset sections (default);
 * "Page content" mode renders the static front page from the block editor.
 *
 * @package Bagus
 */

get_header();

if ( 'sections' === get_theme_mod( 'bagus_home_mode', 'sections' ) ) {
	foreach ( bagus_home_sections() as $section ) {
		if ( bagus_section_enabled( $section ) ) {
			get_template_part( 'template-parts/sections/' . $section, null, array( 'data' => bagus_data( $section ) ) );
		}
	}
} else {
	while ( have_posts() ) {
		the_post();
		echo '<article class="wrap wrap--content prose entry-content page-flow">';
		the_title( '<h1 class="entry-title sr-only">', '</h1>' );
		the_content();
		echo '</article>';
	}
}

get_footer();
