=== Bagus ===
Requires at least: 6.4
Tested up to: 6.8
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Builder-free, mobile-first hospitality & wellness theme with swipe UI, its own motion library, Customizer colour tokens, content presets and Google-standard SEO. See README.md.

== Changelog ==
= 1.0.0 =
* Initial release (Bagus Jati preset).
