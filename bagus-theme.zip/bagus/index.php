<?php
/**
 * Blog index / archives / search results (card grid).
 *
 * @package Bagus
 */

get_header();

if ( is_home() && ! is_front_page() ) {
	$title = single_post_title( '', false );
	$sub   = '';
} elseif ( is_search() ) {
	/* translators: %s: search query */
	$title = sprintf( __( 'Search results for “%s”', 'bagus' ), get_search_query() );
	$sub   = '';
} elseif ( is_archive() ) {
	$title = get_the_archive_title();
	$sub   = get_the_archive_description();
} else {
	$title = get_bloginfo( 'name' );
	$sub   = get_bloginfo( 'description' );
}
get_template_part( 'template-parts/page-hero', null, array( 'title' => $title, 'subtitle' => $sub, 'image_id' => 0 ) );
?>
<div class="wrap section page-flow">
	<?php if ( is_search() ) : ?>
		<div class="search-again"><?php get_search_form(); ?></div>
	<?php endif; ?>

	<?php if ( have_posts() ) : ?>
		<div class="card-grid" data-reveal-stagger>
			<?php
			while ( have_posts() ) {
				the_post();
				get_template_part( 'template-parts/content/card' );
			}
			?>
		</div>
		<?php
		the_posts_pagination(
			array(
				'mid_size'  => 1,
				'prev_text' => bagus_icon( 'arrow-left' ) . '<span class="sr-only">' . __( 'Previous', 'bagus' ) . '</span>',
				'next_text' => '<span class="sr-only">' . __( 'Next', 'bagus' ) . '</span>' . bagus_icon( 'arrow-right' ),
			)
		);
		?>
	<?php else : ?>
		<div class="empty prose">
			<p><?php esc_html_e( 'Nothing found. Try another search.', 'bagus' ); ?></p>
			<?php get_search_form(); ?>
		</div>
	<?php endif; ?>
</div>
<?php
get_footer();
