<?php
/**
 * Page template.
 *
 * @package Bagus
 */

get_header();

while ( have_posts() ) :
	the_post();
	$split = bagus_split_hero();
	get_template_part( 'template-parts/page-hero', null, array( 'subtitle' => has_excerpt() ? get_the_excerpt() : '', 'images' => $split['images'] ) );
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-flow page-body' ); ?>>
		<div class="wrap prose entry-content">
			<?php
			echo apply_filters( 'the_content', $split['content'] ); // phpcs:ignore
			wp_link_pages( array( 'before' => '<nav class="page-links">', 'after' => '</nav>' ) );
			?>
		</div>
	</article>
	<?php
	if ( comments_open() || get_comments_number() ) {
		echo '<div class="wrap wrap--content">';
		comments_template();
		echo '</div>';
	}
endwhile;

get_footer();
