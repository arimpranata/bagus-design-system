<?php
/**
 * Shared dialogs. All are native <dialog> elements (top layer, focus trap,
 * Escape) styled as swipe-to-dismiss bottom sheets on mobile and centred
 * modals on desktop. Their images use loading="lazy" + fetchpriority="low"
 * because they are hidden until opened.
 *
 * @package Bagus
 */

$booking  = bagus_data( 'booking' );
$welcome  = bagus_data( 'welcome' );
$down     = bagus_data( 'downloads' );
?>

<?php if ( $booking ) : ?>
<dialog class="sheet" id="booking-sheet" aria-labelledby="booking-sheet-title">
	<div class="sheet__scroller">
		<div class="sheet__spacer" aria-hidden="true"></div>
		<div class="sheet__panel">
			<span class="sheet__grip" aria-hidden="true"></span>
			<div class="sheet__head">
				<h2 class="sheet__title" id="booking-sheet-title"><?php echo esc_html( $booking['title'] ); ?></h2>
				<button type="button" class="icon-btn" data-close aria-label="<?php esc_attr_e( 'Close', 'bagus' ); ?>" autofocus><?php echo bagus_icon( 'close' ); // phpcs:ignore ?></button>
			</div>
			<?php get_template_part( 'template-parts/booking-form', null, array( 'id' => 'sheet' ) ); ?>
		</div>
	</div>
</dialog>
<?php endif; ?>

<?php if ( ! empty( $down ) ) : ?>
<dialog class="sheet" id="downloads" aria-labelledby="downloads-title">
	<div class="sheet__scroller">
		<div class="sheet__spacer" aria-hidden="true"></div>
		<div class="sheet__panel">
			<span class="sheet__grip" aria-hidden="true"></span>
			<div class="sheet__head">
				<h2 class="sheet__title" id="downloads-title"><?php echo esc_html( $down['title'] ); ?></h2>
				<button type="button" class="icon-btn" data-close aria-label="<?php esc_attr_e( 'Close', 'bagus' ); ?>" autofocus><?php echo bagus_icon( 'close' ); // phpcs:ignore ?></button>
			</div>
			<p><?php echo esc_html( $down['text'] ); ?></p>
			<?php bagus_lead_form( 'download', 'dl' ); ?>
		</div>
	</div>
</dialog>
<?php endif; ?>

<?php if ( bagus_section_enabled( 'welcome' ) && ( is_front_page() || apply_filters( 'bagus_welcome_everywhere', false ) ) ) : ?>
<dialog class="sheet sheet--welcome" id="welcome" aria-labelledby="welcome-title" data-welcome data-trigger="<?php echo esc_attr( get_theme_mod( 'bagus_welcome_trigger', 'scroll' ) ); ?>">
	<div class="sheet__scroller">
		<div class="sheet__spacer" aria-hidden="true"></div>
		<div class="sheet__panel">
			<span class="sheet__grip" aria-hidden="true"></span>
			<div class="sheet__head">
				<h2 class="sheet__title sr-only" id="welcome-title"><?php echo esc_html( $welcome['title'] ); ?></h2>
				<button type="button" class="icon-btn" data-close aria-label="<?php esc_attr_e( 'Close', 'bagus' ); ?>" autofocus><?php echo bagus_icon( 'close' ); // phpcs:ignore ?></button>
			</div>
			<?php
			if ( ! empty( $welcome['promos'] ) ) {
				$slides = array();
				foreach ( $welcome['promos'] as $p ) {
					$slides[] = '<a class="promo"' . bagus_link_attrs( $p['url'] ) . '>'
						. bagus_img( $p['image'], $p['label'], array( 'fetchpriority' => 'low', 'sizes' => '(min-width: 768px) 560px, 92vw' ) )
						. '<span class="promo__cta btn btn--accent btn--sm"><span>' . esc_html( $p['label'] ) . '</span></span></a>';
				}
				bagus_carousel( __( 'Special offers', 'bagus' ), $slides, array( 'variant' => 'promo', 'autoplay' => 5000 ) );
			}
			?>
			<div class="welcome-actions">
				<?php foreach ( (array) ( $welcome['actions'] ?? array() ) as $a ) : ?>
					<?php echo bagus_button( $a['label'], $a['url'], $a['style'], 'ghost' === $a['style'] ? 'whatsapp' : '' ); // phpcs:ignore ?>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</dialog>
<?php endif; ?>

<dialog class="lightbox" id="lightbox" aria-label="<?php esc_attr_e( 'Image viewer', 'bagus' ); ?>">
	<button type="button" class="icon-btn lightbox__close" data-close aria-label="<?php esc_attr_e( 'Close', 'bagus' ); ?>" autofocus><?php echo bagus_icon( 'close' ); // phpcs:ignore ?></button>
	<p class="lightbox__count" aria-live="polite"></p>
	<button type="button" class="icon-btn lightbox__nav lightbox__nav--prev" data-dir="-1" aria-label="<?php esc_attr_e( 'Previous image', 'bagus' ); ?>"><?php echo bagus_icon( 'arrow-left' ); // phpcs:ignore ?></button>
	<div class="lightbox__track" tabindex="0"></div>
	<button type="button" class="icon-btn lightbox__nav lightbox__nav--next" data-dir="1" aria-label="<?php esc_attr_e( 'Next image', 'bagus' ); ?>"><?php echo bagus_icon( 'arrow-right' ); // phpcs:ignore ?></button>
</dialog>
