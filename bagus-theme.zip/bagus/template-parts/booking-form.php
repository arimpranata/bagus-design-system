<?php
/**
 * Availability form → booking engine (GET, opens in a new tab).
 * Native date inputs give ISO dates (YYYY-MM-DD) which the engine expects,
 * so no jQuery / moment / daterangepicker is needed.
 *
 * @package Bagus
 */

$b  = bagus_data( 'booking' );
$id = isset( $args['id'] ) ? sanitize_key( $args['id'] ) : 'bk';
if ( empty( $b['action'] ) ) {
	return;
}
$today    = wp_date( 'Y-m-d' );
$tomorrow = wp_date( 'Y-m-d', time() + DAY_IN_SECONDS );
?>
<form class="booking-form" action="<?php echo esc_url( $b['action'] ); ?>" method="get" target="_blank" data-booking-form>
	<div class="booking-form__field booking-form__field--date">
		<label for="<?php echo esc_attr( $id ); ?>-in"><?php esc_html_e( 'Check in', 'bagus' ); ?></label>
		<input id="<?php echo esc_attr( $id ); ?>-in" type="date" name="checkin" value="<?php echo esc_attr( $today ); ?>" min="<?php echo esc_attr( $today ); ?>" required>
	</div>
	<div class="booking-form__field booking-form__field--date">
		<label for="<?php echo esc_attr( $id ); ?>-out"><?php esc_html_e( 'Check out', 'bagus' ); ?></label>
		<input id="<?php echo esc_attr( $id ); ?>-out" type="date" name="checkout" value="<?php echo esc_attr( $tomorrow ); ?>" min="<?php echo esc_attr( $tomorrow ); ?>" required>
	</div>
	<?php
	$selects = array(
		'adult'  => array( __( 'Adult', 'bagus' ), $b['adults'] ?? array( 1, 2, 3 ) ),
		'child'  => array( __( 'Children', 'bagus' ), $b['children'] ?? array( 0, 1, 2 ) ),
		'infant' => array( __( 'Infant', 'bagus' ), $b['infants'] ?? array( 0, 1, 2 ) ),
	);
	foreach ( $selects as $name => $s ) :
		?>
		<div class="booking-form__field booking-form__field--sm">
			<label for="<?php echo esc_attr( $id . '-' . $name ); ?>"><?php echo esc_html( $s[0] ); ?></label>
			<select id="<?php echo esc_attr( $id . '-' . $name ); ?>" name="<?php echo esc_attr( $name ); ?>">
				<?php foreach ( $s[1] as $n ) : ?>
					<option value="<?php echo esc_attr( $n ); ?>"><?php echo esc_html( $n ? $n : '-' ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	<?php endforeach; ?>
	<div class="booking-form__field">
		<label for="<?php echo esc_attr( $id ); ?>-promo"><?php esc_html_e( 'Promo Code', 'bagus' ); ?></label>
		<input id="<?php echo esc_attr( $id ); ?>-promo" type="text" name="promocode" placeholder="<?php esc_attr_e( 'enter your code', 'bagus' ); ?>" autocomplete="off">
	</div>
	<button type="submit" class="btn btn--accent booking-form__submit"><span><?php echo esc_html( $b['button'] ?? __( 'Check availability', 'bagus' ) ); ?></span><?php echo bagus_icon( 'arrow-right' ); // phpcs:ignore ?></button>
</form>
