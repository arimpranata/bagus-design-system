<?php
/**
 * Inner-page hero: a photo band (slideshow from a "Page hero slideshow"
 * gallery, or the featured image) followed by the centred title block —
 * the same rhythm as the original site, refreshed.
 *
 * Args: title, subtitle, images (array of [src, alt]), image_id.
 *
 * @package Bagus
 */

$title    = $args['title'] ?? get_the_title();
$subtitle = $args['subtitle'] ?? '';
$images   = $args['images'] ?? array();
$image_id = $args['image_id'] ?? ( is_singular() ? get_post_thumbnail_id() : 0 );
if ( ! $images && $image_id ) {
	$images = array( array( (int) $image_id, '' ) );
}
?>
<header class="page-hero<?php echo $images ? ' page-hero--image' : ''; ?>">
	<?php if ( $images ) : ?>
		<div class="page-hero__band">
			<div class="kenburns" data-slideshow="4500">
				<?php foreach ( $images as $i => $img ) : ?>
					<?php
					echo bagus_img( // phpcs:ignore
						$img[0],
						$img[1],
						array( 'class' => 'kenburns__img' . ( 0 === $i ? ' is-active' : '' ), 'sizes' => '100vw' ) + ( 0 === $i ? array( 'loading' => 'eager', 'fetchpriority' => 'high' ) : array( 'fetchpriority' => 'low' ) ),
						'full'
					);
					?>
				<?php endforeach; ?>
			</div>
			<div class="page-hero__shade" aria-hidden="true"></div>
		</div>
	<?php endif; ?>
	<div class="page-hero__content wrap">
		<?php bagus_breadcrumbs(); ?>
		<h1 class="page-hero__title" data-split><?php echo wp_kses_post( $title ); ?></h1>
		<span class="divider" aria-hidden="true"></span>
		<?php if ( $subtitle ) : ?>
			<p class="page-hero__sub" data-reveal="up"><?php echo wp_kses_post( $subtitle ); ?></p>
		<?php endif; ?>
	</div>
</header>
