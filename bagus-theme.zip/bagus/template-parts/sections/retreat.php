<?php
/**
 * Retreat section (shared feature layout).
 *
 * @package Bagus
 */

get_template_part( 'template-parts/sections/feature', null, array( 'data' => $args['data'], 'id' => 'retreat', 'flip' => (bool) 0 ) );
