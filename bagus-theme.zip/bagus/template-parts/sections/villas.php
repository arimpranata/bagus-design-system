<?php
/**
 * Villas: cards with photo gallery, amenity icon list and Read More / Book Now.
 * Desktop: 3 + 2 grid (like the original layout). Phones: swipeable cards; the
 * card photo opens the full gallery in the lightbox (no nested swipe areas).
 *
 * Also used by the [bagus_section name="villas"] shortcode on inner pages.
 *
 * @package Bagus
 */

$d = $args['data'];
?>
<section class="villas section" id="villas" aria-labelledby="villas-title">
	<span class="botanical botanical--left" aria-hidden="true"></span>
	<div class="wrap">
		<?php bagus_heading( '', $d['title'], 'h2', 'villas-title', 'center' ); ?>
		<p class="swipe-hint" aria-hidden="true"><span><?php echo esc_html( sprintf( /* translators: %d: number of villa types */ _n( 'Swipe to explore %d villa', 'Swipe to explore all %d villas', count( $d['items'] ), 'bagus' ), count( $d['items'] ) ) ); ?></span><?php echo bagus_icon( 'arrow-right' ); // phpcs:ignore ?></p>
		<?php
		$slides = array();
		foreach ( $d['items'] as $i => $v ) {
			ob_start();
			?>
			<article class="villa-card" id="villa-<?php echo (int) $i; ?>" aria-labelledby="villa-<?php echo (int) $i; ?>-name">
				<div class="villa-card__media">
					<?php
					$photos = array();
					foreach ( $v['images'] as $j => $img ) {
						$full     = bagus_image_attrs( $img[0], 'full' )['src'];
						$photos[] = '<figure class="media-slide"><a href="' . esc_url( $full ) . '" data-lightbox-item aria-label="' . esc_attr__( 'View larger image', 'bagus' ) . '">'
							. bagus_img( $img[0], $img[1], array( 'sizes' => '(min-width: 1024px) 33vw, 86vw' ) + ( $j ? array( 'fetchpriority' => 'low' ) : array() ), 'bagus-wide' )
							. '</a></figure>';
					}
					/* translators: %s: villa name */
					bagus_carousel( sprintf( __( '%s photos', 'bagus' ), $v['name'] ), $photos, array( 'variant' => 'media', 'lightbox' => true ) );
					?>
					<span class="villa-card__count" aria-hidden="true"><?php echo bagus_icon( 'expand' ); // phpcs:ignore ?><?php echo count( $v['images'] ); ?></span>
				</div>
				<div class="villa-card__body">
					<h3 class="villa-card__name" id="villa-<?php echo (int) $i; ?>-name"><a href="<?php echo esc_url( $v['url'] ); ?>"><?php echo esc_html( $v['name'] ); ?></a></h3>
					<ul class="amenity-list">
						<?php foreach ( $v['features'] as $f ) : ?>
							<li><span class="amenity-list__icon"><?php echo bagus_icon( bagus_feature_icon( $f ) ); // phpcs:ignore ?></span><span><?php echo esc_html( $f ); ?></span></li>
						<?php endforeach; ?>
					</ul>
					<div class="villa-card__actions">
						<?php echo bagus_button( __( 'Read More', 'bagus' ), $v['url'], 'outline' ); // phpcs:ignore ?>
						<?php echo bagus_button( __( 'Book Now', 'bagus' ), $v['book'], 'primary' ); // phpcs:ignore ?>
					</div>
				</div>
			</article>
			<?php
			$slides[] = ob_get_clean();
		}
		bagus_carousel( $d['title'], $slides, array( 'variant' => 'villas', 'progress' => true ) );
		?>
	</div>
</section>
