<?php
/**
 * Shared "feature band": wide Ken Burns photo with the text laid over a dark
 * gradient on the left (desktop), or photo then charcoal text panel (phones).
 * Used by Group Retreat, Organic Farm and Wedding & Event.
 *
 * Args: data (kicker,title,text,link,images), id, flip (bool).
 *
 * @package Bagus
 */

$d    = $args['data'];
$id   = $args['id'];
$flip = ! empty( $args['flip'] );
?>
<section class="band<?php echo $flip ? ' band--flip' : ''; ?>" id="<?php echo esc_attr( $id ); ?>" aria-labelledby="<?php echo esc_attr( $id ); ?>-title">
	<div class="wrap">
		<div class="band__frame" data-reveal="mask">
			<div class="kenburns" data-slideshow="4500">
				<?php foreach ( $d['images'] as $i => $src ) : ?>
					<?php echo bagus_img( $src, 0 === $i ? $d['title'] : '', array( 'class' => 'kenburns__img' . ( 0 === $i ? ' is-active' : '' ), 'sizes' => '(min-width: 1280px) 1240px, 100vw' ) + ( $i ? array( 'fetchpriority' => 'low' ) : array() ), 'full' ); // phpcs:ignore ?>
				<?php endforeach; ?>
			</div>
			<div class="band__veil" aria-hidden="true"></div>
			<?php if ( count( $d['images'] ) > 1 ) : ?>
				<button type="button" class="icon-btn kenburns__toggle" data-slideshow-toggle aria-pressed="false" aria-label="<?php esc_attr_e( 'Pause slideshow', 'bagus' ); ?>" data-pause-label="<?php esc_attr_e( 'Pause slideshow', 'bagus' ); ?>" data-play-label="<?php esc_attr_e( 'Play slideshow', 'bagus' ); ?>"><?php echo bagus_icon( 'pause' ); // phpcs:ignore ?></button>
			<?php endif; ?>
			<div class="band__content">
				<?php if ( ! empty( $d['kicker'] ) ) : ?>
					<p class="band__kicker"><?php echo esc_html( $d['kicker'] ); ?></p>
				<?php endif; ?>
				<h2 class="band__title" id="<?php echo esc_attr( $id ); ?>-title" data-split><?php echo esc_html( $d['title'] ); ?></h2>
				<p class="band__text"><?php echo esc_html( $d['text'] ); ?></p>
				<?php if ( ! empty( $d['link'] ) ) : ?>
					<?php echo bagus_button( $d['link']['label'], $d['link']['url'], 'light', '', array( 'aria-label' => $d['link']['label'] . ': ' . $d['title'] ) ); // phpcs:ignore ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
</section>
