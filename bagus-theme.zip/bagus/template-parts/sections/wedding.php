<?php
/**
 * Wedding section (shared feature layout).
 *
 * @package Bagus
 */

get_template_part( 'template-parts/sections/feature', null, array( 'data' => $args['data'], 'id' => 'wedding', 'flip' => (bool) 0 ) );
