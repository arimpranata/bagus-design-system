<?php
/**
 * Hero: full-bleed image (LCP), title block bottom-left, underlined contact
 * links and the quick-link icon tiles overlaid on the image (grid on desktop,
 * swipe rail on phones). The booking card overlaps the bottom edge.
 *
 * @package Bagus
 */

$d     = $args['data'];
$image = $d['image_id'] ?? ( $d['image'] ?? '' );
$tiles = bagus_section_enabled( 'quicklinks' ) ? bagus_data( 'quicklinks' ) : array();
$video = '';
if ( ! empty( $d['video'] ) ) {
	if ( preg_match( '~(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([\w-]{11})~', $d['video'], $m ) ) {
		$video = 'youtube:' . $m[1];
	} elseif ( preg_match( '~\.(mp4|webm)(\?.*)?$~i', $d['video'] ) ) {
		$video = 'file:' . esc_url_raw( $d['video'] );
	}
}
?>
<section class="hero<?php echo $tiles ? ' hero--tiles' : ''; ?>" aria-labelledby="hero-title" data-hero>
	<div class="hero__media" data-parallax="0.12">
		<?php
		echo bagus_img( // phpcs:ignore
			$image,
			$d['image_alt'] ?? '',
			array(
				'class'         => 'hero__img',
				'loading'       => 'eager',
				'fetchpriority' => 'high',
				'sizes'         => '100vw',
				'width'         => $d['image_w'] ?? '',
				'height'        => $d['image_h'] ?? '',
			),
			'full'
		);
		?>
	</div>
	<?php if ( $video ) : ?>
		<div class="hero__video" data-hero-video="<?php echo esc_attr( $video ); ?>" aria-hidden="true"></div>
		<div class="hero__player" data-hero-player hidden>
			<button type="button" class="hero__pbtn" data-player="play" aria-label="<?php esc_attr_e( 'Pause video', 'bagus' ); ?>" data-label-play="<?php esc_attr_e( 'Play video', 'bagus' ); ?>" data-label-pause="<?php esc_attr_e( 'Pause video', 'bagus' ); ?>"><?php echo bagus_icon( 'pause' ); // phpcs:ignore ?><?php echo bagus_icon( 'play' ); // phpcs:ignore ?></button>
			<button type="button" class="hero__pbtn" data-player="sound" aria-label="<?php esc_attr_e( 'Turn sound on', 'bagus' ); ?>" data-label-on="<?php esc_attr_e( 'Turn sound on', 'bagus' ); ?>" data-label-off="<?php esc_attr_e( 'Mute', 'bagus' ); ?>"><?php echo bagus_icon( 'muted' ); // phpcs:ignore ?><?php echo bagus_icon( 'sound' ); // phpcs:ignore ?></button>
			<button type="button" class="hero__pbtn" data-player="full" aria-label="<?php esc_attr_e( 'Full screen', 'bagus' ); ?>"><?php echo bagus_icon( 'expand' ); // phpcs:ignore ?></button>
		</div>
	<?php endif; ?>
	<div class="hero__veil" aria-hidden="true"></div>

	<div class="hero__inner wrap">
		<div class="hero__text">
			<h1 class="hero__title" id="hero-title">
				<span class="hero__name"><?php echo esc_html( $d['title'] ); ?></span>
				<?php if ( ! empty( $d['subtitle'] ) ) : ?>
					<span class="hero__sub" data-split="chars"><?php echo esc_html( $d['subtitle'] ); ?></span>
				<?php endif; ?>
			</h1>
			<?php if ( ! empty( $d['location'] ) ) : ?>
				<p class="hero__loc" data-reveal="up" style="--d:.5s"><?php echo bagus_icon( 'pin' ); // phpcs:ignore ?><?php echo esc_html( $d['location'] ); ?></p>
			<?php endif; ?>
			<?php if ( ! empty( $d['actions'] ) ) : ?>
				<ul class="hero__actions" data-reveal-stagger style="--d:.6s">
					<?php foreach ( $d['actions'] as $a ) : ?>
						<li data-reveal="up"><a class="chip chip--glass"<?php echo bagus_link_attrs( $a['url'] ); // phpcs:ignore ?>><?php echo bagus_icon( $a['icon'] ); // phpcs:ignore ?><span><?php echo esc_html( $a['label'] ); ?></span></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<?php if ( $tiles ) : ?>
			<nav class="hero__tiles" aria-label="<?php esc_attr_e( 'Explore', 'bagus' ); ?>">
				<ul class="tiles" data-reveal-stagger style="--d:.45s">
					<?php foreach ( $tiles as $q ) : ?>
						<li data-reveal="up">
							<a class="tile" href="<?php echo esc_url( $q['url'] ); ?>">
								<span class="tile__icon"><?php echo bagus_icon( bagus_tile_icon( $q['label'], $q['icon'] ?? '' ) ); // phpcs:ignore ?></span>
								<span class="tile__label"><?php echo esc_html( $q['label'] ); ?></span>
							</a>
						</li>
					<?php endforeach; ?>
				</ul>
			</nav>
		<?php endif; ?>
	</div>

</section>
<div id="after-hero"></div>
