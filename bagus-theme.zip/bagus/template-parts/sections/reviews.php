<?php
/**
 * Guest reviews: swipeable quote cards over a parallax image.
 *
 * @package Bagus
 */

$d     = $args['data'];
$sites = bagus_data( 'review_sites' );
$more  = '';
foreach ( (array) $sites as $s ) {
	if ( 'Tripadvisor' === $s['label'] && $s['url'] ) {
		$more = $s['url'];
	}
}
?>
<section class="reviews section" id="reviews" aria-labelledby="reviews-title">
	<?php if ( ! empty( $d['image'] ) ) : ?>
		<div class="reviews__bg" aria-hidden="true" data-parallax="0.12"><?php echo bagus_img( $d['image'], '', array( 'sizes' => '100vw' ), 'full' ); // phpcs:ignore ?></div>
	<?php endif; ?>
	<div class="wrap">
		<?php bagus_heading( '', $d['title'], 'h2', 'reviews-title', 'center' ); ?>
		<?php
		$slides = array();
		foreach ( $d['items'] as $r ) {
			$lang     = ! empty( $r['lang'] ) ? ' lang="' . esc_attr( $r['lang'] ) . '"' : '';
			$slides[] = '<figure class="review">'
				. '<span class="review__quote">' . bagus_icon( 'quote' ) . '</span>'
				. '<p class="review__title">' . esc_html( $r['title'] ) . '</p>'
				. '<blockquote class="review__text"' . $lang . '><p>' . esc_html( $r['text'] ) . '</p></blockquote>'
				. '<figcaption class="review__meta"><span class="review__avatar" aria-hidden="true">' . esc_html( mb_strtoupper( mb_substr( $r['author'], 0, 1 ) ) ) . '</span>'
				. '<span><strong>' . esc_html( $r['author'] ) . '</strong>'
				. '<time datetime="' . esc_attr( $r['date'] ) . '">' . esc_html( date_i18n( get_option( 'date_format' ), strtotime( $r['date'] ) ) ) . '</time></span></figcaption>'
				. '</figure>';
		}
		bagus_carousel( $d['title'], $slides, array( 'variant' => 'reviews' ) );
		?>
		<?php if ( $more ) : ?>
			<p class="center"><?php echo bagus_button( __( 'Write a review', 'bagus' ), $more, 'light' ); // phpcs:ignore ?></p>
		<?php endif; ?>
	</div>
</section>
