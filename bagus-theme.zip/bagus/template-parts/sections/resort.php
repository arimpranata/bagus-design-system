<?php
/**
 * The Resort: image carousel (swipe + lightbox), story text, key facts,
 * download buttons and the sustainability commitment.
 *
 * @package Bagus
 */

$d = $args['data'];
?>
<section class="resort section" id="the-resort" aria-labelledby="resort-title">
	<span class="botanical botanical--right" aria-hidden="true"></span>
	<div class="wrap resort__grid">
		<div class="resort__media" data-reveal="mask">
			<?php
			$slides = array();
			foreach ( $d['images'] as $i => $img ) {
				$full     = bagus_image_attrs( $img['src'], 'full' )['src'];
				$slides[] = '<figure class="media-slide"><a href="' . esc_url( $full ) . '" data-lightbox-item aria-label="' . esc_attr__( 'View larger image', 'bagus' ) . '">'
					. bagus_img( $img['src'], $img['alt'], array( 'sizes' => '(min-width: 1024px) 45vw, 100vw' ) + ( $i ? array( 'fetchpriority' => 'low' ) : array() ) )
					. '</a></figure>';
			}
			bagus_carousel( $d['kicker'], $slides, array( 'variant' => 'media', 'autoplay' => 3000, 'lightbox' => true ) );
			?>
			<?php if ( ! empty( $d['stats'] ) ) : ?>
				<ul class="stats" data-reveal-stagger>
					<?php foreach ( $d['stats'] as $s ) : ?>
						<li class="stat" data-reveal="up"><strong class="stat__value"><?php echo esc_html( $s['value'] ); ?><small><?php echo esc_html( $s['unit'] ); ?></small></strong><span class="stat__label"><?php echo esc_html( $s['label'] ); ?></span></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>

		<div class="resort__body">
			<?php bagus_heading( $d['kicker'], $d['title'], 'h2', 'resort-title' ); ?>
			<div class="prose readmore" data-readmore>
				<?php foreach ( $d['paragraphs'] as $p ) : ?>
					<p data-reveal="up"><?php echo esc_html( $p ); ?></p>
				<?php endforeach; ?>
			</div>
			<?php if ( ! empty( $d['downloads'] ) ) : ?>
				<div class="btn-row" data-reveal="up">
					<?php foreach ( $d['downloads'] as $label ) : ?>
						<button type="button" class="btn btn--primary" data-open="downloads" data-magnetic><?php echo bagus_icon( 'download' ); // phpcs:ignore ?><span><?php echo esc_html( $label ); ?></span></button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( ! empty( $d['sustain'] ) ) : ?>
		<div class="wrap">
			<aside class="sustain" aria-labelledby="sustain-title" data-reveal="up">
				<span class="sustain__icon"><?php echo bagus_icon( 'leaf' ); // phpcs:ignore ?></span>
				<div>
					<h3 class="sustain__title" id="sustain-title"><?php echo esc_html( $d['sustain']['title'] ); ?></h3>
					<p><?php echo esc_html( $d['sustain']['text'] ); ?></p>
					<?php echo bagus_button( $d['sustain']['link']['label'], $d['sustain']['link']['url'], 'link' ); // phpcs:ignore ?>
				</div>
			</aside>
		</div>
	<?php endif; ?>
</section>
