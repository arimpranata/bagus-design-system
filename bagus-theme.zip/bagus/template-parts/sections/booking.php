<?php
/**
 * Booking card overlapping the hero. Full form on tablet/desktop; on phones a
 * single button opens the same form in the bottom sheet.
 *
 * @package Bagus
 */

$d = $args['data'];
if ( empty( $d['action'] ) ) {
	return;
}
?>
<section class="booking" aria-labelledby="booking-title">
	<div class="wrap">
		<div class="booking__card" data-reveal="up">
			<h2 class="booking__title" id="booking-title"><?php echo bagus_icon( 'star' ); // phpcs:ignore ?><?php echo esc_html( $d['title'] ); ?></h2>
			<div class="booking__form"><?php get_template_part( 'template-parts/booking-form', null, array( 'id' => 'bar' ) ); ?></div>
			<button type="button" class="btn btn--accent btn--block booking__open" data-open="booking-sheet"><?php echo bagus_icon( 'calendar' ); // phpcs:ignore ?><span><?php echo esc_html( $d['button'] ?? __( 'Check availability', 'bagus' ) ); ?></span></button>
		</div>
	</div>
</section>
