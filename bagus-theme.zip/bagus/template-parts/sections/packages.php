<?php
/**
 * Experiences packages — expanding photo panels.
 * Desktop: six tall panels side by side; the one under the pointer (or with
 * keyboard focus) widens to reveal its story. Phones/tablets: a swipe rail of
 * tall photo cards with the story laid over the image.
 *
 * @package Bagus
 */

$d = $args['data'];
?>
<section class="packages section" id="packages" aria-labelledby="packages-title">
	<span class="botanical botanical--right" aria-hidden="true"></span>
	<div class="wrap">
		<?php bagus_heading( '', $d['title'], 'h2', 'packages-title', 'center' ); ?>
		<?php
		$slides = array();
		foreach ( $d['items'] as $i => $p ) {
			$name     = mb_convert_case( mb_strtolower( $p['name'] ), MB_CASE_TITLE );
			$slides[] = '<article class="xp' . ( 0 === $i ? ' is-active' : '' ) . '" aria-labelledby="xp-' . (int) $i . '" data-expand-item>'
				. bagus_img( $p['image'], '', array( 'sizes' => '(min-width: 1024px) 50vw, 80vw', 'class' => 'xp__img' ), 'full' )
				. '<span class="xp__shade" aria-hidden="true"></span>'
				. '<span class="xp__tab" aria-hidden="true">' . esc_html( $name ) . '</span>'
				. '<div class="xp__body">'
				. '<h3 class="xp__name" id="xp-' . (int) $i . '">' . esc_html( $name ) . '</h3>'
				. '<p class="xp__text">' . esc_html( $p['text'] ) . '</p>'
				. '<a class="xp__link" href="' . esc_url( $p['url'] ) . '" aria-label="' . esc_attr( __( 'Learn More', 'bagus' ) . ': ' . $name ) . '"><span>' . esc_html__( 'Learn More', 'bagus' ) . '</span><span class="xp__arrow">' . bagus_icon( 'arrow-right' ) . '</span></a>'
				. '</div></article>';
		}
		bagus_carousel( $d['title'], $slides, array( 'variant' => 'xp', 'class' => 'xp-group' ) );
		?>
	</div>
</section>
