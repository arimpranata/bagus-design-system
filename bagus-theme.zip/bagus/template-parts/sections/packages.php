<?php
/**
 * Experiences packages: alternating photo/text rows on desktop (the original
 * layout, refreshed), swipeable cards on phones.
 *
 * @package Bagus
 */

$d = $args['data'];
?>
<section class="packages section" id="packages" aria-labelledby="packages-title">
	<span class="botanical botanical--right" aria-hidden="true"></span>
	<div class="wrap">
		<?php bagus_heading( '', $d['title'], 'h2', 'packages-title', 'center' ); ?>
		<?php
		$slides = array();
		foreach ( $d['items'] as $i => $p ) {
			$slides[] = '<article class="pkg" aria-labelledby="pkg-' . (int) $i . '">'
				. '<div class="pkg__media">' . bagus_img( $p['image'], '', array( 'sizes' => '(min-width: 1024px) 30vw, 84vw', 'class' => 'pkg__img' ), 'bagus-wide' ) . '</div>'
				. '<div class="pkg__body">'
				. '<h3 class="pkg__name" id="pkg-' . (int) $i . '"><a class="stretched" href="' . esc_url( $p['url'] ) . '">' . esc_html( mb_convert_case( mb_strtolower( $p['name'] ), MB_CASE_TITLE ) ) . '</a></h3>'
				. '<p class="pkg__text">' . esc_html( $p['text'] ) . '</p>'
				. '<span class="pkg__more" aria-hidden="true"><span>' . esc_html__( 'Learn More', 'bagus' ) . '</span><span class="pkg__arrow">' . bagus_icon( 'arrow-right' ) . '</span></span>'
				. '</div></article>';
		}
		bagus_carousel( $d['title'], $slides, array( 'variant' => 'packages' ) );
		?>
	</div>
</section>
