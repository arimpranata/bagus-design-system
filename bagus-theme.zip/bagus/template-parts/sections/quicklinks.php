<?php
/**
 * Quick links are rendered as icon tiles inside the hero (sections/hero.php).
 * This standalone version only shows when the hero section is switched off.
 *
 * @package Bagus
 */

if ( bagus_section_enabled( 'hero' ) ) {
	return;
}
$d = $args['data'];
?>
<nav class="quicklinks wrap" aria-label="<?php esc_attr_e( 'Explore', 'bagus' ); ?>">
	<ul class="tiles tiles--static" data-reveal-stagger>
		<?php foreach ( $d as $q ) : ?>
			<li data-reveal="up"><a class="tile" href="<?php echo esc_url( $q['url'] ); ?>"><span class="tile__icon"><?php echo bagus_icon( $q['icon'] ); // phpcs:ignore ?></span><span class="tile__label"><?php echo esc_html( $q['label'] ); ?></span></a></li>
		<?php endforeach; ?>
	</ul>
</nav>
