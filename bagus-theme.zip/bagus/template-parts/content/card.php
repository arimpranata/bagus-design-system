<?php
/**
 * Post card (whole card is one link target via stretched link).
 *
 * @package Bagus
 */
?>
<article <?php post_class( 'card' ); ?> data-reveal="up">
	<div class="card__media">
		<?php if ( has_post_thumbnail() ) : ?>
			<?php echo bagus_img( get_post_thumbnail_id(), '', array( 'sizes' => '(min-width: 1024px) 33vw, (min-width: 640px) 50vw, 100vw' ), 'bagus-card' ); // phpcs:ignore ?>
		<?php else : ?>
			<span class="card__placeholder" aria-hidden="true"><?php echo bagus_icon( 'leaf' ); // phpcs:ignore ?></span>
		<?php endif; ?>
	</div>
	<div class="card__body">
		<?php if ( 'post' === get_post_type() ) : ?>
			<p class="card__meta"><?php bagus_posted_on(); ?></p>
		<?php endif; ?>
		<h2 class="card__title"><a class="stretched" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
		<p class="card__excerpt"><?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ) ); ?></p>
		<span class="card__more" aria-hidden="true"><?php esc_html_e( 'Read more', 'bagus' ); ?><?php echo bagus_icon( 'arrow-right' ); // phpcs:ignore ?></span>
	</div>
</article>
