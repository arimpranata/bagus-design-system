<?php
/**
 * Bagus theme bootstrap.
 *
 * Builder-free: no Elementor (or any page builder) code, CSS or assets are
 * used or required. Everything visual comes from assets/css/main.css and the
 * small motion library in assets/js.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

define( 'BAGUS_VERSION', '1.3.0' );
define( 'BAGUS_DIR', get_template_directory() );
define( 'BAGUS_URI', get_template_directory_uri() );

require BAGUS_DIR . '/inc/data.php';
require BAGUS_DIR . '/inc/icons.php';
require BAGUS_DIR . '/inc/setup.php';
require BAGUS_DIR . '/inc/assets.php';
require BAGUS_DIR . '/inc/customizer.php';
require BAGUS_DIR . '/inc/template-tags.php';
require BAGUS_DIR . '/inc/menus.php';
require BAGUS_DIR . '/inc/seo.php';
require BAGUS_DIR . '/inc/forms.php';
require BAGUS_DIR . '/inc/legacy.php';
require BAGUS_DIR . '/inc/updater.php';
require BAGUS_DIR . '/inc/importer.php';
