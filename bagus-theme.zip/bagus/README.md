# Bagus — tema WordPress tanpa page builder

Tema WordPress cepat dan *mobile-first* untuk hotel, resort, dan wellness retreat. Tema ini dibuat dari nol dan berdiri sendiri: **tidak memakai page builder**, dan tidak membawa kode, CSS, atau aset dari tema lama. Animasi, carousel, drawer, bottom sheet, dan lightbox memakai library kecil buatan sendiri (ES modules, tanpa dependensi dan tanpa build step).

Tema ini sudah membawa **preset konten Bagus Jati**: semua teks, gambar, menu, urutan section, dan link dari homepage bagusjati.com dipindahkan apa adanya. Untuk website lain, ganti preset dan warnanya. Kode temanya tetap generik.

![Screenshot](screenshot.jpg)

## Versi 1.1.0 — siap untuk 5 website

- Preset konten untuk **Bagus Jati, Bagus Agro Pelaga, Puri Bagus Candidasa, Puri Bagus Lovina dan Puri Bagus Manggis** (`presets/`), diambil dari homepage live masing-masing: teks, gambar, menu, villa, paket, review, kontak, sosial media.
- Preset dipilih otomatis dari domain website (bagusagropelaga.com → preset Bagus Agro Pelaga). Bisa diganti di Customizer.
- Tiap preset membawa warna sendiri (primary + secondary); tetap bisa diubah di Customizer → Colours.
- Update otomatis: tema membaca `theme-update.json` di repo publik `arimpranata/bagus-design-system` dan muncul sebagai "Update available" di Tampilan → Tema.
- Nama resort yang panjang di hero otomatis mengecil dan pindah baris.

## Instalasi

1. Download repo sebagai ZIP, atau clone ke `wp-content/themes/bagus`.
2. Buka **Tampilan → Tema → Aktifkan "Bagus"**. Menu WordPress yang sudah ada otomatis dipasang ke lokasi *Primary*. Kalau belum ada menu, tema menampilkan menu bagusjati.com dari preset.
3. Pindah dari page builder lama? Pakai plugin terpisah **Bagus Migration** (lihat di bawah). Tema sendiri tidak berisi kode page builder.
4. **SEO tetap utuh.** Tema memakai `title-tag` dan `wp_head()`, jadi Yoast SEO tetap mengatur title, meta description, canonical, Open Graph, dan schema seperti sebelumnya.

## Pengaturan (Tampilan → Sesuaikan → Bagus Theme)

| Bagian | Isi |
|---|---|
| **Colours** | Primary, Accent, Text, Background, Dark, dan radius sudut. Warna turunan lain dihitung otomatis dengan `color-mix()`. |
| **Typography** | Pasangan font heading/body dari Google Fonts, atau font sistem. |
| **Homepage & content preset** | Pilih preset, mode homepage (*section tema* atau *konten block editor*), dan tampil/sembunyikan tiap section. |
| **Hero** | Gambar, judul H1, subjudul, lokasi, dan motto (marquee). |
| **Contact & booking** | URL Reserve, booking engine, WhatsApp, peta, kontak, virtual tour, telepon, alamat. |
| **Downloads & leads** | URL file Factsheet / E-Brochure / Press Release yang terbuka setelah pengunjung mengisi email, plus alamat email penerima lead. Lead tersimpan di **Alat → Bagus leads** (bisa diekspor ke CSV). |

## Memakai tema untuk website lain

1. Salin `presets/bagusjati.php` ke `presets/namasitus.php` (di tema ini atau di child theme), lalu ubah isinya.
2. Pilih preset itu di Customizer, atur warna dan font. Selesai.
3. Atau pakai mode **Page content** untuk membangun homepage dengan block editor. Tersedia block style: *Swipe carousel* (Gallery), *Swipe on mobile* (Columns), *Card* (Group), *Kicker* (Heading), *Ghost* (Button).

Filter yang tersedia untuk developer: `bagus_presets`, `bagus_data`, `bagus_home_sections`, `bagus_colors`, `bagus_fonts`, `bagus_business_type`, `bagus_schema_enabled`, `bagus_seo_plugin_active`, `bagus_builder_handle_prefixes`.

## Fitur

**Mobile / usability**
- App bar bawah di zona jempol: Book (membuka bottom sheet form ketersediaan), Chat (WhatsApp), Location, Menu.
- Drawer menu dengan gestur swipe asli (scroll-snap) dan submenu accordion.
- Carousel yang bisa di-swipe untuk foto resort, galeri tiap villa, paket, review, dan Bagus Discovery. Quick links berupa rail chip yang bisa di-swipe.
- Bottom sheet yang ditutup dengan swipe ke bawah (booking, download, welcome/promo). Di desktop tampil sebagai modal.
- Lightbox swipe untuk semua galeri. Chip villa sticky dengan scroll-spy. Teks panjang memakai "Read more".
- Tombol minimal 44 px, input 16 px (tidak memicu zoom di iOS), dan dukungan safe-area untuk iPhone.

**Animasi (library sendiri, `assets/js/lib`)**
- Reveal saat scroll (`data-reveal="up|left|right|scale|blur|mask"`), stagger, split text per kata/huruf.
- Ken Burns slideshow, zoom hero, marquee, parallax dan progress bar berbasis *scroll-driven animations* (progressive enhancement).
- Tombol "magnetic" dan efek sheen, transisi halaman *cross-document view transitions*.
- Semua animasi mengikuti `prefers-reduced-motion`. Kalau JS gagal dimuat, konten tetap tampil.

**SEO & performa (standar Google)**
- Satu H1 per halaman, HTML semantik, breadcrumbs (memakai Yoast/Rank Math kalau terpasang).
- JSON-LD `Resort`/`LodgingBusiness` lengkap dengan alamat, sameAs, dan `containsPlace` untuk setiap villa. Entitas ini terhubung ke Organization milik Yoast. Kalau tidak ada plugin SEO, tema menulis sendiri meta description, robots, Open Graph, dan BreadcrumbList.
- Gambar hero di-preload dengan `fetchpriority="high"`, gambar lain `loading="lazy"`. URL media dipetakan ke attachment supaya `srcset` responsif ikut keluar. Font dimuat tanpa memblokir render.
- Tanpa jQuery. CSS block library tidak dimuat di homepage. Form booking memakai input tanggal native, bukan jQuery + moment + daterangepicker.

## Struktur

```
functions.php          bootstrap
inc/                   data/preset, setup, assets, customizer, seo, menus, forms, updater
presets/bagusjati.php  konten Bagus Jati (teks, gambar, menu, link)
template-parts/        section homepage, dialog, form booking, hero halaman, kartu
assets/css/main.css    seluruh styling (token warna dari Customizer)
assets/js/app.js       entry → lib/motion, carousel, overlays, lightbox, ui
```

## Migrasi dari page builder lama (plugin Bagus Migration)

Konverter halaman tidak lagi ada di dalam tema. Pakai plugin sekali-pakai **Bagus Migration** (`bagus-migration.zip`):

1. Pasang dan aktifkan plugin Bagus Migration. Selama aktif, aset dan template page builder lama tidak tampil di front-end.
2. Buka **Alat → Bagus: Convert pages**, centang semua halaman, klik **Convert selected pages** (atau `wp bagus convert --all`). Setiap halaman disusun ulang dengan block editor sesuai layout tema; konten lama tersimpan sebagai revision.
3. Nonaktifkan dan hapus page builder beserta add-on-nya.
4. Nonaktifkan dan hapus plugin Bagus Migration.
