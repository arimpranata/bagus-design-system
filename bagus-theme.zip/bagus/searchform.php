<?php
/**
 * Search form.
 *
 * @package Bagus
 */

$uid = wp_unique_id( 'search-' );
?>
<form role="search" method="get" class="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="sr-only" for="<?php echo esc_attr( $uid ); ?>"><?php esc_html_e( 'Search for:', 'bagus' ); ?></label>
	<input type="search" id="<?php echo esc_attr( $uid ); ?>" class="search-form__input" placeholder="<?php esc_attr_e( 'Search…', 'bagus' ); ?>" value="<?php echo get_search_query(); ?>" name="s" enterkeyhint="search">
	<button type="submit" class="icon-btn search-form__btn" aria-label="<?php esc_attr_e( 'Search', 'bagus' ); ?>"><?php echo bagus_icon( 'search' ); // phpcs:ignore ?></button>
</form>
