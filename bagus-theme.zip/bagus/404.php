<?php
/**
 * 404.
 *
 * @package Bagus
 */

get_header();
get_template_part( 'template-parts/page-hero', null, array( 'title' => __( 'Page not found', 'bagus' ), 'subtitle' => __( 'The page you are looking for may have moved. Try the menu, a search, or one of the links below.', 'bagus' ), 'image_id' => 0 ) );
?>
<div class="wrap wrap--content section prose">
	<?php get_search_form(); ?>
	<?php if ( bagus_data( 'quicklinks' ) ) : ?>
		<ul class="quicklinks__rail quicklinks__rail--static">
			<?php foreach ( bagus_data( 'quicklinks' ) as $q ) : ?>
				<li><a class="qlink" href="<?php echo esc_url( $q['url'] ); ?>"><span class="qlink__icon"><?php echo bagus_icon( $q['icon'] ); // phpcs:ignore ?></span><span class="qlink__label"><?php echo esc_html( $q['label'] ); ?></span></a></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<p><?php echo bagus_button( __( 'Back to home', 'bagus' ), home_url( '/' ), 'primary', 'home' ); // phpcs:ignore ?></p>
</div>
<?php
get_footer();
