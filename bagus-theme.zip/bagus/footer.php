<?php
/**
 * Footer: sister properties, contact columns, newsletter, review & social
 * links, mobile app bar and shared dialogs (booking sheet, downloads,
 * lightbox, welcome sheet).
 *
 * @package Bagus
 */

$brand     = bagus_data( 'brand' );
$contact   = bagus_data( 'contact' );
$discovery = bagus_data( 'discovery' );
$news      = bagus_data( 'newsletter' );
$reserve   = $contact['reserve_url'] ?? '';
?>
</main>

<footer class="site-footer" id="footer">
	<?php if ( bagus_section_enabled( 'discovery' ) && ! empty( $discovery['items'] ) ) : ?>
		<section class="discovery" aria-labelledby="discovery-title">
			<div class="wrap">
				<header class="sec-head sec-head--center">
					<h2 class="sec-title sec-title--light" id="discovery-title" data-split><?php echo esc_html( $discovery['title'] ); ?></h2>
					<p class="kicker kicker--light" data-reveal="fade"><?php echo esc_html( $discovery['subtitle'] ); ?></p>
				</header>
				<?php
				$slides = array();
				foreach ( $discovery['items'] as $item ) {
					$slides[] = '<a class="disc-card"' . bagus_link_attrs( $item['url'] ) . '>'
						. bagus_img( $item['image'], $item['name'], array( 'sizes' => '(min-width: 1024px) 20vw, 70vw', 'class' => 'disc-card__img' ), 'bagus-card' )
						. '<span class="disc-card__body"><strong class="disc-card__name">' . esc_html( $item['name'] ) . '</strong>'
						. '<span class="disc-card__text">' . esc_html( $item['text'] ) . '</span>'
						. '<span class="disc-card__cta">' . esc_html__( 'Open Website', 'bagus' ) . bagus_icon( 'external' ) . '</span></span></a>';
				}
				bagus_carousel( $discovery['title'], $slides, array( 'variant' => 'discovery' ) );
				?>
			</div>
		</section>
	<?php endif; ?>

	<div class="footer-main wrap">
		<?php if ( ! empty( $contact['address'] ) ) : ?>
			<section class="footer-col" data-reveal>
				<h2 class="footer-col__title"><?php esc_html_e( 'Address', 'bagus' ); ?></h2>
				<address>
					<p><?php echo esc_html( $contact['address'] ); ?></p>
					<p>
						<?php if ( ! empty( $contact['phone'] ) ) : ?>
							<?php esc_html_e( 'Phone', 'bagus' ); ?> : <a href="tel:<?php echo esc_attr( $contact['phone'] ); ?>"><?php echo esc_html( $contact['phone_label'] ?? $contact['phone'] ); ?></a><br>
						<?php endif; ?>
						<?php if ( ! empty( $contact['fax_label'] ) ) : ?>
							<?php esc_html_e( 'Fax', 'bagus' ); ?> : <?php echo esc_html( $contact['fax_label'] ); ?>
						<?php endif; ?>
					</p>
				</address>
			</section>
		<?php endif; ?>

		<?php if ( ! empty( $contact['emails'] ) ) : ?>
			<section class="footer-col" data-reveal>
				<h2 class="footer-col__title"><?php esc_html_e( 'Contact Information', 'bagus' ); ?></h2>
				<dl class="footer-mails">
					<?php foreach ( $contact['emails'] as $m ) : ?>
						<div><dt><?php echo esc_html( $m['label'] ); ?></dt><dd><a href="mailto:<?php echo esc_attr( $m['email'] ); ?>"><?php echo esc_html( $m['email'] ); ?></a></dd></div>
					<?php endforeach; ?>
				</dl>
			</section>
		<?php endif; ?>

		<?php if ( ! empty( $news ) ) : ?>
			<section class="footer-col footer-col--news" id="newsletter" data-reveal>
				<h2 class="footer-col__title"><?php echo esc_html( $news['title'] ); ?></h2>
				<p><?php echo esc_html( $news['text'] ); ?></p>
				<?php bagus_lead_form( 'newsletter', 'news' ); ?>
			</section>
		<?php endif; ?>

		<div class="footer-col footer-col--links" data-reveal>
			<?php if ( bagus_data( 'review_sites' ) ) : ?>
				<h2 class="footer-col__title"><?php esc_html_e( 'Review Us', 'bagus' ); ?></h2>
				<ul class="logo-row">
					<?php foreach ( bagus_data( 'review_sites' ) as $r ) : ?>
						<li>
							<?php if ( $r['url'] ) : ?><a<?php echo bagus_link_attrs( $r['url'] ); // phpcs:ignore ?> aria-label="<?php echo esc_attr( $r['label'] ); ?>"><?php endif; ?>
							<?php echo bagus_img( $r['img'], $r['url'] ? '' : $r['label'], array( 'sizes' => '64px', 'width' => 64, 'height' => 64 ), 'thumbnail' ); // phpcs:ignore ?>
							<?php if ( $r['url'] ) : ?></a><?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
			<?php if ( bagus_data( 'social' ) ) : ?>
				<h2 class="footer-col__title"><?php esc_html_e( 'Follow Us', 'bagus' ); ?></h2>
				<ul class="social-row">
					<?php foreach ( bagus_data( 'social' ) as $s ) : ?>
						<li><a class="social-row__link"<?php echo bagus_link_attrs( $s['url'] ); // phpcs:ignore ?> aria-label="<?php echo esc_attr( $s['label'] ); ?>"><?php echo bagus_icon( $s['icon'] ); // phpcs:ignore ?></a></li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( is_active_sidebar( 'footer-1' ) ) : ?>
		<div class="wrap footer-widgets"><?php dynamic_sidebar( 'footer-1' ); ?></div>
	<?php endif; ?>

	<div class="footer-bottom-band">
	<div class="footer-bottom wrap">
		<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Footer', 'bagus' ); ?>"><?php bagus_render_menu( 'footer', 'footer' ); ?></nav>
		<?php endif; ?>
		<p>&copy; <?php echo esc_html( wp_date( 'Y' ) ); ?> <?php echo esc_html( $brand['name'] ?? get_bloginfo( 'name' ) ); ?>. <?php esc_html_e( 'All rights reserved.', 'bagus' ); ?></p>
		<?php $credit = get_theme_mod( 'bagus_footer_credit', '' ) ? get_theme_mod( 'bagus_footer_credit' ) : ( bagus_data( 'brand' )['credit'] ?? '' ); ?>
		<?php if ( $credit ) : ?>
			<p class="footer-bottom__credit"><?php echo esc_html( $credit ); ?></p>
		<?php endif; ?>
	</div>
	</div>
</footer>

<?php /* ---------- Mobile app bar (thumb zone) ---------- */ ?>
<nav class="appbar" aria-label="<?php esc_attr_e( 'Quick actions', 'bagus' ); ?>" data-appbar>
	<?php if ( bagus_data( 'booking' ) ) : ?>
		<button type="button" class="appbar__item appbar__item--main" data-open="booking-sheet"><?php echo bagus_icon( 'calendar' ); // phpcs:ignore ?><span><?php esc_html_e( 'Book', 'bagus' ); ?></span></button>
	<?php elseif ( $reserve ) : ?>
		<a class="appbar__item appbar__item--main"<?php echo bagus_link_attrs( $reserve ); // phpcs:ignore ?>><?php echo bagus_icon( 'calendar' ); // phpcs:ignore ?><span><?php esc_html_e( 'Book', 'bagus' ); ?></span></a>
	<?php endif; ?>
	<?php if ( ! empty( $contact['whatsapp_url'] ) ) : ?>
		<a class="appbar__item"<?php echo bagus_link_attrs( $contact['whatsapp_url'] ); // phpcs:ignore ?>><?php echo bagus_icon( 'whatsapp' ); // phpcs:ignore ?><span><?php esc_html_e( 'Chat', 'bagus' ); ?></span></a>
	<?php endif; ?>
	<?php if ( ! empty( $contact['map_url'] ) ) : ?>
		<a class="appbar__item"<?php echo bagus_link_attrs( $contact['map_url'] ); // phpcs:ignore ?>><?php echo bagus_icon( 'pin' ); // phpcs:ignore ?><span><?php esc_html_e( 'Location', 'bagus' ); ?></span></a>
	<?php endif; ?>
	<button type="button" class="appbar__item" data-open-drawer aria-controls="drawer"><?php echo bagus_icon( 'menu' ); // phpcs:ignore ?><span><?php esc_html_e( 'Menu', 'bagus' ); ?></span></button>
</nav>

<?php get_template_part( 'template-parts/dialogs' ); ?>

<?php wp_footer(); ?>
</body>
</html>
