<?php
/**
 * Content preset: Puri Bagus Lovina — Spa Beach Resort & Yoga Meditation Retreat.
 *
 * Texts, images, links and menu carried over from the live puribaguslovina.com homepage
 * (extracted automatically; check and adjust in this file or in the Customizer).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

return array(
	'label' => 'Puri Bagus Lovina — Spa Beach Resort & Yoga Meditation Retreat',
	'colors' => array(
		'primary' => '#004F58',
		'secondary' => '#004F58',
	),
	'brand' => array(
		'name' => 'Puri Bagus Lovina',
		'tagline' => 'The True Essence Of Bagus Hospitality',
		'logo' => 'https://puribaguslovina.com/storage/2026/08/logo-web-lovina-putih-01.png',
		'logo_alt' => 'Puri Bagus Lovina',
		'credit' => 'Website by Bagus Discovery maintain by Lightandpulse',
	),
	'contact' => array(
		'reserve_url' => 'https://reserveonline.id/s/6920288',
		'reserve_url_menu' => 'https://reserveonline.id/s/6A02F6B',
		'whatsapp_url' => 'https://wa.me/6281288684070?text=Hello,%20I%20am%20interested%20in%20the%20November%20Special%20Offer,%20please%20share%20the%20information',
		'map_url' => 'https://maps.app.goo.gl/HxbWFzoGpFzUNWgr8',
		'contact_url' => 'https://puribaguslovina.com/contact-us/',
		'tour_url' => '',
		'check_booking_url' => 'https://puribaguslovina.reserveonline.id/book/478/check-bookings?promotions%5B%5D=9621&promotions%5B%5D=9669&promotions%5B%5D=9676',
		'booking_engine' => 'https://puribaguslovina.reserveonline.id/book/478',
		'address' => 'Jalan Raya Seririt Singaraja Desa Pemaron Lovina, Singaraja 81151 Bali – Indonesia, P.O.Box 225 Lovina',
		'street' => 'Jalan Raya Seririt Singaraja',
		'locality' => '',
		'region' => 'Bali',
		'postal' => '81151',
		'country' => 'ID',
		'phone' => '+6236221430',
		'phone_label' => '+62 362 21430',
		'fax_label' => '+62 362 22627',
		'emails' => array(
			array(
				'label' => 'E-Mail',
				'email' => 'info@puribaguslovina.com',
			),
			array(
				'label' => 'Reservation',
				'email' => 'reservation@puribaguslovina.com',
			),
			array(
				'label' => 'Meeting & Event',
				'email' => 'sales@puribaguslovina.com',
			),
		),
	),
	'social' => array(
		array(
			'label' => 'Facebook',
			'icon' => 'facebook',
			'url' => 'https://www.facebook.com/people/Puri-Bagus-Lovina/100063919124795/#',
			'img' => 'https://puribaguslovina.com/storage/2026/08/ffb-1.png',
		),
		array(
			'label' => 'Instagram',
			'icon' => 'instagram',
			'url' => 'https://www.instagram.com/puribaguslovina/',
			'img' => 'https://puribaguslovina.com/storage/2026/08/fig-1.png',
		),
		array(
			'label' => 'YouTube',
			'icon' => 'youtube',
			'url' => 'https://www.youtube.com/watch?v=wGr9T7rmebg',
			'img' => 'https://puribaguslovina.com/storage/2026/08/ffb-1.png',
		),
		array(
			'label' => 'TikTok',
			'icon' => 'tiktok',
			'url' => 'https://www.tiktok.com/404?fromUrl=/puribaguslovina',
			'img' => 'https://puribaguslovina.com/storage/2026/08/fdouyin.svg',
		),
	),
	'review_sites' => array(
		array(
			'label' => 'Tripadvisor',
			'url' => 'https://www.tripadvisor.co.uk/Hotel_Review-g1600249-d307557-Reviews-Puri_Bagus_Lovina-Pemaron_Lovina_Beach_Buleleng_District_Buleleng_Regency_Bali.html',
			'img' => '',
		),
		array(
			'label' => 'Reviews',
			'url' => 'https://www.instagram.com/puribaguslovina/',
			'img' => '',
		),
		array(
			'label' => 'Reviews',
			'url' => 'https://www.puribaguslovina.com/resort-facilities/#',
			'img' => '',
		),
		array(
			'label' => 'Google Reviews',
			'url' => 'https://google.com/puribaguslovina',
			'img' => '',
		),
	),
	'menu' => array(
		array(
			'title' => 'The Resort',
			'url' => 'https://puribaguslovina.com/the-resort/',
		),
		array(
			'title' => 'Villas',
			'url' => 'https://puribaguslovina.com/villas/',
		),
		array(
			'title' => 'Offers',
			'url' => 'https://puribaguslovina.com/special-offers/',
		),
		array(
			'title' => 'Dining',
			'url' => 'https://puribaguslovina.com/#',
			'children' => array(
				array(
					'title' => 'SARASWATI RESTAURANT AND BAR',
					'url' => 'https://puribaguslovina.com/dining/#Saraswati',
				),
				array(
					'title' => 'SEAVIEW GRILL HOUSE',
					'url' => 'https://puribaguslovina.com/dining/#Seaview',
				),
				array(
					'title' => 'PRIVATE ROMANTIC DINNER',
					'url' => 'https://puribaguslovina.com/dining/#Private',
				),
				array(
					'title' => 'PICNIC LUNCH',
					'url' => 'https://puribaguslovina.com/dining/#Picnic',
				),
				array(
					'title' => 'FLOATING BRUNCH & LUNCH',
					'url' => 'https://puribaguslovina.com/dining/#Floating',
				),
				array(
					'title' => 'ROOM SERVICE',
					'url' => 'https://puribaguslovina.com/dining/#Room',
				),
			),
		),
		array(
			'title' => 'Facilities',
			'url' => 'https://puribaguslovina.com/#',
			'children' => array(
				array(
					'title' => 'Resort Facilities',
					'url' => 'https://puribaguslovina.com/resort-facilities/#Resort',
				),
				array(
					'title' => 'SPECIAL REQUEST ARRANGEMENTS',
					'url' => 'https://puribaguslovina.com/resort-facilities/#Special',
				),
				array(
					'title' => 'Other Services',
					'url' => 'https://puribaguslovina.com/resort-facilities/#Other',
				),
			),
		),
		array(
			'title' => 'Experience',
			'url' => 'https://puribaguslovina.com/#',
			'children' => array(
				array(
					'title' => 'Cultural Yoga',
					'url' => 'https://puribaguslovina.com/experiences/#cultural',
				),
				array(
					'title' => 'Rejuvenation Spa',
					'url' => 'https://puribaguslovina.com/experiences/#Rejuvenation',
				),
				array(
					'title' => 'Spiritual Healing',
					'url' => 'https://puribaguslovina.com/experiences/#spiritual',
				),
				array(
					'title' => 'Adventure Sport',
					'url' => 'https://puribaguslovina.com/experiences/#adventure',
				),
				array(
					'title' => 'Exotic Bali',
					'url' => 'https://puribaguslovina.com/experiences/#Bali',
				),
				array(
					'title' => 'Diving',
					'url' => 'https://puribaguslovina.com/experiences/#Diving',
				),
				array(
					'title' => 'Authentic Bali',
					'url' => 'https://puribaguslovina.com/experiences/#authenticbali',
				),
			),
		),
		array(
			'title' => 'Activities',
			'url' => 'https://puribaguslovina.com/#',
			'children' => array(
				array(
					'title' => 'Daily Culture & Retreat Activities',
					'url' => 'https://puribaguslovina.com/activities/#Daily',
				),
				array(
					'title' => 'A DAY OF MINDFULNESS',
					'url' => 'https://puribaguslovina.com/activities/#mindfulness',
				),
				array(
					'title' => 'Optional Activities',
					'url' => 'https://puribaguslovina.com/activities/#Optional',
				),
			),
		),
		array(
			'title' => 'Profile',
			'url' => 'https://puribaguslovina.com/#',
			'children' => array(
				array(
					'title' => 'Media & Blog',
					'url' => 'https://puribaguslovina.com/media-blog/',
				),
				array(
					'title' => 'Awards',
					'url' => 'https://puribaguslovina.com/awards/',
				),
				array(
					'title' => 'Gallery',
					'url' => 'https://puribaguslovina.com/gallery/',
				),
				array(
					'title' => 'Contact Us',
					'url' => 'https://puribaguslovina.com/contact-us/',
				),
			),
		),
	),
	'hero' => array(
		'title' => 'PURI BAGUS LOVINA',
		'subtitle' => 'THE TRUE ESSENCE OF BAGUS HOSPITALITY',
		'location' => 'Buleleng, Bali, 81119',
		'motto' => '',
		'video' => 'https://www.youtube.com/watch?v=Bt9Tca7N35w',
		'image' => 'https://puribaguslovina.com/storage/2026/08/homepage-9.jpg',
		'image_alt' => 'Puri Bagus Lovina',
		'actions' => array(
			array(
				'label' => 'WhatsApp',
				'icon' => 'whatsapp',
				'url' => 'https://wa.me/6281288684070?text=Hello,%20I%20am%20interested%20in%20the%20November%20Special%20Offer,%20please%20share%20the%20information',
			),
			array(
				'label' => 'Location',
				'icon' => 'pin',
				'url' => 'https://maps.app.goo.gl/HxbWFzoGpFzUNWgr8',
			),
			array(
				'label' => 'Contact Us',
				'icon' => 'mail',
				'url' => 'https://puribaguslovina.com/contact-us/',
			),
		),
	),
	'quicklinks' => array(
		array(
			'label' => 'Activity',
			'icon' => 'walker',
			'url' => 'https://bagusagropelaga.com/activities/',
		),
		array(
			'label' => 'Packages',
			'icon' => 'book-open',
			'url' => 'https://bagusagropelaga.com/experiences/',
		),
		array(
			'label' => 'Dining',
			'icon' => 'cloche',
			'url' => 'https://bagusagropelaga.com/dining-bap/',
		),
		array(
			'label' => 'Offers',
			'icon' => 'star-line',
			'url' => 'https://bagusagropelaga.com/special-offers/',
		),
		array(
			'label' => 'Spa Wellness',
			'icon' => 'spa',
			'url' => 'https://bagusagropelaga.com/spa-wellness/',
		),
		array(
			'label' => 'Yoga Meditation',
			'icon' => 'sun',
			'url' => 'https://bagusagropelaga.com/yoga/',
		),
	),
	'booking' => array(
		'title' => 'Best Rate Guarantee',
		'action' => 'https://puribaguslovina.reserveonline.id/book/478',
		'button' => 'Check availability',
		'adults' => array( 1, 2, 3 ),
		'children' => array( 0, 1, 2 ),
		'infants' => array( 0, 1, 2 ),
	),
	'resort' => array(
		'kicker' => 'THE RESORT',
		'title' => 'PURI BAGUS LOVINA',
		'paragraphs' => array(
			'Set along the tranquil northern coast of Bali, Puri Bagus Lovina is a premier beachfront resort where guests can experience breathtaking sunsets over the ocean in a serene and unspoiled setting. With direct access to a pristine beach, the resort offers a peaceful retreat that blends refined comfort, natural beauty, and authentic Balinese hospitality.',
			'Designed for relaxation, the accommodations feature spacious layouts, abundant natural light, and sweeping views of the surrounding landscape. Guests can choose from a range of room categories, including oceanfront villas such as Deluxe Ocean View and Two Bedroom Pool Villa, creating an immersive beachfront experience in Lovina.',
			'Rooted in the Balinese philosophy of Tri Hita Karana, the resort reflects harmony between people, nature, and the spiritual realm. This philosophy is expressed through eco-conscious design, cultural respect, and warm, personalized service, offering not just a stay, but a deeper connection to Bali’s heritage and environment. Traditional architectural elements, including alang-alang thatched roofs, enhance both the aesthetic and functionality of the resort by naturally cooling interiors while blending seamlessly with the tropical surroundings.',
			'Puri Bagus Lovina also offers a comprehensive wellness experience designed to nurture body, mind, and spirit. At Jaya Spa, guests can enjoy a curated selection of traditional Balinese and contemporary treatments using organic, locally sourced ingredients. Complementing this is a holistic program that includes yoga and meditation sessions held at the ocean-facing shala pavilion, where panoramic views of the Bali Sea create a truly inspiring setting for personal renewal.',
			'Dining at Saraswati Restaurant & Bar completes the wellness journey with a menu of thoughtfully prepared international and Indonesian cuisine, emphasizing fresh, locally sourced ingredients and balanced nutrition. Guests can enjoy nourishing meals while overlooking the calming ocean views.',
			'For those seeking exploration, the resort provides access to a range of cultural and outdoor activities, from dolphin-watching, snorkeling, and diving to traditional dance performances and cooking classes. Nearby attractions such as Banjar Hot Springs, Brahmavihara-Arama Monastery, and Gitgit Waterfall offer further opportunities to discover the natural and cultural richness of North Bali.',
			'Whether for beachfront relaxation, a holistic wellness retreat, or cultural exploration, Puri Bagus Lovina offers an immersive and rejuvenating escape where every element is designed to create a meaningful and memorable experience.',
		),
		'images' => array(
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-9.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-10-1.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-4.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-3.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-6.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
			array(
				'src' => 'https://puribaguslovina.com/storage/2026/08/homepage-7.jpg',
				'alt' => 'Puri Bagus Lovina',
			),
		),
		'downloads' => array( 'Factsheet', 'E-Brochure', 'Press Release' ),
		'sustain' => array(
			'title' => 'Sustainability Commitment',
			'text' => 'Sustainability is at the core of Puri Bagus Lovina’s operations. The resort integrates eco-friendly practices such as energy-efficient systems and responsible waste management while actively supporting environmental conservation efforts. By sourcing ingredients and materials from nearby communities, promoting local cultural activities, and employing local artisans, the resort contributes to preserving Bali’s natural environment and cultural heritage while creating a positive impact on the surrounding community.',
			'link' => array(
				'label' => 'Discover more',
				'url' => 'https://puribaguslovina.com/sustainability-commitment/',
			),
		),
	),
	'downloads' => array(
		'title' => 'Download Factsheet, E-Brochure & Press Release!',
		'text' => 'Please provide your email to proceed the file download.',
	),
	'villas' => array(
		'title' => 'VILLAS',
		'items' => array(
			array(
				'name' => 'Two Bedroom Pool Villa',
				'url' => 'https://puribaguslovina.com/villas/two-bedroom-pool-villa/',
				'book' => 'https://reserveonline.id/s/6AD5E26',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 50 m2 Include Wide Verandah and Bathroom',
					'Private Pool',
					'Lovina Beach View',
					'Verandah Day bed and Coffee table',
					'Non-Smoking',
					'Shower | Bathub',
				),
				'images' => array(),
			),
			array(
				'name' => 'DELUXE OCEAN VILLA',
				'url' => 'https://puribaguslovina.com/villas/deluxe-ocean-villa/',
				'book' => 'https://puribaguslovina.reserveonline.id/book/478?room_type_id%5B%5D=1617',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 49 m2 Include wide Verandah and Bathroom',
					'Lovina Beach View',
					'Verandah Day bed and Coffee table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(),
			),
			array(
				'name' => 'DELUXE GARDEN VIEW',
				'url' => 'https://puribaguslovina.com/villas/deluxe-garden-view/',
				'book' => 'https://puribaguslovina.reserveonline.id/book/478?room_type_id%5B%5D=4005',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 49 m2 Include wide Verandah and Bathroom',
					'Green Garden',
					'Verandah Day bed and Coffee table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(),
			),
			array(
				'name' => 'SUPERIOR GARDEN VIEW',
				'url' => 'https://puribaguslovina.com/villas/superior-garden-view/',
				'book' => 'https://puribaguslovina.reserveonline.id/book/478?room_type_id%5B%5D=1616',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 47 m22 Include Verandah and Bathroom',
					'Green Garden',
					'Verandah Day bed and Coffee table',
					'Non-Smoking',
					'Shower',
				),
				'images' => array(),
			),
		),
	),
	'retreat' => array(
		'kicker' => 'Puri Bagus Lovina',
		'title' => 'Group Retreat',
		'text' => 'Plan your next group retreat at Puri Bagus Lovina, where serene beachfront surroundings and lush tropical gardens create the perfect environment for relaxation and bonding. Whether you are organizing a Yoga Retreat, Meditation Retreat, Prana Chakra Healing Retreat, Sound Healing Retreat, Spiritual and Healing Retreat, Palm Reading Retreat, or Yoga Teacher Training Course, Puri Bagus Lovina offers spacious accommodations, versatile meeting venues, and a range of activities, spa treatments, and healthy fresh meals tailored to your group’s needs. With personalized service and a tranquil setting, your group retreat will be a rejuvenating and memorable experience.',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://puribaguslovina.com/group-retreat/',
		),
		'images' => array(
			'https://puribaguslovina.com/storage/2026/08/group-retreat-4.jpg',
			'https://puribaguslovina.com/storage/2026/08/group-retreat-1.jpg',
			'https://puribaguslovina.com/storage/2026/08/group-retreat-3.jpg',
			'https://puribaguslovina.com/storage/2026/08/puri-bagus-lovina-gr3.jpg',
			'https://puribaguslovina.com/storage/2026/08/puri-bagus-lovina-gr1.jpg',
		),
	),
	'farm' => array(
		'kicker' => 'Puri Bagus Lovina',
		'title' => 'The Meeting, Event & Wedding',
		'text' => '',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://puribaguslovina.com/wedding-event/',
		),
		'images' => array(
			'https://puribaguslovina.com/storage/2026/08/Meeting-Venue-Services-2-1.jpg',
			'https://puribaguslovina.com/storage/2026/08/Meeting-Venue-Services-3.jpg',
			'https://puribaguslovina.com/storage/2026/08/pblcycling.jpg',
			'https://puribaguslovina.com/storage/2026/08/Wedding-Venue-Services-4.jpg',
		),
	),
	'packages' => array(
		'title' => 'EXPERIENCES PACKAGES',
		'items' => array(
			array(
				'name' => 'Cultural Yoga',
				'url' => 'https://puribaguslovina.com/experiences/#cultural',
				'image' => 'https://puribaguslovina.com/storage/2026/08/187-1.jpg',
				'text' => 'Retain your composure with a fusion of reenergizing yoga excercises and exhilarating cultural activities in one enriching experience.',
			),
			array(
				'name' => 'Rejuvenation Spa',
				'url' => 'https://puribaguslovina.com/experiences/#Rejuvenation%20',
				'image' => 'https://puribaguslovina.com/storage/2026/08/beauty-treatment-2.jpg',
				'text' => 'Enjoy beach front a panoramic getaway from the hustle and bustle of every-day life and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical Balinese garden surroundings. Experience our different Rejuvenation spa treatments and spoil your taste buds with delicious healthy prepared meals.',
			),
			array(
				'name' => 'Spiritual Healing',
				'url' => 'https://puribaguslovina.com/experiences/#spiritual',
				'image' => 'https://puribaguslovina.com/storage/2026/08/spiritual-h3.jpg',
				'text' => 'Enjoy beach front a panoramic getaway from the hustle and bustle of every-day life and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical Balinese garden surroundings. Experience our different Rejuvenation spa treatments and spoil your taste buds with delicious healthy prepared meals.',
			),
			array(
				'name' => 'Adventure Sport',
				'url' => 'https://puribaguslovina.com/experiences/#Adventure%20',
				'image' => 'https://puribaguslovina.com/storage/2026/08/homepage-kecil.jpg',
				'text' => 'Feeling adventurous? A selection of energizing activities with various level of difficulties is ready to fulfill your cravings.',
			),
			array(
				'name' => 'Exotic Bali',
				'url' => 'https://puribaguslovina.com/experiences/#Exotic%20',
				'image' => 'https://puribaguslovina.com/storage/2026/08/exotic-bali-9.jpg',
				'text' => 'The complete collection combining every single aspect which represents the signatures of Bali in one ultimate experience.',
			),
			array(
				'name' => 'Diving',
				'url' => 'https://puribaguslovina.com/experiences/#Diving',
				'image' => 'https://puribaguslovina.com/storage/2026/08/diving-3-1.jpg',
				'text' => 'Take a deep dive into Northern Bali’s sweet spots with our friends at Orca Dive Club, explore the vast and majestic undersea life of Tulamben and Menjangan.',
			),
			array(
				'name' => 'Authentic Bali',
				'url' => 'https://puribaguslovina.com/experiences/#authenticbali',
				'image' => 'https://puribaguslovina.com/storage/2026/08/exotic-bali-2-1.jpg',
				'text' => 'The complete collection combining every single aspect which represents the signatures of Bali in one ultimate experience.',
			),
		),
	),
	'reviews' => array(
		'title' => 'Guest Review',
		'image' => 'https://puribaguslovina.com/storage/2026/08/resort-2.jpg',
		'items' => array(
			array(
				'title' => 'GREAT STAY AT PURI BAGUS',
				'author' => 'Melissa S',
				'date' => '2026-09-26',
				'text' => 'We had a wonderful stay at Puri Bagus. We were impressed by the beautifully maintained gardens, comfortable beachfront bungalow and very quiet and peaceful surrounds. The staff were friendly and the food was great. Highlight for us was the cooking lesson with resident chef, Putra. The staff went the extra mile to accommodate us when we enquired about getting some extra tv channels in our room. Special thanks to Ketut for his extra care and attention. We also loved the outdoor shower at our bungalow. The main swimming pool was a great place to relax. We had a few massages at the spa, very enjoyable experience. We didn\'t want to leave after our 8 night stay. Would definitely recommend this resort to our family and friends.',
			),
			array(
				'title' => '海豚之旅的绝佳起点',
				'author' => 'Sophia',
				'date' => '2026-08-11',
				'text' => '来之前做了攻略，知道罗威纳这边酒店都比较旧，所以报了一定预期，没想到酒店非常舒适，靠着海边度假满满，整个酒店很像一个大庄园，追海豚很方便',
			),
			array(
				'title' => 'CÉLÉBRATION D\'ANNIVERSAIRE PARFAITE',
				'author' => 'Mylène Breuzin',
				'date' => '2026-08-06',
				'text' => 'J’ai réalisé une journée package wellness dans cet hôtel à l’occasion de mon anniversaire. L’accueil est incroyable, le staff est aux petits soins et d’un très grand professionnalisme. L’hôtel est magnifique. La journée était super bien organisée, j’ai adoré ! Tout appelle au calme et à la sérénité. Merci encore à toute l’équipe pour cette journée inoubliable.',
			),
			array(
				'title' => 'НЕВЕРОЯТНАЯ ЗАБОТА И ДУШЕВНЫЙ СЕРВИС',
				'author' => 'Mariya S',
				'date' => '2026-07-07',
				'text' => 'Очень внимательный персонал! Я немного приболела, так мне в номер принесли еду , чай…. И интересовались моим здоровьем в течении оставшихся дней, выпила ли я таблетки, нужна ли мне помощь.Молодцы! Территория ухоженная и красивая! Уборка номера каждый день, вкусная еда! Отличный сервис и отдых. Спасибо за отдых♥️',
			),
			array(
				'title' => 'INCREÍBLE EXPERIENCIA Y SERVICIO EXCEPCIONAL',
				'author' => 'Laura Pérez-Rendón Pina',
				'date' => '2026-06-12',
				'text' => 'Increible. Servicio buenísimo con personas muy agradables. Todo muy limpio y con tranquilidad. El restaurante esta frente a la piscina y justo detras la playa. Tiene un camino que da directo a la arena. La cena estuvo espectacular, ademas condos personas cantando y tocando, creaban un ambiente idílico. Solo estuvimos una noche asi que no nos dio tiempo a mas, pero seguro que volveremos.',
			),
			array(
				'title' => 'HEERLIJKE SPA EN PRACHTIGE TUIN AAN ZEE',
				'author' => 'Rob van Groeningen',
				'date' => '2026-05-16',
				'text' => 'Heerlijke locatie direct aan het strand en geweldig zwembad en super mooie tuin en heerlijke spa massage en bediening staat direct klaar voor alle service en gemakken.',
			),
			array(
				'title' => 'A SERENE PARADISE WITH HEARTFELT SERVICE',
				'author' => 'Jürgen Viforcos',
				'date' => '2026-04-20',
				'text' => 'We were perfectly happy throughout our entire stay. The resort is beautiful and extremely well-maintained, with a calm and positive atmosphere. Great attention is paid to the little details, such as fresh fruit in the bungalows or lovely floral decorations. The management takes personal care of every guest, offering great suggestions and organizing tours, while regularly checking in for feedback and special requests. The staff is very attentive, polite, and open-minded, always taking the time for a personal chat or helpful tips. It was simply a wonderful stay with absolutely nothing to complain about. A place we would love to return to!',
			),
			array(
				'title' => 'HIGHLY RECOMMENDED SEASIDE ESCAPE',
				'author' => 'Besik',
				'date' => '2026-03-21',
				'text' => 'One of the best resorts in the area. Had a beautiful experience while staying at Puri Bagus, with very nice staff, great location, nice and cozy room, direct access to the beach and lovely swimming pool. Breakfast was amazing. Much recommended resort.',
			),
			array(
				'title' => '把时间浪费在美好事物上的完美住宿',
				'author' => 'Gao/XiYa',
				'date' => '2026-02-04',
				'text' => '住进罗威纳的这家酒店，才明白什么叫「躺平式度假」。 推开房门就是椰林步道，走到尽头是茅草凉亭和无边泳池。 眼前的印度洋蓝得像一块宝石，海浪声是天然的白噪音。 在这里，不用赶行程，不用找网红机位，没有拥挤的人潮，只有酒店专属的宁静与松弛。这才是我想要的巴厘岛假期，把时间浪费在所有美好的小事上。',
			),
			array(
				'title' => 'A SOLID 10: EXCEPTIONAL STAY IN LOVINA',
				'author' => 'Monica Agatha Gemma',
				'date' => '2026-01-04',
				'text' => 'Pure perfection! A stunning, spacious, and beautifully maintained resort right on the sea. Spacious bungalows with comfortable beds and a comfortable terrace with (in our case) a magnificent sea view. There\'s also an extensive breakfast buffet with a chef who prepares eggs just the way you like them. Highly professional staff who are truly dedicated to their needs. And not to forget: a fantastic, comprehensive spa and a spacious yoga room with or without an instructor. The icing on the cake: a beautiful, large infinity pool. In short: a solid 10!',
			),
		),
	),
	'discovery' => array(
		'title' => 'Bagus Discovery',
		'subtitle' => 'FOR QUALITY AND DIVERSITY',
		'items' => array(
			array(
				'name' => 'PURI BAGUS MANGGIS',
				'text' => 'A Villa Resort in a Balinese Village',
				'url' => 'http://www.puribagusmanggis.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/bagus-manggis.jpg',
			),
			array(
				'name' => 'PURI BAGUS CANDIDASA',
				'text' => 'Beach Dive Resort & Yoga MeditationRetreat',
				'url' => 'https://www.puribaguscandidasa.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/candidasa.jpg',
			),
			array(
				'name' => 'BAGUS AGRO PELAGA',
				'text' => 'Wellness Farm Resort & Lifestyle Retreat',
				'url' => 'https://bagusagropelaga.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/pelaga.jpg',
			),
			array(
				'name' => 'PURI BAGUS LOVINA',
				'text' => 'Spa Beach Resort & Yoga MeditationRetreat',
				'url' => 'https://www.puribaguslovina.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/lovina.jpg',
			),
			array(
				'name' => 'BAGUS JATI',
				'text' => 'Health & Wellbeing Retreat Resort',
				'url' => 'https://bagusjati.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/7-5.jpg',
			),
		),
	),
	'newsletter' => array(
		'title' => 'JOIN OUR MAILING LIST',
		'text' => 'Be the first to know about Our exclusive perks, events and promotions!',
	),
	'welcome' => array(
		'title' => 'Welcome to Puri Bagus Lovina',
		'promos' => array(),
		'actions' => array(
			array(
				'label' => 'Reserve Now',
				'url' => 'https://reserveonline.id/s/6920288',
				'style' => 'primary',
			),
			array(
				'label' => 'Chat With Us',
				'url' => 'https://api.whatsapp.com/send/?phone=6281288684070&text&type=phone_number&app_absent=0',
				'style' => 'ghost',
			),
			array(
				'label' => 'I Already Have a Reservation',
				'url' => 'https://puribaguslovina.reserveonline.id/book/478/check-bookings?promotions%5B%5D=9621&promotions%5B%5D=9669&promotions%5B%5D=9676',
				'style' => 'link',
			),
		),
	),
);
