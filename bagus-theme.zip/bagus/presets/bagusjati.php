<?php
/**
 * Content preset: Bagus Jati Health & Wellbeing Retreat.
 *
 * Every text, image, link and menu item below was carried over 1:1 from the
 * live bagusjati.com homepage so the new theme keeps the existing content,
 * layout order and SEO signals. Other sites can ship their own preset file
 * (copy this one into a child theme's /presets folder, or use the
 * `bagus_presets` filter) — the theme itself stays generic.
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

$u = 'https://bagusjati.com/storage/'; // Media library base (same WordPress install).

$wa = 'https://api.whatsapp.com/send/?phone=6287816992018&text&type=phone_number&app_absent=0';

return array(
	'label'   => 'Bagus Jati — Health & Wellbeing Retreat',

	'brand'   => array(
		'name'    => 'Bagus Jati',
		'tagline' => 'Health and Wellbeing Retreat',
		'logo'    => $u . '2024/06/logobjnew.png',
		'logo_alt'=> 'Icon Bagus Jati',
		'credit'  => 'Website developed and maintained by Lightandpulse',
	),

	'contact' => array(
		'reserve_url'  => 'https://reserveonline.id/s/6920267',
		'reserve_url_menu' => 'https://reserveonline.id/s/6A02F6B',
		'whatsapp_url' => $wa,
		'map_url'      => 'https://www.google.com/maps/dir/Current+Location/Bagus+Jati+Health+and+Wellbeing+Retreat',
		'contact_url'  => 'https://bagusjati.com/contact/',
		'tour_url'     => 'https://www.panomatics.com/virtualtours/in/bagusjati/index.html?startscene=0',
		'check_booking_url' => 'https://bagusjati.reserveonline.id/book/585/check-bookings',
		'booking_engine'    => 'https://bagusjati.reserveonline.id/book/585',
		'address'      => 'Br. Jati, Desa Sebatu, Kecamatan Tegallalang P.O.Box 4 – Ubud Gianyar – Bali 80561 – Indonesia',
		'street'       => 'Br. Jati, Desa Sebatu, Kecamatan Tegallalang',
		'locality'     => 'Ubud, Gianyar',
		'region'       => 'Bali',
		'postal'       => '80561',
		'country'      => 'ID',
		'phone'        => '+62361901888',
		'phone_label'  => '+ 62 361 901888',
		'fax_label'    => '+62 361 901999',
		'emails'       => array(
			array( 'label' => 'E-Mail', 'email' => 'info@bagusjati.com' ),
			array( 'label' => 'Reservation', 'email' => 'reservation@bagusjati.com' ),
			array( 'label' => 'Wedding & Event', 'email' => 'sales@bagusjati.com' ),
		),
	),

	'social' => array(
		array( 'label' => 'Facebook', 'icon' => 'facebook', 'url' => 'https://www.facebook.com/bagusjatiretreat', 'img' => $u . '2024/06/fb.png' ),
		array( 'label' => 'Instagram', 'icon' => 'instagram', 'url' => 'https://www.instagram.com/bagusjati_retreat', 'img' => $u . '2024/06/ig.png' ),
		array( 'label' => 'YouTube', 'icon' => 'youtube', 'url' => 'https://www.youtube.com/playlist?list=PLZnx3j6XT6X_TljrBIedArDSgzeQCtPZx', 'img' => $u . '2024/06/yt.png' ),
		array( 'label' => 'TikTok', 'icon' => 'tiktok', 'url' => 'https://www.tiktok.com/@bagusjatiofficial?_t=8l6T7NWotkn&_r=1', 'img' => $u . '2024/07/douyin.png' ),
		array( 'label' => 'Douyin', 'icon' => 'douyin', 'url' => 'https://www.douyin.com/user/MS4wLjABAAAAlyKhpu-NqxOlRPWKfKjgnJB90wqV16B4LDCxuyhBbpB4ZtIZ8DPoJLkasEKYH2NC', 'img' => $u . '2025/09/icon-douyin.png' ),
		array( 'label' => 'Xiaohongshu', 'icon' => 'xiaohongshu', 'url' => 'https://www.xiaohongshu.com/user/profile/68b7de0d0000000019039ff8', 'img' => $u . '2025/09/Xiaohongshu-icon.png' ),
	),

	'review_sites' => array(
		array( 'label' => 'HolidayCheck', 'url' => 'https://www.holidaycheck.de/hi/bagus-jati-health-wellbeing-retreat/8d47063d-9f05-3610-90e0-fa9e6823f0df', 'img' => $u . '2024/06/holidaycheck-logo-BW.png' ),
		array( 'label' => 'Tripadvisor', 'url' => 'https://www.tripadvisor.com/UserReviewEdit-g608497-d307182-Bagus_Jati_Health_Wellbeing_Retreat-Tegalalang_Gianyar_Regency_Bali.html', 'img' => $u . '2024/06/tripadvisor.png' ),
		array( 'label' => 'TrustYou', 'url' => '', 'img' => $u . '2024/06/trustyou.png' ),
		array( 'label' => 'Google Reviews', 'url' => 'https://g.page/r/CdfAR_K4KIDiEB0/review', 'img' => $u . '2024/07/googlerev.png' ),
	),

	/* Fallback menu = the exact structure of the current bagusjati.com menu. */
	'menu' => array(
		array( 'title' => 'The Resort', 'url' => 'https://bagusjati.com/the-resort/' ),
		array( 'title' => 'Villas', 'url' => 'https://bagusjati.com/villas/' ),
		array( 'title' => 'Offers', 'url' => 'https://bagusjati.com/special-offers/' ),
		array(
			'title'    => 'Dining',
			'url'      => '#',
			'children' => array(
				array( 'title' => 'Surya Restaurant', 'url' => 'https://bagusjati.com/dining-bagusjati/#suryaRestaurant' ),
				array( 'title' => 'Ishwari Poolside Cafe', 'url' => 'https://bagusjati.com/dining-bagusjati/#ishwari-poolside-cafe' ),
				array( 'title' => 'Room Services', 'url' => 'https://bagusjati.com/dining-bagusjati/#room-services' ),
				array( 'title' => 'BBQ Facilities & Services', 'url' => 'https://bagusjati.com/dining-bagusjati/#bbq-facilities' ),
				array( 'title' => 'Floating Brunch', 'url' => 'https://bagusjati.com/dining-bagusjati/#floating-brunch' ),
				array( 'title' => 'Picnic Lunch', 'url' => 'https://bagusjati.com/dining-bagusjati/#picnic-lunch' ),
			),
		),
		array(
			'title'    => 'Facilities',
			'url'      => '#',
			'children' => array(
				array( 'title' => 'Resort Facilities', 'url' => 'https://bagusjati.com/resort-facilities/#resort-facilities' ),
				array( 'title' => 'Special Arrangements', 'url' => 'https://bagusjati.com/resort-facilities/#special-request' ),
				array( 'title' => 'Other Services', 'url' => 'https://bagusjati.com/resort-facilities/#other-services' ),
			),
		),
		array(
			'title'    => 'Experience',
			'url'      => '#',
			'children' => array(
				array( 'title' => 'Balinese Sejati Retreat', 'url' => 'https://bagusjati.com/packages/#newstart' ),
				array( 'title' => 'Yoga & Ayurveda Retreat', 'url' => 'https://bagusjati.com/packages/#yoga' ),
				array( 'title' => 'Rejuvenation Spa Retreat', 'url' => 'https://bagusjati.com/packages/#rejuvenation' ),
				array( 'title' => 'Detox Retreat', 'url' => 'https://bagusjati.com/packages/#detox' ),
				array( 'title' => 'Spiritual Healing Retreat', 'url' => 'https://bagusjati.com/packages/#spiritual' ),
				array( 'title' => 'Couple Wellness Retreat', 'url' => 'https://bagusjati.com/packages/#couple' ),
			),
		),
		array( 'title' => 'Events', 'url' => 'https://bagusjati.com/events/' ),
		array(
			'title'    => 'Activities',
			'url'      => '#',
			'children' => array(
				array( 'title' => 'Daily Retreat', 'url' => 'https://bagusjati.com/activities/#daily' ),
				array( 'title' => 'Optional Activities', 'url' => 'https://bagusjati.com/activities/#opti' ),
			),
		),
		array(
			'title'    => 'Profile',
			'url'      => '#',
			'children' => array(
				array( 'title' => 'Media & Blog', 'url' => 'https://bagusjati.com/media-blog/' ),
				array( 'title' => 'Awards', 'url' => 'https://bagusjati.com/awards/' ),
				array( 'title' => 'Gallery', 'url' => 'https://bagusjati.com/gallery/' ),
			),
		),
		array( 'title' => 'Contact Us', 'url' => 'https://bagusjati.com/contact/' ),
	),

	'hero' => array(
		'title'    => 'BAGUS JATI',
		'subtitle' => 'HEALTH & WELLBEING RETREAT',
		'location' => 'Gianyar, Bali, 80561',
		'motto'    => 'Escape. Breathe. Heal.',
		'video'    => 'https://www.youtube.com/watch?v=tVb77gz6Gpg',
		'image'    => $u . '2024/08/1-10.jpg',
		'image_w'  => 1496,
		'image_h'  => 1125,
		'image_alt'=> 'balinese',
		'actions'  => array(
			array( 'label' => 'WhatsApp', 'icon' => 'whatsapp', 'url' => $wa ),
			array( 'label' => 'Location', 'icon' => 'pin', 'url' => 'https://www.google.com/maps/dir/Current+Location/Bagus+Jati+Health+and+Wellbeing+Retreat' ),
			array( 'label' => 'Contact Us', 'icon' => 'mail', 'url' => 'https://bagusjati.com/contact/' ),
			array( 'label' => 'Virtual Tour', 'icon' => 'tour', 'url' => 'https://www.panomatics.com/virtualtours/in/bagusjati/index.html?startscene=0' ),
		),
	),

	'quicklinks' => array(
		array( 'label' => 'Activity', 'icon' => 'walker', 'url' => 'https://bagusjati.com/activities/' ),
		array( 'label' => 'Packages', 'icon' => 'book-open', 'url' => 'https://bagusjati.com/packages/' ),
		array( 'label' => 'Dining', 'icon' => 'cloche', 'url' => 'https://bagusjati.com/dining-bagusjati/' ),
		array( 'label' => 'Offers', 'icon' => 'star-line', 'url' => 'https://bagusjati.com/special-offers/' ),
		array( 'label' => 'Spa Wellness', 'icon' => 'spa', 'url' => 'https://bagusjati.com/spa-wellness/' ),
		array( 'label' => 'Yoga Meditation', 'icon' => 'sun', 'url' => 'https://bagusjati.com/yoga/' ),
	),

	'booking' => array(
		'title'  => 'Best Rate Guarantee',
		'action' => 'https://bagusjati.reserveonline.id/book/585',
		'button' => 'Check availability',
		'adults' => array( 1, 2, 3 ),
		'children' => array( 0, 1, 2 ),
		'infants'  => array( 0, 1, 2 ),
	),

	'resort' => array(
		'kicker'     => 'The Resort',
		'title'      => 'BAGUS JATI',
		'paragraphs' => array(
			'Bagus Jati is a premier wellness retreat located in the serene rural village of Jati, nestled in the highlands of Tegallalang, Northern Ubud. Set across five hectares of lush hillside gardens surrounded by tropical forests and sweeping mountain views, the retreat offers an exceptional blend of luxury, tranquility, and holistic living. Positioned 750 meters above sea level, guests are immersed in fresh mountain air and a naturally comfortable climate ranging from 20 to 25 degrees Celsius.',
			'Guided by the Balinese philosophy of Tri Hita Karana, which emphasizes harmony between humans, nature, and the divine, every aspect of Bagus Jati is thoughtfully designed to create a balanced and enriching experience. Guests are invited to embark on a holistic wellness journey through a wide range of treatments inspired by ancient Balinese healing traditions, along with yoga and meditation sessions led by experienced practitioners. Spiritual healing programs rooted in Balinese Hindu beliefs further deepen the experience, offering a meaningful connection to the island’s cultural and spiritual heritage.',
			'Beyond wellness, Bagus Jati is also a distinguished destination for weddings, corporate retreats, and special events. With venues such as Wisnu Pavilion Complex, Balinese Djaja Compound, and Ishwari Poolside Café, each event is set against the breathtaking natural beauty of Bali. A dedicated team ensures every occasion is thoughtfully curated and seamlessly executed.',
			'Whether seeking a tranquil escape, a transformative wellness retreat, or an unforgettable event setting, Bagus Jati provides a refined sanctuary where guests can reconnect with nature, rejuvenate body and mind, and experience the cultural richness of Bali.',
		),
		'stats' => array(
			array( 'value' => '5', 'unit' => 'ha', 'label' => 'Hillside gardens' ),
			array( 'value' => '750', 'unit' => 'm', 'label' => 'Above sea level' ),
			array( 'value' => '20–25', 'unit' => '°C', 'label' => 'Mountain climate' ),
		),
		'images' => array(
			array( 'src' => $u . '2024/08/1-4.jpg', 'alt' => 'natural remedies' ),
			array( 'src' => $u . '2024/08/bjslide.jpg', 'alt' => 'natural remedies' ),
			array( 'src' => $u . '2024/08/3-4-scaled.jpg', 'alt' => 'natural remedies' ),
			array( 'src' => $u . '2024/08/4-3-scaled.jpg', 'alt' => 'natural remedies' ),
		),
		'downloads' => array( 'Factsheet', 'E-Brochure', 'Press Release' ),
		'sustain' => array(
			'title' => 'Sustainability Commitment',
			'text'  => 'Bagus Jati is committed to sustainable and responsible practices that respect both nature and community. The retreat actively implements eco-friendly initiatives such as waste reduction, energy conservation, and the use of organic products. By sourcing ingredients and materials from nearby villages, supporting local artisans, and promoting cultural activities within the community, Bagus Jati contributes to preserving Balinese traditions while creating a positive environmental and social impact',
			'link'  => array( 'label' => 'Discover more', 'url' => 'https://bagusjati.com/sustainability-commitment/' ),
		),
	),

	'downloads' => array(
		'title' => 'Download Factsheet, E-Brochure & Press Release!',
		'text'  => 'Please provide your email to proceed the file download.',
		/* File URLs are set in Appearance → Customize → Bagus: Downloads. */
	),

	'villas' => array(
		'title' => 'VILLAS',
		'items' => array(
			array(
				'name'     => 'Royal Suite Two Bedroom Pool Villa',
				'url'      => 'https://bagusjati.com/villas/type-royal-pool-villa/',
				'book'     => 'https://reserveonline.id/s/6AC601C',
				'features' => array( 'Free Wi-Fi', 'King Size Bed', 'Mosquito Net', 'Villa size 302 m2', 'Living Room 36 m2', 'Pool Size 3.2m x 8m, 1.2m deep', 'Balinese Garden View', 'Terace, Sofa Set', 'Non-Smoking', 'Separate Shower | Bathtub' ),
				'images'   => array(
					array( $u . '2024/08/Balinese-Compound-2-scaled.jpg', 'Royal Suite Two Bedroom Pool Villa' ),
					array( $u . '2024/06/9-6.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/06/1-10.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/08/2-4-1-scaled.jpg', 'Royal Suite Two Bedroom Pool Villa' ),
					array( $u . '2024/08/23-2.jpg', 'Royal Suite Two Bedroom Pool Villa' ),
					array( $u . '2024/06/3-9.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/08/24-1.jpg', 'Royal Suite Two Bedroom Pool Villa' ),
					array( $u . '2024/06/5-9.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/06/2-8.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/06/7-7.jpg', 'Royal Pool Villa' ),
					array( $u . '2024/08/25-1.jpg', 'Royal Suite Two Bedroom Pool Villa' ),
				),
			),
			array(
				'name'     => 'Two Bedroom Pool Villa',
				'url'      => 'https://bagusjati.com/villas/type-pool-villa/',
				'book'     => 'https://reserveonline.id/s/6AC600A',
				'features' => array( 'Free Wi-Fi', 'Twin Bed or King Size Bed', 'Mosquito Net', 'Villa size 62 m2 Include Terrace, Spa & Bathroom', 'Living Room 28 m2', 'Pool Size 3.2m x 8m, 1.2m deep', 'Forest View', 'Balcony Day bed and Dining table', 'Non-Smoking', 'Separate Shower | Bathtub' ),
				'images'   => array(
					array( $u . '2024/08/35-1.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/08/6-1-1.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/2-7.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2019/10/pool-villa-03.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/3-8.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/4-8.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/6-7.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/1-9.jpg', 'Two Bedroom Pool Villa' ),
					array( $u . '2024/06/9-5.jpg', 'Two Bedroom Pool Villa' ),
				),
			),
			array(
				'name'     => 'Deluxe Spa Villa',
				'url'      => 'https://bagusjati.com/villas/type-deluxe-spa-villa/',
				'book'     => 'https://reserveonline.id/s/6AC6009',
				'features' => array( 'Free Wi-Fi', 'Twin Bed or King Size Bed', 'Mosquito Net', 'Villa size 93 m2 Include Balcony and Bathroom', 'Forest & Garden View', 'Terrace Sofa & Dining Table', 'Non-Smoking', 'Separate Shower | Jacuzzi Bath' ),
				'images'   => array(
					array( $u . '2024/06/6-6.jpg', 'Deluxe Villa' ),
					array( $u . '2024/08/21-1.jpg', 'Deluxe Spa Villa' ),
					array( $u . '2024/08/22-2.jpg', 'Deluxe Spa Villa' ),
					array( $u . '2024/08/superiorvilla4.jpg', 'Deluxe Spa Villa' ),
					array( $u . '2024/06/3-7.jpg', 'Deluxe Villa' ),
					array( $u . '2024/06/8-6.jpg', 'Deluxe Villa' ),
					array( $u . '2024/06/2-6.jpg', 'Deluxe Villa' ),
					array( $u . '2024/08/20-2.jpg', 'Deluxe Spa Villa' ),
					array( $u . '2024/08/19-1.jpg', 'Deluxe Spa Villa' ),
					array( $u . '2024/06/1-8.jpg', 'Room' ),
					array( $u . '2024/08/deluxe-spa-villa-01.jpg', 'Deluxe Spa Villa' ),
				),
			),
			array(
				'name'     => 'Superior Chalet',
				'url'      => 'https://bagusjati.com/villas/type-superior-chalet/',
				'book'     => 'https://reserveonline.id/s/6AC6005',
				'features' => array( 'Free Wi-Fi', 'Twin Bed or King Size Bed', 'Villa size 52 m2 Include Balcony and Bathroom', 'Forest View', 'Balcony Day bed and Dining table', 'Non-Smoking', 'Shower' ),
				'images'   => array(
					array( $u . '2024/06/5-5.jpg', 'Superior Chalet' ),
					array( $u . '2024/06/7-3.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/2-2-1.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/3-10.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/27-1.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/28-2.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/30-1.jpg', 'Superior Chalet' ),
					array( $u . '2024/06/2-4.jpg', 'Superior Chalet' ),
					array( $u . '2024/06/4-5.jpg', 'Superior Chalet' ),
					array( $u . '2024/08/Superior-Chalet-Bathroom-Interior-1-scaled.jpg', 'Superior Chalet' ),
				),
			),
			array(
				'name'     => 'Superior Villa',
				'url'      => 'https://bagusjati.com/villas/type-superior-villa/',
				'book'     => 'https://reserveonline.id/s/6AC6007',
				'features' => array( 'Free Wi-Fi', 'Twin Bed or King Size Bed', 'Villa size 62 m2 Include Balcony and Bathroom', 'Forest View', 'Balcony Day bed and Dining table', 'Non-Smoking', 'Separate Shower | Bathtub' ),
				'images'   => array(
					array( $u . '2024/08/bjslide.jpg', 'natural remedies' ),
					array( $u . '2024/08/29-1.jpg', 'Superior Villa' ),
					array( $u . '2024/08/31-1.jpg', 'Superior Villa' ),
					array( $u . '2024/08/32-1.jpg', 'Superior Villa' ),
					array( $u . '2024/06/4-6.jpg', 'Superior Villa' ),
					array( $u . '2024/06/superior.jpeg', 'Superior Villa' ),
					array( $u . '2024/08/Superior-Villa-Interior-12-scaled.jpg', 'Superior Villa' ),
					array( $u . '2024/08/33-1.jpg', 'Superior Villa' ),
					array( $u . '2024/06/8-5.jpg', 'Superior Villa' ),
					array( $u . '2024/08/34-1.jpg', 'Superior Villa' ),
				),
			),
		),
	),

	'retreat' => array(
		'kicker' => 'Bagus Jati',
		'title'  => 'Group Retreat',
		'text'   => 'Bagus Jati is suitable for various kinds of retreat groups in our eco-green environment with fresh mountain air and pleasant climate. We have hosted many retreat groups for various occasions such as Yoga Retreat, Meditation Retreat, Prana Chakra Healing Retreat, Sound Healing Retreat, Spiritual and Healing Retreat, Yoga Teacher Training Course, Meditation Teacher Training Course, Life Coaching Retreat, Qigong Retreat, Belly Dance Retreat, Palm Reading Retreat, Tarot Reading Retreat, Astrology Retreat, to name a few.',
		'link'   => array( 'label' => 'Discover more', 'url' => 'https://bagusjati.com/group-retreat-jati/' ),
		'images' => array( $u . '2024/08/120.jpg', $u . '2024/08/119.jpg', $u . '2024/08/121.jpg', $u . '2024/08/122.jpg', $u . '2024/08/124.jpg', $u . '2024/08/123.jpg', $u . '2024/08/126.jpg', $u . '2024/08/125.jpg', $u . '2024/08/bagus-jati-retreat.jpg' ),
	),

	'packages' => array(
		'title' => 'EXPERIENCES PACKAGES',
		'items' => array(
			array( 'name' => 'BALINESE SEJATI RETREAT', 'url' => 'https://bagusjati.com/packages/#new-start', 'image' => $u . '2024/08/retreat.jpg', 'text' => 'Awaken each day with yoga and meditation, savor wholesome gourmet meals, explore the beauty of the island through cooking classes, jungle treks, or cycling adventures, and unwind with blissful spa rituals. This is your journey to rejuvenation, set amidst the tranquil hills of Ubud.' ),
			array( 'name' => 'Rejuvenation Spa Retreat', 'url' => 'https://bagusjati.com/packages/#rejuvenation', 'image' => $u . '2024/08/Rejuvenation-Spa-Retreat.jpg', 'text' => 'Enjoy a tranquil getaway from the hustle and bustle of every-day life, and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical forest surroundings. Experience our different spa treatments and spoil your taste buds with delicious freshly prepared meals.' ),
			array( 'name' => 'YOGA & AYURVEDA RETREAT', 'url' => 'https://bagusjati.com/packages/#yoga', 'image' => $u . '2024/06/packages-3.jpg', 'text' => 'Yoga and Ayurveda package help you to restore your energy levels and dissolve your stress with balanced nutritional food and detoxifying body treatments in a nurturing and natural environment.' ),
			array( 'name' => 'SPIRITUAL HEALING RETREAT', 'url' => 'https://bagusjati.com/packages/#spiritual', 'image' => $u . '2024/06/8.jpg', 'text' => 'Immerse yourself in Bali’s sacred traditions with a spiritual healing journey guided by local healers, and discover inner peace through ancient rituals passed down for generations.' ),
			array( 'name' => 'DETOX RETREAT', 'url' => 'https://bagusjati.com/packages/#detox', 'image' => $u . '2024/06/toktok.jpg', 'text' => 'This Detox programs are designed to eliminate harmful environmentally toxins built unconsciously in your system and help clear the buildup of stress that we all encounter due to the hectic demands of daily life. Detox is the essential first step in establishing a pattern of wellbeing and vitality, a pattern that should become a way of life. For those seeking a change from the stress and toxin of everyday life, this is the package for you. It includes special detoxifying diet carefully designed by our specialist for personal purposes, body treatments including Acupuncture and lifestyle counseling perfect for men and women who really appreciate preventive healing and the benefit of “time out to detoxify.”' ),
			array( 'name' => 'COUPLE WELLNESS RETREAT', 'url' => 'https://bagusjati.com/packages/#couple', 'image' => $u . '2024/06/packages-4.jpg', 'text' => 'This thoughtfully crafted round-trip package is designed to meet your every expectation for an unforgettable holiday experience.' ),
		),
	),

	'farm' => array(
		'kicker' => 'Bagus Jati',
		'title'  => 'Organic Farm Landscape',
		'text'   => 'Our Organic Farm at Bagus Jati offers a peaceful blend of nature, nourishment, and discovery, with gardens grown with care and are the source of much of the fresh produce served at the resort. Guests can stroll through rows of crisp lettuce, romaine, arugula, kale, pak choi, choy sum, radish, spinach, and eggplant, then wander among orchards of fruit including mangosteen, jackfruit, banana, durian, pomelo, tangerine, guava, water apple, papaya, and avocado. Fragrant beds of herbs like turmeric, ginger, lemongrass, galangal, and mint complete the farm’s garden-to-table experience. It is a place to slow down, breathe deeply, and rediscover where good food begins.',
		'link'   => array( 'label' => 'Discover more', 'url' => 'https://bagusjati.com/organic-farm-landscape/' ),
		'images' => array( $u . '2026/10/farm1.jpg', $u . '2026/10/farm2.jpg' ),
	),

	'wedding' => array(
		'kicker' => 'Bagus Jati',
		'title'  => 'The Wedding & Event',
		'text'   => 'Nestled in the heart of Bali’s lush green hills, Bagus Jati offers an idyllic setting for your special day, combining the serenity of nature with unparalleled luxury and wellness. Surrounded by the beauty of nature, our resort is the perfect backdrop for your dream wedding.',
		'link'   => array( 'label' => 'Discover more', 'url' => 'https://bagusjati.com/weddings-events/' ),
		'images' => array( $u . '2024/08/133.jpg', $u . '2024/08/132.jpg', $u . '2024/08/11-4.jpg', $u . '2024/08/131.jpg', $u . '2024/08/130.jpg' ),
	),

	'reviews' => array(
		'title' => 'Guest Review',
		'image' => $u . '2024/06/8-2.jpg',
		'items' => array(
			array( 'title' => 'SUPERBLY QUIET 6 NIGHTS - PERFECT FOR RELAXATION', 'date' => '2026-01-28', 'author' => 'magic k', 'text' => 'Daily yoga, plus other activities if you want to take part. Or just relax in the stunning villas, in the middle of nowhere. Wildlife, bird song, beautifully landscaped and maintained gardens. Huge choice of treatments in the spa, large swimming pool, steam room, hot tub, and excellent freshly prepared food. Can’t think of anything to criticise!' ),
			array( 'title' => 'MINDFUL HEALING JOURNEY', 'date' => '2026-02-09', 'author' => 'Taro Yanase', 'lang' => 'ja', 'text' => 'ウブドの山奥にあるリトリートヴィラで、周りは森に囲まれていて、都会の喧騒から離れてリラックスできる夢のような場所です。施設内にはテレビやラジオもなく、デジタルデトックスにも向いています。 アクティビティも充実していて、ヨガ、メディテーション、プールエクササイズ、ウォーキングなど、毎日何かしらに無料で参加できます。 特に、モーニングヨガとメディテーションは素晴らしく、楽しみながらヨガのことや身体、心のあり方などを丁寧に教えてくれます。 ブダ先生のヨガは、難しいポーズをするのではなく、身体をリラックスさせたストレッチに重点が置かれていて、身体に無理なく取り組めるので身体の硬い自分も楽しめました。 メディテーションの先生は、チャクラと感情の関係やマントラを唱えるときの声の出し方などたくさんの大切な話をじっくりしてくれて良い学びになりしました。 また是非、行きたいです！' ),
			array( 'title' => 'RECOMMENDED FOR THOSE SEEKING RELAXATION', 'date' => '2026-03-30', 'author' => 'Ayako', 'lang' => 'ja', 'text' => 'リラクゼーションを求める方におすすめ. ホテルはウブドの中心地から更に40分ほど車で行った先（テガラランライステラスを更に奥に進みます）にあります。 車を降りた瞬間空気が全く異なることを実感しました。 広大な敷地、素朴だけれどしっかり手入れされた建物、あふれる緑、すべてが深い癒しにつながりました。 あまりに広大な敷地なのでレストランに行くにも一苦労ではあったのですが、足腰に自信のない方はバギーを呼べるので安心です。私たちは夕食の後の真っ暗な夜道だけが怖かったのでその時とチェックアウトの時だけバギーをお願いしました。レストランはインテリアも素敵で食事もとてもおいしいです。外のテラス席でいただくもの気持ちが良いと思います！ ヨガは朝と夕方にレッスンが受けられます。それぞれ１．５時間、１時間とゆっくり時間をかけて行われます。先生のブダさんは日本語と英語で教えてくださいますので、英語ができなくても' ),
			array( 'title' => 'A LITTLE SLICE OF HEAVEN', 'date' => '2026-04-30', 'author' => 'Tammy Wu', 'text' => 'Bagus Jati feels like a little slice of heaven. The property has amazing views, beautiful gardens, and the pool area is gorgeous. It feels expansive, a place to immerse in nature, and is tucked away in a calm village area of Bali. We enjoyed the daily programming, particularly the morning yoga. What a refreshing way to begin each day! While we only ventured off the property a couple of times, we f' ),
			array( 'title' => 'BALINESE RETREAT IN NATURE', 'date' => '2026-05-09', 'author' => 'Momoka', 'text' => 'A Balinese retreat in the heart of nature It was wonderful to relax amidst the magnificent greenery! Just taking a stroll around the grounds is refreshing, and there are plenty of activities like yoga, so you can easily have a great time just at this facility. Waking up to a sea of green in front of me, and hearing the sounds of birds when I opened the window, made for a very pleasant start to the' ),
			array( 'title' => 'INDULGENT SPA WITH SCENIC VIEWS', 'date' => '2026-06-05', 'author' => 'Yuko', 'lang' => 'ja', 'text' => '絶景なロケーションに圧巻でした。 特にスパからの景観、ジャグジーも１人占めで最高な時間でした。 ヨガルームも素晴らしく朝ヨガもとても良かったです。アクティビティも豊富でスパトゥの滝に行きましたがそれも貴重な思い出になりました。' ),
			array( 'title' => 'A SECOND VISIT TO PARADISE', 'date' => '2026-07-14', 'author' => 'Nicole Barrett', 'text' => 'This is my second visit to Bagus Jati - the perfect destination for rest and recharge. The staff are exceptionally friendly and helpful. The location is tranquil and feels like old traditional Bali. The daily yoga and meditation classes with high quality instructors, and the spa treatments were heaven. Very much enjoyed the cooking class and exploring the self-sustaining gardens. Highly recommend,' ),
			array( 'title' => 'WARM, ATTENTIVE & FRIENDLY STAFF', 'date' => '2026-08-11', 'author' => 'Olivia Hofmann', 'lang' => 'de', 'text' => 'Wunderbar ruhiger Ort zum Abschalten und Entspannen.Das Hotelpersonal ist super aufmerksam und freundlich, sehr gut organisiert und denkt immer mit. Die Häuschen sind wunderschön eingerichtet, ruhig gelegen und sehr sauber. Jeden Tag gibt es frische Früchte und man kann flexibel Massagen oder andere Aktivitäten buchen, die gesamte Anlage ist eine Augenweide! Das Essen ist sehr gut und gesund mit s' ),
		),
	),

	'discovery' => array(
		'title'    => 'Bagus Discovery',
		'subtitle' => 'FOR QUALITY AND DIVERSITY',
		'items'    => array(
			array( 'name' => 'PURI BAGUS MANGGIS', 'text' => 'A Villa Resort in a Balinese Village', 'url' => 'http://www.puribagusmanggis.com', 'image' => $u . '2024/06/bagus-manggis.jpg' ),
			array( 'name' => 'PURI BAGUS CANDIDASA', 'text' => 'Beach Dive Resort & Yoga Meditation Retreat', 'url' => 'http://www.puribaguscandidasa.com', 'image' => $u . '2024/06/candidasa.jpg' ),
			array( 'name' => 'BAGUS AGRO PELAGA', 'text' => 'Wellness Farm Resort & Lifestyle Retreat', 'url' => 'http://www.bagusagropelaga.com', 'image' => $u . '2024/06/pelaga.jpg' ),
			array( 'name' => 'PURI BAGUS LOVINA', 'text' => 'Spa Beach Resort & Yoga Meditation Retreat', 'url' => 'http://www.puribaguslovina.com', 'image' => $u . '2024/06/lovina.jpg' ),
			array( 'name' => 'BAGUS JATI', 'text' => 'Health & Wellbeing Retreat Resort', 'url' => 'http://bagusjati.com', 'image' => $u . '2024/06/7-5.jpg' ),
		),
	),

	'newsletter' => array(
		'title' => 'JOIN OUR MAILING LIST',
		'text'  => 'Be the first to know about Our exclusive perks, events and promotions!',
	),

	'welcome' => array(
		'title'  => 'Welcome to Bagus Jati',
		'promos' => array(
			array( 'image' => $u . '2024/06/bjoctober.jpg', 'url' => 'https://reserveonline.id/s/6659366', 'label' => 'BOOK NOW' ),
			array( 'image' => $u . '2024/06/template-web-slide-promo-new-year-eve-2026-bj-01.jpg-scaled.jpeg', 'url' => 'https://reserveonline.id/s/63EA30E', 'label' => 'BOOK NOW' ),
			array( 'image' => $u . '2024/06/BJ-tahun-baru-2026-07.jpg-scaled.jpeg', 'url' => 'https://reserveonline.id/s/6B08F91', 'label' => 'BOOK NOW' ),
		),
		'actions' => array(
			array( 'label' => 'Reserve Now', 'url' => 'https://reserveonline.id/s/6920267', 'style' => 'primary' ),
			array( 'label' => 'Chat With Us', 'url' => $wa, 'style' => 'ghost' ),
			array( 'label' => 'I Already Have a Reservation', 'url' => 'https://bagusjati.reserveonline.id/book/585/check-bookings', 'style' => 'link' ),
		),
	),
);
