<?php
/**
 * Content preset: Puri Bagus Manggis — A Villa Resort in a Balinese Village.
 *
 * Texts, images, links and menu carried over from the live puribagusmanggis.com homepage
 * (extracted automatically; check and adjust in this file or in the Customizer).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

return array(
	'label' => 'Puri Bagus Manggis — A Villa Resort in a Balinese Village',
	'colors' => array(
		'primary' => '#653475',
		'secondary' => '#653475',
	),
	'brand' => array(
		'name' => 'Puri Bagus Manggis',
		'tagline' => 'Experience The Essence Of Bali',
		'logo' => 'https://puribagusmanggis.com/storage/2025/01/logoclea.png',
		'logo_alt' => 'Puri Bagus Manggis',
		'credit' => 'Website by Bagus Discovery maintain by Lightandpulse',
	),
	'contact' => array(
		'reserve_url' => 'https://reserveonline.id/s/6A02F6B',
		'reserve_url_menu' => 'https://reserveonline.id/s/6A02F6B',
		'whatsapp_url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
		'map_url' => 'https://www.google.com/maps/dir/Ubud,+Kecamatan+Ubud,+Kabupaten+Gianyar,+Bali/Puri+Bagus+Manggis+Resort,+Manggis,+Karangasem+Regency,+Bali+80871/@-8.5368681,115.2315511,11z/data=!4m13!4m12!1m5!1m1!1s0x2dd23d739f22c9c3:0x54a38afd6b773d1c!2m2!1d115.2624778!2d-8.5068536!1m5!1m1!1s0x2dd20f64d1423a3d:0xfa22bc7b0e05e1d4!2m2!1d115.5243142!2d-8.4848458?entry=ttu&g_ep=EgoyMDI2MDgxMC4wIKXMDSoASAFQAw%3D%3D',
		'contact_url' => 'https://puribagusmanggis.com/contact/',
		'tour_url' => '',
		'check_booking_url' => 'https://puribagusmanggis.reserveonline.id/book/1285/check-bookings',
		'booking_engine' => 'https://puribagusmanggis.reserveonline.id/book/1285',
		'address' => 'Desa Manggis, Kec. Manggis, Karangasem 80871 Bali – Indonesia',
		'street' => 'Desa Manggis, Kec. Manggis, Karangasem 80871 Bali – Indonesia',
		'locality' => '',
		'region' => 'Bali',
		'postal' => '80871',
		'country' => 'ID',
		'phone' => '+62361901888',
		'phone_label' => '+62 361 901888',
		'fax_label' => '+62 361 901999',
		'emails' => array(
			array(
				'label' => 'E-Mail',
				'email' => 'info@puribagusmanggis.com',
			),
			array(
				'label' => 'Reservation',
				'email' => 'reservation@puribagusmanggis.com',
			),
			array(
				'label' => 'Wedding & Event',
				'email' => 'sales@puribagusmanggis.com',
			),
		),
	),
	'social' => array(
		array(
			'label' => 'Facebook',
			'icon' => 'facebook',
			'url' => 'https://www.facebook.com/pbmanggis/',
			'img' => 'https://puribagusmanggis.com/storage/2026/08/ffb-1.png',
		),
		array(
			'label' => 'Instagram',
			'icon' => 'instagram',
			'url' => 'https://www.instagram.com/puribagusmanggis',
			'img' => 'https://puribagusmanggis.com/storage/2026/08/fig-1.png',
		),
		array(
			'label' => 'YouTube',
			'icon' => 'youtube',
			'url' => 'https://www.youtube.com/playlist?list=PLZnx3j6XT6X8YzE3r5VxWYPAalN-olL5I',
			'img' => 'https://puribagusmanggis.com/storage/2026/08/fyt.webp',
		),
		array(
			'label' => 'TikTok',
			'icon' => 'tiktok',
			'url' => 'https://www.tiktok.com/404?fromUrl=/puribaguslovina',
			'img' => 'https://puribagusmanggis.com/storage/2026/08/fdouyin.svg',
		),
		array(
			'label' => 'TikTok',
			'icon' => 'tiktok',
			'url' => 'https://www.tiktok.com/404?fromUrl=/puribaguslovina',
			'img' => 'https://puribagusmanggis.com/storage/2026/08/Xiaohongshu-icon-1.webp',
		),
	),
	'review_sites' => array(
		array(
			'label' => 'HolidayCheck',
			'url' => 'https://www.holidaycheck.de/hr/bewertungen-puri-bagus-manggis/89a1cc4b-d87b-3c79-973c-92edcd964a24',
			'img' => '',
		),
		array(
			'label' => 'Tripadvisor',
			'url' => 'https://www.tripadvisor.com/UserReviewEdit-g608489-d526791-Puri_Bagus_Manggis-Manggis_Bali.html',
			'img' => '',
		),
		array(
			'label' => 'Google Reviews',
			'url' => 'https://www.google.com/maps/place//data=!4m3!3m2!1s0x2dd20f64d1423a3d:0xfa22bc7b0e05e1d4!12e1?source=g.page.m._&laa=merchant-review-solicitation',
			'img' => '',
		),
		array(
			'label' => 'Reviews',
			'url' => 'https://puribagusmanggis.com/#',
			'img' => '',
		),
	),
	'menu' => array(
		array(
			'title' => 'The Resort',
			'url' => 'https://puribagusmanggis.com/the-resort/',
		),
		array(
			'title' => 'Villas',
			'url' => 'https://puribagusmanggis.com/villas/',
		),
		array(
			'title' => 'Offers',
			'url' => 'https://puribagusmanggis.com/special-offers/',
		),
		array(
			'title' => 'Dining',
			'url' => 'https://puribagusmanggis.com/dining/',
			'children' => array(
				array(
					'title' => 'RESTAURANT',
					'url' => 'https://puribagusmanggis.com/dining/#restaurant',
				),
				array(
					'title' => 'PICNIC LUNCH',
					'url' => 'https://puribagusmanggis.com/dining/#picnic-lunch',
				),
				array(
					'title' => 'PRIVATE ROMANTIC DINNER',
					'url' => 'https://puribagusmanggis.com/dining/#private-romantic-dinner',
				),
			),
		),
		array(
			'title' => 'Facilities',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Resort Facilities New',
					'url' => 'https://puribagusmanggis.com/resort-facilities-new/',
				),
				array(
					'title' => 'Special Arrangements',
					'url' => 'https://puribagusmanggis.com/special-arrangements/',
				),
				array(
					'title' => 'Other Services',
					'url' => 'https://puribagusmanggis.com/other-services/',
				),
			),
		),
		array(
			'title' => 'Experience',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Adventure & Sport Activities',
					'url' => 'https://puribagusmanggis.com/packages/#sport',
				),
				array(
					'title' => 'Culture Yoga Retreat',
					'url' => 'https://puribagusmanggis.com/packages/#yoga',
				),
				array(
					'title' => 'Diving',
					'url' => 'https://puribagusmanggis.com/packages/#diving',
				),
				array(
					'title' => 'Rejuvenation Spa',
					'url' => 'https://puribagusmanggis.com/packages/#spa',
				),
				array(
					'title' => 'Spiritual Healing',
					'url' => 'https://puribagusmanggis.com/packages/#healing',
				),
				array(
					'title' => 'Authentic Bali',
					'url' => 'https://puribagusmanggis.com/packages/#authenticbali',
				),
				array(
					'title' => 'Events',
					'url' => 'https://puribagusmanggis.com/events/',
				),
			),
		),
		array(
			'title' => 'Activities',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Daily Retreat',
					'url' => 'https://puribagusmanggis.com/daily-retreat/',
				),
				array(
					'title' => 'Optional Activities',
					'url' => 'https://puribagusmanggis.com/optional-activities/',
				),
			),
		),
		array(
			'title' => 'Healing',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Chakra Healing',
					'url' => 'https://puribagusmanggis.com/cakra-healing/',
				),
				array(
					'title' => 'Sound Healing',
					'url' => 'https://puribagusmanggis.com/sound-healing/',
				),
			),
		),
		array(
			'title' => 'Wedding',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Wedding & Event',
					'url' => 'https://puribagusmanggis.com/weddings-events/',
				),
			),
		),
		array(
			'title' => 'Profile',
			'url' => 'https://puribagusmanggis.com/#',
			'children' => array(
				array(
					'title' => 'Media & Blog',
					'url' => 'https://puribagusmanggis.com/media-blog/',
				),
				array(
					'title' => 'Awards',
					'url' => 'https://puribagusmanggis.com/awards/',
				),
				array(
					'title' => 'Gallery',
					'url' => 'https://puribagusmanggis.com/gallery/',
				),
				array(
					'title' => 'Contact Us',
					'url' => 'https://puribagusmanggis.com/contact/',
				),
			),
		),
	),
	'hero' => array(
		'title' => 'PURI BAGUS MANGGIS',
		'subtitle' => 'EXPERIENCE THE ESSENCE OF BALI',
		'location' => 'KARANGASEM MANGGIS, BALI, 80871',
		'motto' => '',
		'video' => '',
		'image' => 'https://puribagusmanggis.com/storage/2025/03/Resort-facilities-main-slide-1.jpg',
		'image_alt' => 'Puri Bagus Manggis',
		'actions' => array(
			array(
				'label' => 'WhatsApp',
				'icon' => 'whatsapp',
				'url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
			),
			array(
				'label' => 'Location',
				'icon' => 'pin',
				'url' => 'https://www.google.com/maps/dir/Ubud,+Kecamatan+Ubud,+Kabupaten+Gianyar,+Bali/Puri+Bagus+Manggis+Resort,+Manggis,+Karangasem+Regency,+Bali+80871/@-8.5368681,115.2315511,11z/data=!4m13!4m12!1m5!1m1!1s0x2dd23d739f22c9c3:0x54a38afd6b773d1c!2m2!1d115.2624778!2d-8.5068536!1m5!1m1!1s0x2dd20f64d1423a3d:0xfa22bc7b0e05e1d4!2m2!1d115.5243142!2d-8.4848458?entry=ttu&g_ep=EgoyMDI2MDgxMC4wIKXMDSoASAFQAw%3D%3D',
			),
			array(
				'label' => 'Contact Us',
				'icon' => 'mail',
				'url' => 'https://puribagusmanggis.com/contact/',
			),
		),
	),
	'quicklinks' => array(
		array(
			'label' => 'Activity',
			'icon' => 'walker',
			'url' => '',
		),
		array(
			'label' => 'Dining',
			'icon' => 'cloche',
			'url' => '',
		),
		array(
			'label' => 'Offers',
			'icon' => 'star-line',
			'url' => '',
		),
		array(
			'label' => 'Packages',
			'icon' => 'book-open',
			'url' => '',
		),
		array(
			'label' => 'Cakra Healing',
			'icon' => 'sun',
			'url' => '',
		),
		array(
			'label' => 'Facilities',
			'icon' => 'leaf',
			'url' => '',
		),
	),
	'booking' => array(
		'title' => 'Best Rate Guarantee',
		'action' => 'https://puribagusmanggis.reserveonline.id/book/1285',
		'button' => 'Check availability',
		'adults' => array( 1, 2, 3 ),
		'children' => array( 0, 1, 2 ),
		'infants' => array( 0, 1, 2 ),
	),
	'resort' => array(
		'kicker' => 'The Resort',
		'title' => 'PURI BAGUS MANGGIS',
		'paragraphs' => array(
			'Experience the true essence of Bali at Puri Bagus Manggis, a hidden gem nestled in the charming village of Manggis near Candidasa. Embracing a homey atmosphere and the rich architectural heritage of Balinese Karangasem Regency, this intimate retreat features seven exclusive guest rooms within a historic family compound, surrounded by 646 square meters of lush tropical gardens. With breathtaking views of rice paddies and the majestic Mount Agung, Puri Bagus Manggis is the ideal hub for exploring Padang Bai, Lombok, and the Gili Islands, just a 15-minute drive to the harbor.',
			'Perfect for holiday gatherings with family or friends, reunions, or simply as a serene escape, Puri Bagus Manggis offers cozy accommodations, a shimmering pool, and welcoming outdoor spaces designed for socializing and dining. Guests can enjoy cultural activities like Balinese cooking classes, savor local and international cuisine, and immerse themselves in the vibrant traditions of village life. With access to the facilities at our sister resort, Puri Bagus Candidasa, just 15 minutes away, your experience is enriched with diving, spa treatments, and exciting tours. Whether you seek relaxation or connection, Puri Bagus Manggis is your tranquil sanctuary in the heart of Bali',
		),
		'images' => array(
			array(
				'src' => 'https://puribagusmanggis.com/storage/2025/03/Resort-facilities-main-slide-1.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2025/03/media-and-blog-1.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2025/03/superior-room-3.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2025/03/superior-room-4.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2025/03/superior-room-5.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-47.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-48.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
			array(
				'src' => 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-49.jpg',
				'alt' => 'Puri Bagus Manggis',
			),
		),
		'downloads' => array( 'Factsheet', 'E-Brochure', 'Press Release' ),
		'sustain' => array(
			'title' => 'Sustainability Commitment',
			'text' => 'At Puri Bagus Manggis, sustainability is an integral part of daily operations and long-term vision. The resort embraces eco-friendly practices through responsible resource management, energy efficiency, and waste reduction initiatives designed to minimize environmental impact while preserving the natural beauty of East Bali. By prioritizing locally sourced ingredients and materials, the resort supports surrounding communities and reduces its footprint. This commitment extends beyond the environment through active support of local culture, including collaboration with artisans and the promotion of traditional activities, ensuring that each guest experience contributes positively to both the community and the preservation of Bali’s cultural heritage.',
			'link' => array(
				'label' => 'Discover more',
				'url' => 'https://puribagusmanggis.com/sustainability-commitment/',
			),
		),
	),
	'downloads' => array(
		'title' => 'Download Factsheet, E-Brochure & Press Release!',
		'text' => 'Please provide your email to proceed the file download.',
	),
	'villas' => array(
		'title' => 'ROOMS',
		'items' => array(
			array(
				'name' => 'Superior Room',
				'url' => 'https://puribagusmanggis.com/villas/superior-room/',
				'book' => '',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 32 m2 Include Verandah and Bathroom',
					'Garden View',
					'Coffee Table',
					'Non-Smoking',
					'Shower',
				),
				'images' => array(
					array(
						'https://puribagusmanggis.com/storage/2025/03/Resort-facilities-main-slide-1.jpg',
						'Superior Room',
					),
					array( 'https://puribagusmanggis.com/storage/2025/03/media-and-blog-1.jpg', 'Superior Room' ),
					array( 'https://puribagusmanggis.com/storage/2025/03/superior-room-3.jpg', 'Superior Room' ),
					array( 'https://puribagusmanggis.com/storage/2025/03/superior-room-4.jpg', 'Superior Room' ),
					array( 'https://puribagusmanggis.com/storage/2025/03/superior-room-5.jpg', 'Superior Room' ),
				),
			),
			array(
				'name' => 'Heritage Deluxe Room',
				'url' => 'https://puribagusmanggis.com/villas/heritage-deluxe-room/',
				'book' => '',
				'features' => array(
					'Free Wi-Fi',
					'King Size Bed',
					'Villa size 46 m2 Include Verandah and Bathroom',
					'Garden View',
					'Coffee Table',
					'Non-Smoking',
					'Shower',
				),
				'images' => array(
					array( 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-47.jpg', 'Heritage Deluxe Room' ),
					array( 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-48.jpg', 'Heritage Deluxe Room' ),
					array( 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-49.jpg', 'Heritage Deluxe Room' ),
					array( 'https://puribagusmanggis.com/storage/2026/05/Untitled-design-50.jpg', 'Heritage Deluxe Room' ),
				),
			),
		),
	),
	'retreat' => array(
		'kicker' => 'The Wedding',
		'title' => 'Intimate Balinese Wedding',
		'text' => 'Celebrate your special moments at Puri Bagus Manggis, where intimate Balinese wedding ceremonies are set amidst the enchanting beauty of lush rice paddies. Our charming venue provides a peaceful setting for couples seeking an authentic Balinese ceremony filled with romance, elegance, and unforgettable memories',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://puribagusmanggis.com/weddings-events/',
		),
		'images' => array(
			'https://puribagusmanggis.com/storage/2025/03/Wedding-and-event-Balinese-1.jpg',
			'https://puribagusmanggis.com/storage/2025/03/Wedding-and-event-Balinese-2.jpg',
			'https://puribagusmanggis.com/storage/2025/03/1newactivities-1.jpg',
		),
	),
	'packages' => array(
		'title' => 'EXPERIENCES PACKAGES',
		'items' => array(
			array(
				'name' => 'DIVING',
				'url' => 'https://puribagusmanggis.com/packages#diving',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2026/05/diving3.webp',
				'text' => 'Our diving package includes multi-day dive sessions paired with accommodation and complimentary in-house activities, ensuring an unforgettable experience.',
			),
			array(
				'name' => 'CULTURAL YOGA',
				'url' => 'https://puribagusmanggis.com/packages#yoga',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2025/03/Yoga-Meditation-Class-6.jpg',
				'text' => 'The Body, Mind & Soul Rejuvenation Program',
			),
			array(
				'name' => 'REJUVENATION SPA',
				'url' => 'https://puribagusmanggis.com/packages#spa',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2025/04/rejuvination-spa.jpg',
				'text' => 'Enjoy a tranquil getaway from the hustle and bustle of every-day life, and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical forest surroundings.',
			),
			array(
				'name' => 'SPIRITUAL HEALING',
				'url' => 'https://puribagusmanggis.com/packages#healing',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2025/03/activities-daily6.jpg',
				'text' => 'Immerse yourself in Bali’s sacred traditions with a spiritual healing journey guided by local healers, and discover inner peace through ancient rituals passed down for generations.',
			),
			array(
				'name' => 'ADVENTURE & SPORT',
				'url' => 'https://puribagusmanggis.com/packages#sport',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2026/05/Untitled-design-39.jpg',
				'text' => 'Get your heart racing with a variety of thrilling outdoor activities, from cycling through lush countryside to exploring hidden trails off the beaten path.',
			),
			array(
				'name' => 'AUTHENTIC BALI',
				'url' => 'https://puribagusmanggis.com/packages#authenticbali',
				'image' => 'https://puribagusmanggis.com/wp-content/uploads/2026/05/optional-activities10.webp',
				'text' => 'This thoughtfully crafted round-trip package is designed to meet your every expectation for an unforgettable holiday experience.',
			),
		),
	),
	'reviews' => array(
		'title' => 'Guest Review',
		'image' => 'https://puribagusmanggis.com/wp-content/uploads/2025/02/manggis7.jpg',
		'items' => array(
			array(
				'title' => 'BLISSFUL HIDDEN GEM',
				'text' => 'There were six of us on Bali and we had 3 weeks to explore the island. Puri Bagus Manggis is definitely one of the highlights of our trip. Located in a small village and captivating by its Charem and its location. Tourist crowds are searched for in vain and so we managed to make nice contacts with locals. The staff is very friendly and we were very lucky not to have to share this fantastic villa with anyone. Anytime we would come back to Manggis.',
			),
			array(
				'title' => 'A VERY SPECIAL PLACE',
				'text' => 'This hotel is located in the middle of the rice fields in a very authentic part of Bali without (much) tourism. The rooms are very separate in old Balinese style. The care is also very special and especially personal. It was an extraordinary experience for us. By the way: if you want to swim in the sea and experience the wideness of the Balinese sea, there is a free shuttle to Puri Bagus Candidasa, also a special hotel, to which we have lost our hearts.',
			),
			array(
				'title' => 'INTIMATE CULTURAL EXPERIENCE',
				'text' => 'Puri Bagus Manggis is a small village villa with 7 rooms, private temple and very private atmosphere. An ideal starting point to get in touch with the original village life or to climb the slopes of Gunung Agung on a scooter. There were six of us there for four days during the Galungan and would have liked to have stayed even longer. In Manggis you have the opportunity to experience Bali away from the tourist hustle and bustle and to get in touch with the locals.',
			),
			array(
				'title' => 'MEMORABLE STAY',
				'text' => 'Nice Place in to the nature! And a free shuttle to candi dasa and to the hotel bagus mangis candidasa. The host is really nice and will do all of his best to have a nice stay in to the hotel, thank you so much for this 3 beautiful Days.',
			),
			array(
				'title' => 'AUTHENTIC BALINESE CHARM',
				'text' => 'Super sweet traditional Small hotel in the middle of a very original and untouristic place! Located directly on a rice field! The place has a totally mystical atmosphere! Great to get to know the original Bali! Very friendly staff and great service!! I\'ll be back!!',
			),
		),
	),
	'discovery' => array(
		'title' => 'Bagus Discovery',
		'subtitle' => 'FOR QUALITY AND DIVERSITY',
		'items' => array(
			array(
				'name' => 'PURI BAGUS MANGGIS',
				'text' => 'A Villa Resort in a Balinese Village',
				'url' => 'http://www.puribagusmanggis.com/',
				'image' => 'https://puribagusmanggis.com/storage/2025/02/bagus-manggis.jpg',
			),
			array(
				'name' => 'PURI BAGUS CANDIDASA',
				'text' => 'Beach Dive Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguscandidasa.com/',
				'image' => 'https://puribagusmanggis.com/storage/2025/02/candidasa.jpg',
			),
			array(
				'name' => 'BAGUS AGRO PELAGA',
				'text' => 'Wellness Farm Resort & Lifestyle Retreat',
				'url' => 'http://www.bagusagropelaga.com/',
				'image' => 'https://puribagusmanggis.com/storage/2025/02/pelaga.jpg',
			),
			array(
				'name' => 'PURI BAGUS LOVINA',
				'text' => 'Spa Beach Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguslovina.com/',
				'image' => 'https://puribagusmanggis.com/storage/2025/02/lovina.jpg',
			),
			array(
				'name' => 'BAGUS JATI',
				'text' => 'Health & Wellbeing Retreat Resort',
				'url' => 'http://www.bagusjati.com/',
				'image' => 'https://puribagusmanggis.com/storage/2025/02/7-5.jpg',
			),
		),
	),
	'newsletter' => array(
		'title' => 'JOIN OUR MAILING LIST',
		'text' => 'Be the first to know about Our exclusive perks, events and promotions!',
	),
	'welcome' => array(
		'title' => 'Welcome to Puri Bagus Manggis',
		'promos' => array(),
		'actions' => array(
			array(
				'label' => 'Reserve Now',
				'url' => 'https://puribagusmanggis.reserveonline.id/book/1285?promotions%5B%5D=14653',
				'style' => 'primary',
			),
			array(
				'label' => 'Chat With Us',
				'url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
				'style' => 'ghost',
			),
			array(
				'label' => 'I Already Have a Reservation',
				'url' => 'https://puribagusmanggis.reserveonline.id/book/1285/check-bookings',
				'style' => 'link',
			),
		),
	),
);
