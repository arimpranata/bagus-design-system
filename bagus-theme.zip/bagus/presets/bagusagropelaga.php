<?php
/**
 * Content preset: Bagus Agro Pelaga — Wellness Farm Resort & Lifestyle Retreat.
 *
 * Texts, images, links and menu carried over from the live bagusagropelaga.com homepage
 * (extracted automatically; check and adjust in this file or in the Customizer).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

return array(
	'label' => 'Bagus Agro Pelaga — Wellness Farm Resort & Lifestyle Retreat',
	'colors' => array(
		'primary' => '#85AA45',
		'secondary' => '#546122',
	),
	'brand' => array(
		'name' => 'Bagus Agro Pelaga',
		'tagline' => 'Bali\'S First Agrotourism Site',
		'logo' => 'https://bagusagropelaga.com/storage/2015/03/logo-bagus-agro-pelaga-02.png',
		'logo_alt' => 'Bagus Agro Pelaga',
		'credit' => 'Website by Bagus Discovery maintain by Lightandpulse',
	),
	'contact' => array(
		'reserve_url' => 'https://reserveonline.id/s/6AE45D7',
		'reserve_url_menu' => 'https://bagusagropelaga.reserveonline.id/book/656',
		'whatsapp_url' => 'https://wa.me/628179339090',
		'map_url' => 'https://www.google.com/maps/dir/Current+Location/Bagus+Agro+Pelaga,+Pelaga,+Badung+Regency,+Bali,+Indonesia',
		'contact_url' => 'https://bagusagropelaga.com/contact-us/',
		'tour_url' => '',
		'check_booking_url' => 'https://bagusagropelaga.reserveonline.id/book/656/check-bookings',
		'booking_engine' => 'https://bagusagropelaga.reserveonline.id/book/656',
		'address' => 'Jalan Raya Puncak Mangu Desa Pelaga, Kecamatan Petang Badung 80353 Bali – Indonesia',
		'street' => 'Jalan Raya Puncak Mangu Desa Pelaga, Kecamatan Petang',
		'locality' => '',
		'region' => 'Bali',
		'postal' => '80353',
		'country' => 'ID',
		'phone' => '+623617998572',
		'phone_label' => '(+62) 361-799-8572',
		'fax_label' => '(+62) 361-752-779',
		'emails' => array(
			array(
				'label' => 'General Inquiries',
				'email' => 'info@bagusagropelaga.com',
			),
			array(
				'label' => 'Reservation',
				'email' => 'reservation@bagusagropelaga.com',
			),
			array(
				'label' => 'Meetings & Events',
				'email' => 'sales@bagusagropelaga.com',
			),
			array(
				'label' => 'Resort Manager',
				'email' => 'resortmanager@bagusagropelaga.com',
			),
		),
	),
	'social' => array(
		array(
			'label' => 'Facebook',
			'icon' => 'facebook',
			'url' => 'https://www.facebook.com/bagusagropelaga/?locale=id_ID',
			'img' => 'https://bagusagropelaga.com/storage/ffb-300x300.png.webp',
		),
		array(
			'label' => 'Instagram',
			'icon' => 'instagram',
			'url' => 'https://www.instagram.com/bagusagropelaga/?hl=en',
			'img' => 'https://bagusagropelaga.com/storage/fig-300x300.png.webp',
		),
		array(
			'label' => 'YouTube',
			'icon' => 'youtube',
			'url' => 'https://www.youtube.com/watch?v=urrnJ1HvckE',
			'img' => 'https://bagusagropelaga.com/storage/fyt-300x300.png.webp',
		),
		array(
			'label' => 'TikTok',
			'icon' => 'tiktok',
			'url' => 'https://www.tiktok.com/@bagusagropelaga',
			'img' => 'https://bagusagropelaga.com/storage/fdouyin-300x300.png.webp',
		),
		array(
			'label' => 'Douyin',
			'icon' => 'douyin',
			'url' => 'https://www.douyin.com/user/MS4wLjABAAAAlyKhpu-NqxOlRPWKfKjgnJB90wqV16B4LDCxuyhBbpB4ZtIZ8DPoJLkasEKYH2NC',
			'img' => 'https://bagusagropelaga.com/storage/icon-douyin.png',
		),
		array(
			'label' => 'Xiaohongshu',
			'icon' => 'xiaohongshu',
			'url' => 'https://www.xiaohongshu.com/user/profile/68b7de0d0000000019039ff8?xsec_token=YBmwhEPFCynzdhCRCtn4m0_sMeFNt5bIeTijPgTUFHYv8%3D&xsec_source=app_share&xhsshare=CopyLink&appuid=68b7de0d0000000019039ff8&apptime=1757569710&share_id=fff4061881da4e5aa61c9f3da6ebe2dd&share_channel=copy_link',
			'img' => 'https://bagusagropelaga.com/storage/Xiaohongshu-icon.png',
		),
	),
	'review_sites' => array(
		array(
			'label' => 'HolidayCheck',
			'url' => 'https://www.holidaycheck.de/hi/bagus-agro-pelaga/c0026bc2-c0bf-3c7d-9ad6-bedb5734d15c',
			'img' => 'https://bagusagropelaga.com/storage/fholidaycheck-logo-BW-300x300.png.webp',
		),
		array(
			'label' => 'Tripadvisor',
			'url' => 'https://www.tripadvisor.co.id/Hotel_Review-g8747551-d1163123-Reviews-Bagus_Agro_Pelaga-Plaga_Bali.html',
			'img' => 'https://bagusagropelaga.com/storage/ftripadvisor-300x300.png.webp',
		),
		array(
			'label' => 'Google Reviews',
			'url' => 'https://www.google.com/travel/hotels/entity/CgsIkP2_2auInYW6ARAB/overview?utm_campaign=sharing&utm_medium=link&utm_source=htls&ts=CAEaIAoCGgASGhIUCgcI6A8QChgeEgcI6A8QChgfGAEyAhAAKgkKBToDSURSGgA',
			'img' => 'https://bagusagropelaga.com/storage/fgooglerev-300x300.png.webp',
		),
	),
	'menu' => array(
		array(
			'title' => 'The Resort',
			'url' => 'https://bagusagropelaga.com/the-resort/',
		),
		array(
			'title' => 'Rooms & Villas',
			'url' => 'https://bagusagropelaga.com/rooms-villas/',
		),
		array(
			'title' => 'Offers',
			'url' => 'https://bagusagropelaga.com/special-offers/',
		),
		array(
			'title' => 'Dining',
			'url' => 'https://bagusagropelaga.com/dining-bap/',
			'children' => array(
				array(
					'title' => 'Lotus Restaurant',
					'url' => 'https://bagusagropelaga.com/dining-bap/#lotus-restaurant',
				),
				array(
					'title' => 'Mahogani Cafe & Bar',
					'url' => 'https://bagusagropelaga.com/dining-bap/#mahogani-cafe',
				),
				array(
					'title' => 'Tunjung Restaurant',
					'url' => 'https://bagusagropelaga.com/dining-bap/#tunjung-restaurant',
				),
				array(
					'title' => 'Picnic Lunch at Saung or Paon Bali',
					'url' => 'https://bagusagropelaga.com/dining-bap/#picnic-lunch',
				),
				array(
					'title' => 'Outdoor Private Romantic Dinner',
					'url' => 'https://bagusagropelaga.com/dining-bap/#outdoor-private-romantic-dinner',
				),
				array(
					'title' => 'BBQ',
					'url' => 'https://bagusagropelaga.com/dining-bap/#bbq',
				),
				array(
					'title' => 'Floating Lunch',
					'url' => 'https://bagusagropelaga.com/dining-bap/#floating-lunch',
				),
				array(
					'title' => 'Floating Breakfast',
					'url' => 'https://bagusagropelaga.com/dining-bap/#floating-breakfast',
				),
			),
		),
		array(
			'title' => 'Facilities',
			'url' => 'https://bagusagropelaga.com/resort-facilities/',
			'children' => array(
				array(
					'title' => 'Resort Map',
					'url' => 'https://bagusagropelaga.com/resort-facilities/#resort-map',
				),
				array(
					'title' => 'Resort Facilities',
					'url' => 'https://bagusagropelaga.com/resort-facilities/#resort-facilities',
				),
				array(
					'title' => 'Special Arrangements',
					'url' => 'https://bagusagropelaga.com/resort-facilities/#special-arrangements',
				),
				array(
					'title' => 'Other Services',
					'url' => 'https://bagusagropelaga.com/resort-facilities/#other-services',
				),
			),
		),
		array(
			'title' => 'Experiences',
			'url' => 'https://bagusagropelaga.com/experiences/',
			'children' => array(
				array(
					'title' => 'Sustainability Farming',
					'url' => 'https://bagusagropelaga.com/experiences/#sustainability-farming',
				),
				array(
					'title' => 'Adventure Sport',
					'url' => 'https://bagusagropelaga.com/experiences/#adventure-sport',
				),
				array(
					'title' => 'Family Healing',
					'url' => 'https://bagusagropelaga.com/experiences/#family-healing',
				),
				array(
					'title' => 'Rejuvenation Spa',
					'url' => 'https://bagusagropelaga.com/experiences/#rejuvenation',
				),
				array(
					'title' => 'Cultural Yoga',
					'url' => 'https://bagusagropelaga.com/experiences/#yoga',
				),
				array(
					'title' => 'Authentic Bali',
					'url' => 'https://bagusagropelaga.com/experiences/#authentic-bali',
				),
				array(
					'title' => 'Events',
					'url' => 'https://bagusagropelaga.com/events/',
				),
			),
		),
		array(
			'title' => 'Activities',
			'url' => 'https://bagusagropelaga.com/activities/',
			'children' => array(
				array(
					'title' => 'Daily Retreat',
					'url' => 'https://bagusagropelaga.com/activities/#daily',
				),
				array(
					'title' => 'Optional Activities',
					'url' => 'https://bagusagropelaga.com/activities/#opti',
				),
			),
		),
		array(
			'title' => 'Ayurvedic Detox',
			'url' => 'https://bagusagropelaga.com/ayurvedic-detox/',
		),
		array(
			'title' => 'Yoga & Meditation Teacher Training',
			'url' => 'https://bagusagropelaga.com/yoga-meditation-teacher-training/',
		),
		array(
			'title' => 'Profile',
			'url' => 'https://bagusagropelaga.com/#',
			'children' => array(
				array(
					'title' => 'Media & Blog',
					'url' => 'https://bagusagropelaga.com/media-blog/',
				),
				array(
					'title' => 'Awards',
					'url' => 'https://bagusagropelaga.com/awards/',
				),
				array(
					'title' => 'Gallery',
					'url' => 'https://bagusagropelaga.com/gallery-photo-video/',
				),
				array(
					'title' => 'Contact Us',
					'url' => 'https://bagusagropelaga.com/contact-us/',
				),
			),
		),
	),
	'hero' => array(
		'title' => 'BAGUS AGRO PELAGA',
		'subtitle' => 'BALI\'S FIRST AGROTOURISM SITE',
		'location' => 'Badung, Bali, 80353',
		'motto' => 'Escape. Breathe. Heal.',
		'video' => 'https://www.youtube.com/watch?v=hnhffqXOb7g',
		'image' => 'https://bagusagropelaga.com/storage/1-10-1.jpg',
		'image_alt' => 'Bagus Agro Pelaga',
		'actions' => array(
			array(
				'label' => 'WhatsApp',
				'icon' => 'whatsapp',
				'url' => 'https://wa.me/628179339090',
			),
			array(
				'label' => 'Location',
				'icon' => 'pin',
				'url' => 'https://www.google.com/maps/dir/Current+Location/Bagus+Agro+Pelaga,+Pelaga,+Badung+Regency,+Bali,+Indonesia',
			),
			array(
				'label' => 'Contact Us',
				'icon' => 'mail',
				'url' => 'https://bagusagropelaga.com/contact-us/',
			),
		),
	),
	'quicklinks' => array(
		array(
			'label' => 'Activity',
			'icon' => 'walker',
			'url' => 'https://bagusagropelaga.com/activities/',
		),
		array(
			'label' => 'Experience',
			'icon' => 'book-open',
			'url' => 'https://bagusagropelaga.com/experiences/',
		),
		array(
			'label' => 'Dining',
			'icon' => 'cloche',
			'url' => 'https://bagusagropelaga.com/dining-bap/',
		),
		array(
			'label' => 'Offers',
			'icon' => 'star-line',
			'url' => 'https://bagusagropelaga.com/special-offers/',
		),
		array(
			'label' => 'Spa Wellness',
			'icon' => 'spa',
			'url' => 'https://bagusagropelaga.com/spa-wellness/',
		),
		array(
			'label' => 'Yoga Meditation',
			'icon' => 'sun',
			'url' => 'https://bagusagropelaga.com/yoga/',
		),
	),
	'booking' => array(
		'title' => 'Best Rate Guarantee',
		'action' => 'https://bagusagropelaga.reserveonline.id/book/656',
		'button' => 'Check availability',
		'adults' => array( 1, 2, 3 ),
		'children' => array( 0, 1, 2 ),
		'infants' => array( 0, 1, 2 ),
	),
	'resort' => array(
		'kicker' => 'THE RESORT',
		'title' => 'BAGUS AGRO PELAGA',
		'paragraphs' => array(),
		'images' => array(
			array(
				'src' => 'https://bagusagropelaga.com/storage/meetingroom.jpg',
				'alt' => 'Bagus Agro Pelaga',
			),
			array(
				'src' => 'https://bagusagropelaga.com/storage/Page-1-2.jpg',
				'alt' => 'Bagus Agro Pelaga',
			),
			array(
				'src' => 'https://bagusagropelaga.com/storage/Page-2-2.jpg',
				'alt' => 'Bagus Agro Pelaga',
			),
			array(
				'src' => 'https://bagusagropelaga.com/storage/Page-3-2.jpg',
				'alt' => 'Bagus Agro Pelaga',
			),
			array(
				'src' => 'https://bagusagropelaga.com/storage/Page-6-1.jpg',
				'alt' => 'Bagus Agro Pelaga',
			),
		),
		'downloads' => array( 'Factsheet', 'E-Brochure', 'Press Release' ),
		'sustain' => array(
			'title' => 'Sustainability Commitment',
			'text' => 'Sustainability is at the core of Bagus Agro Pelaga and is reflected in every aspect of its operations. The resort practices organic farming, responsible sourcing, and environmentally conscious production methods to reduce its ecological footprint. Waste reduction and recycling programs are actively implemented, while energy conservation efforts include the use of renewable energy and water saving technologies. Through these initiatives, Bagus Agro Pelaga continues to protect the natural environment while supporting local communities and promoting a more sustainable future.',
			'link' => array(
				'label' => 'Discover more',
				'url' => 'https://bagusagropelaga.com/sustainability-commitment/',
			),
		),
	),
	'downloads' => array(
		'title' => 'Download Factsheet, E-Brochure & Press Release!',
		'text' => 'Please provide your email to proceed the file download.',
	),
	'villas' => array(
		'title' => 'VILLA',
		'items' => array(
			array(
				'name' => 'SUPERIOR FARM ROOM​​',
				'url' => 'https://bagusagropelaga.com/rooms-villas/superior-farm-room/',
				'book' => 'https://reserveonline.id/s/6AC5FD0',
				'features' => array(
					'Terrace',
					'Mini Bar',
					'IDD Telephone',
					'Tea/Coffee Making',
					'Coffee Table',
					'28 m2',
					'Walk in Shower',
					'Hair Dryer',
					'Bathroom Amenities',
					'Slipper',
					'Umbrella',
					'Safety Box on Request',
				),
				'images' => array(
					array( 'https://bagusagropelaga.com/storage/Superior-Farm-Room.jpg', 'SUPERIOR FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Superior-Farm-Room-2.jpg', 'SUPERIOR FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Superior-Farm-Room-3.jpg', 'SUPERIOR FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Superior-Farm-Room-4.jpg', 'SUPERIOR FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Superior-Farm-Room-5.jpg', 'SUPERIOR FARM ROOM' ),
				),
			),
			array(
				'name' => 'DELUXE FARM ROOM',
				'url' => 'https://bagusagropelaga.com/rooms-villas/deluxe-farm-room/',
				'book' => 'https://reserveonline.id/s/6AC5FD9',
				'features' => array(
					'Balcony',
					'Mini Bar',
					'IDD Telephone',
					'Tea/Coffee Making',
					'Coffee Table',
					'39 m2',
					'Walk in Shower',
					'Hair Dryer',
					'Bathrobes',
					'Bathroom Amenities',
					'Slipper',
					'Umbrella',
					'Extra Bed on Request',
					'Safety Box on Request',
				),
				'images' => array(
					array( 'https://bagusagropelaga.com/storage/Deluxe-Farm-Room-1.jpg', 'DELUXE FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Deluxe-Farm-Room-2.jpg', 'DELUXE FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Deluxe-Farm-Room-3.jpg', 'DELUXE FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Deluxe-Farm-Room-4.jpg', 'DELUXE FARM ROOM' ),
					array( 'https://bagusagropelaga.com/storage/Deluxe-Farm-Room-5.jpg', 'DELUXE FARM ROOM' ),
				),
			),
			array(
				'name' => 'LUXURY FARM VILLA​',
				'url' => 'https://bagusagropelaga.com/rooms-villas/luxury-farm-villa/',
				'book' => 'https://reserveonline.id/s/6AC5FEB',
				'features' => array(
					'Balcony',
					'Mini Bar',
					'IDD Telephone',
					'Tea/Coffee Making',
					'Coffee Table',
					'59 m2',
					'Walk in Shower',
					'Hair Dryer',
					'Bathrobes',
					'Bathroom Amenities',
					'Slipper',
					'Umbrella',
					'Safety Box on Request',
				),
				'images' => array(
					array( 'https://bagusagropelaga.com/storage/Luxury-Farm-Villa-1.jpg', 'LUXURY FARM VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Luxury-Farm-Villa-2.jpg', 'LUXURY FARM VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Luxury-Farm-Villa-3.jpg', 'LUXURY FARM VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Luxury-Farm-Villa-4.jpg', 'LUXURY FARM VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Luxury-Farm-Villa-5.jpg', 'LUXURY FARM VILLA' ),
				),
			),
			array(
				'name' => 'TWO-BEDROOM POOL VILLA',
				'url' => 'https://bagusagropelaga.com/rooms-villas/two-bedroom-pool-villa/',
				'book' => 'https://reserveonline.id/s/6AC5FEF',
				'features' => array(
					'Private Pool',
					'Balcony',
					'Dining & Kitchenette',
					'Living Room',
					'Mini Bar',
					'IDD Telephone',
					'Tea/Coffee Making',
					'166 m2',
					'Bathtub',
					'Walk in Shower',
					'Hair Dryer',
					'Bathrobes',
					'Bathroom Amenities',
					'Slipper',
					'Umbrella',
					'Safety Box',
					'Coffee Table',
				),
				'images' => array(
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa-1.jpg', 'TWO-BEDROOM POOL VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa-2-1.jpg', 'TWO-BEDROOM POOL VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa.jpg', 'TWO-BEDROOM POOL VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa-2.jpg', 'TWO-BEDROOM POOL VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa-3.jpg', 'TWO-BEDROOM POOL VILLA' ),
					array( 'https://bagusagropelaga.com/storage/Two-Bedroom-Pool-Villa-4.jpg', 'TWO-BEDROOM POOL VILLA' ),
				),
			),
		),
	),
	'retreat' => array(
		'kicker' => 'Bagus Agro Pelaga',
		'title' => 'Group Retreat',
		'text' => 'Bagus Agro Pelaga is a suitable venue for retreat groups, set amidst vast organic farmlands, rolling hills, and the refreshing cool air of central Bali’s highlands. Surrounded by lush greenery and serene landscapes, it provides the perfect environment for balance, renewal, and creative exploration. We have welcomed groups for diverse occasions such as Yoga Retreats, Meditation Retreats, Prana Chakra Healing Retreats, Sound Healing Retreats, Spiritual and Healing Retreats, Yoga Teacher Training Courses, Meditation Teacher Training Courses, Life Coaching Retreats, Qigong Retreats, Sustainability Workshops, and Team-Building Programs, to name a few.',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://bagusagropelaga.com/group-retreat',
		),
		'images' => array(
			'http://bagusagropelaga.com/storage/1-3.jpg',
			'http://bagusagropelaga.com/storage/2-1.jpg',
			'http://bagusagropelaga.com/storage/3.3.jpg',
			'http://bagusagropelaga.com/storage/4-2.jpg',
			'http://bagusagropelaga.com/storage/5-2.jpg',
		),
	),
	'farm' => array(
		'kicker' => 'Bagus Agro Pelaga',
		'title' => 'Wellness Farm',
		'text' => 'In the immaculate highlands of Bali, our Wellness Farm presents a special blend of leisure, learning, and entertainment. Nestled among lush surroundings and cool mountain air, the farm offers an ideal location for a variety of events, including group gatherings, educational tours, outbound experiences, and other recreational outing programs. Guests can enjoy hands-on farm activities and pick their own fresh produce straight from the field, from juicy strawberries and sweet potatoes to a variety of other seasonal crops grown in the fertile soil of Pelaga. Step inside our greenhouse to discover beautiful Holland Roses, flourishing in Bagus Agro Pelaga’s perfect highland climate and creating a lovely backdrop for photos and a peaceful moment to slow down. Our Wellness Farm offers unique activities suitable for everyone, whether your search is for a quiet haven or an intriguing group experience.',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://bagusagropelaga.com/wellness-farm/',
		),
		'images' => array(
			'http://bagusagropelaga.com/storage/resort-facilities6.jpg',
			'http://bagusagropelaga.com/storage/resort-facilities5.jpg',
			'http://bagusagropelaga.com/storage/resort-facilities4.jpg',
			'http://bagusagropelaga.com/storage/resort-facilities3.jpg',
		),
	),
	'wedding' => array(
		'kicker' => 'Bagus Agro Pelaga',
		'title' => 'The Meeting, Event & Wedding',
		'text' => 'Perfect for couples looking for a mix of natural beauty and cultural appeal, Bagus Agro presents a lovely and calm wedding venue. Set amid lush greenery with amazing mountain views at 950 meters above sea level, the location offers a romantic and peaceful environment. Access to breathtaking outdoor locations, traditional and foreign cuisine, and expert planning services to guarantee a perfect celebration comprise wedding packages.',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://bagusagropelaga.com/weddings-events/',
		),
		'images' => array(
			'http://bagusagropelaga.com/storage/wedding-service-7.jpg',
			'http://bagusagropelaga.com/storage/2017/04/2-Jaya-Graha-Meetingroom-1.jpg',
			'http://bagusagropelaga.com/storage/2017/04/3-Executive-Meetingroom-1.jpg',
			'http://bagusagropelaga.com/storage/bapevent5-1.jpg',
		),
	),
	'packages' => array(
		'title' => 'EXPERIENCES PACKAGES',
		'items' => array(
			array(
				'name' => 'Sustainability Farming',
				'url' => 'https://bagusagropelaga.com/experiences/#sustainability-farming',
				'image' => 'http://bagusagropelaga.com/storage/2017/04/agro-plantations-07.jpg',
				'text' => 'Wake up to the scent of fresh soil and morning dew. Wander through our organic gardens, hand-pick vegetables for your next meal, and reconnect with the rhythm of the earth. Nestled in the tranquil hills of Ubud, this is where mindful living begins.',
			),
			array(
				'name' => 'Adventure Sport',
				'url' => 'https://bagusagropelaga.com/experiences/#adventure-sport',
				'image' => 'https://bagusagropelaga.com/storage/Page-5-1.jpg',
				'text' => 'Feeling adventurous? A selection of energizing activities with various level of difficulties is ready to fulfill your cravings.',
			),
			array(
				'name' => 'Family Healing',
				'url' => 'https://bagusagropelaga.com/experiences/#family-healing',
				'image' => 'https://bagusagropelaga.com/storage/2015/03/pelaga-family.jpg',
				'text' => 'Embark on a family wellness retreat that invites you to reconnect with nature and each other, creating a space for rejuvenation and renewal.',
			),
			array(
				'name' => 'Rejuvenation Spa',
				'url' => 'https://bagusagropelaga.com/experiences/#rejuvenation',
				'image' => 'https://bagusagropelaga.com/storage/1-20-33.jpg',
				'text' => 'Enjoy a tranquil getaway from the hustle and bustle of every-day life, and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical forest surroundings. Experience our different spa treatments and spoil your taste buds with delicious freshly prepared meals.',
			),
			array(
				'name' => 'Cultural Yoga',
				'url' => 'https://bagusagropelaga.com/experiences/#yoga',
				'image' => 'https://bagusagropelaga.com/storage/2015/03/retreat-lifestyle.jpg',
				'text' => 'Cultural Yoga package help you to restore your energy levels and dissolve your stress with balanced nutritional food and detoxifying body treatments in a nurturing and natural environment.',
			),
			array(
				'name' => 'Authentic Bali',
				'url' => 'https://bagusagropelaga.com/experiences/#authentic-bali',
				'image' => 'https://bagusagropelaga.com/storage/penglipuran.jpg',
				'text' => 'This thoughtfully crafted round-trip package is designed to meet your every expectation for an unforgettable holiday experience.',
			),
		),
	),
	'reviews' => array(
		'title' => 'Guest Review',
		'image' => 'https://bagusagropelaga.com/storage/Exterior-Luxury-Villa-and-Hotel-area-scaled.jpg',
		'items' => array(
			array(
				'title' => 'LOKASI STRATEGIS DI BADUNG UTARA',
				'author' => 'Febri Ana',
				'date' => '2026-08-24',
				'text' => 'Salah satu lokasi menginap yg strategis di badung utara, dekat dengan jembatan tukad bangkung, start poin pendakian puncak manggu, air terjun tukad bangkung dan banyak wisata alam yg indah di sekitaran badung utara.',
			),
			array(
				'title' => 'STUNNING TWIN MOUNTAIN & SUNRISE VIEWS',
				'author' => 'Candy Vanneque',
				'date' => '2026-05-29',
				'text' => 'Experienced such a calming, back-to-nature staycation with my 2 teenage sons. If you\'re looking for a peaceful escape surrounded by huge plantation and fresh mountain air, you\'ll love this place. The property itself is massive and located near Jembatan Bangkung. We really enjoyed trekking around the area, and they also provide bicycles for rent if you want to explore more of the surroundings. One if the highlights was the bonfire setup, which can be arranges upon request and is highly recommended. Sitting around the fire under the stars, listening only to the sounds of nature, was such a peaceful experience. Don\'t forget to wake up early for the sunrise, you\'ll be rewarded with a stunning view of the twin mountain from afar. Ms. Ika and the team were friendly and welcoming, making sure we had the best experience during our stay. They offer rooms ranging from budget friendly options to more exclusive stays, so you can choose based on your budget. The property also has a beautiful rose garden, various plantations, a lovely spa and yoga area, and relaxing swimming pool. Overall, it was such a refreshing and memorable staycation experience.',
			),
			array(
				'title' => 'FRIENDLY AND MAGICAL STAY',
				'author' => 'THOMAS -',
				'date' => '2025-08-02',
				'text' => 'A wonderful, magical place with the friendliest people I\'ve ever met. Plus, top-notch accommodations with the most beautiful view. We\'d love to come back.',
			),
			array(
				'title' => 'DELICIOUS & DELIGHTFUL DINING EXPERIENCE',
				'author' => 'R T',
				'date' => '2026-06-23',
				'text' => 'It was a wonderful place. The food was delicious, and the staff were kind and courteous. I was especially touched and warmed by the fact that Rama spoke to me in Japanese. Thank you so much. I would definitely love to stay here again if I visit Bali in the future. I wholeheartedly recommend this place.♡',
			),
			array(
				'title' => 'IDEAL UNTUK GATHERING, OUTING & TEAM BUILDING',
				'author' => 'Mutimedia GKT Denpasar',
				'date' => '2026-05-14',
				'text' => 'Gereja Kristus Tuhan Ibadah Padang & Outing Ke Bagus Agro Pelaga. Pelayanan dari pimpinan dan staff yg premium, Wantilan yg luas dan nyaman. Toilet terjamin kebersihannya. Pemandangan hutan yg hijau dan udara bersih segar untuk kesehatan mental, pikiran dan fisik gathering, outing & team building.',
			),
			array(
				'title' => 'DESTINASI HEALING & RELAKSASI',
				'author' => 'Ovy Dwijayanthi',
				'date' => '2026-04-28',
				'text' => 'Nyaman banget tempatnyaa cocok buat healing bareng org tersayang',
			),
			array(
				'title' => 'SERENE & PEACEFUL ESCAPE',
				'author' => 'Loris Monteux',
				'date' => '2026-03-01',
				'text' => 'Amazing place in a quite aera of Bali. Perfect to explore around and the staff is amazing.',
			),
			array(
				'title' => 'THIS PLACE IS BEAUTIFUL',
				'author' => 'Roman Provorov',
				'date' => '2026-02-10',
				'text' => 'Место красивое. По смотреть точно надо. Можно отдохнуть и большой компанией. Занятия йоги проходили при нас.',
			),
			array(
				'title' => 'THE OTHER SIDE OF BALI ESCAPE',
				'author' => 'Niko Wicaksono',
				'date' => '2026-07-04',
				'text' => 'Stayed at Bagus Agro Pelaga in Petang, Badung for just 1 night, but it was amazing. The place is so quiet and peaceful. This is the other side of Bali that people must visit if they want a break from beaches and the busy city. The rooms are not modern, but they are very clean and well-maintained. Not to forget, big thanks to Ibu Ika for helping me so much with the booking. Highly recommended!',
			),
		),
	),
	'discovery' => array(
		'title' => 'Bagus Discovery',
		'subtitle' => 'FOR QUALITY AND DIVERSITY',
		'items' => array(
			array(
				'name' => 'PURI BAGUS MANGGIS',
				'text' => 'A Villa Resort in a Balinese Village',
				'url' => 'http://www.puribagusmanggis.com/',
				'image' => 'https://bagusagropelaga.com/storage/bagus-manggis-1.jpg',
			),
			array(
				'name' => 'PURI BAGUS CANDIDASA',
				'text' => 'Beach Dive Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguscandidasa.com/',
				'image' => 'https://bagusagropelaga.com/storage/candidasa-1.jpg',
			),
			array(
				'name' => 'BAGUS AGRO PELAGA',
				'text' => 'Wellness Farm Resort & Lifestyle Retreat',
				'url' => 'http://www.bagusagropelaga.com/',
				'image' => 'https://bagusagropelaga.com/storage/pelaga-1.jpg',
			),
			array(
				'name' => 'PURI BAGUS LOVINA',
				'text' => 'Spa Beach Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguslovina.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/lovina.jpg',
			),
			array(
				'name' => 'BAGUS JATI',
				'text' => 'Health & Wellbeing Retreat Resort',
				'url' => 'http://www.bagusjati.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/7-5.jpg',
			),
		),
	),
	'newsletter' => array(
		'title' => 'JOIN OUR MAILING LIST',
		'text' => 'Be the first to know about Our exclusive perks, events and promotions!',
	),
	'welcome' => array(
		'title' => 'Welcome to Bagus Agro Pelaga',
		'promos' => array(),
		'actions' => array(
			array(
				'label' => 'Reserve Now',
				'url' => 'https://reserveonline.id/s/692028F',
				'style' => 'primary',
			),
			array(
				'label' => 'Chat With Us',
				'url' => 'https://api.whatsapp.com/send/?phone=628179339090&text&type=phone_number&app_absent=0',
				'style' => 'ghost',
			),
			array(
				'label' => 'I Already Have a Reservation',
				'url' => 'https://bagusagropelaga.reserveonline.id/book/656/check-bookings',
				'style' => 'link',
			),
		),
	),
);
