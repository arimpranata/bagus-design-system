<?php
/**
 * Content preset: Puri Bagus Candidasa — Beach Dive Resort & Yoga Meditation Retreat.
 *
 * Texts, images, links and menu carried over from the live www.puribaguscandidasa.com homepage
 * (extracted automatically; check and adjust in this file or in the Customizer).
 *
 * @package Bagus
 */

defined( 'ABSPATH' ) || exit;

return array(
	'label' => 'Puri Bagus Candidasa — Beach Dive Resort & Yoga Meditation Retreat',
	'colors' => array(
		'primary' => '#084975',
		'secondary' => '#084975',
	),
	'brand' => array(
		'name' => 'Puri Bagus Candidasa',
		'tagline' => 'A Heaven Of Peace & Graceful Service',
		'logo' => 'https://www.puribaguscandidasa.com/storage/2017/11/logo-puri-bagus-candidasa-02.png',
		'logo_alt' => 'Puri Bagus Candidasa logo white text',
		'credit' => 'Website by Bagus Discovery maintain by Lightandpulse',
	),
	'contact' => array(
		'reserve_url' => 'https://puribaguscandidasa.reserveonline.id/book/477?promotions%5B%5D=9619&promotions%5B%5D=12099&promotions%5B%5D=12100',
		'reserve_url_menu' => 'https://reserveonline.id/s/6A02F6B',
		'whatsapp_url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
		'map_url' => 'https://www.google.com/maps/place/Puri+Bagus+Candidasa+Resort/@-8.5137519,115.5766493,17z/data=!4m9!3m8!1s0x2dd2092c99aa7f75:0x32478ed769575cca!5m2!4m1!1i2!8m2!3d-8.5137519!4d115.5792242!16s%2Fg%2F1tdjmyz2?entry=tts&g_ep=EgoyMDI0MDkzMC4wIPu8ASoASAFQAw%3D%3D',
		'contact_url' => 'https://www.puribaguscandidasa.com/contact-us/',
		'tour_url' => '',
		'check_booking_url' => 'https://puribaguscandidasa.reserveonline.id/book/477/check-bookings?promotions%5B%5D=9619&promotions%5B%5D=12099&promotions%5B%5D=12100',
		'booking_engine' => 'https://puribaguscandidasa.reserveonline.id/book/477',
		'address' => 'Jalan Puri Bagus, Desa Bugbug, Kec. Karangasem, Kabupaten Karangasem 80811 Bali – Indonesia, P.O. Box 129 Candidasa',
		'street' => 'Jalan Puri Bagus, Desa Bugbug, Kec. Karangasem, Kabupaten Karangasem 80811 Bali – Indonesia, P.O. Box 129 Candidasa',
		'locality' => '',
		'region' => 'Bali',
		'postal' => '80811',
		'country' => 'ID',
		'phone' => '+6236341131',
		'phone_label' => '+62 363 41131',
		'fax_label' => '+62 363 41290',
		'emails' => array(
			array(
				'label' => 'E-Mail',
				'email' => 'info@puribaguscandidasa.com',
			),
			array(
				'label' => 'Reservation',
				'email' => 'reservation@puribaguscandidasa.com',
			),
			array(
				'label' => 'Wedding & Event',
				'email' => 'sales@puribaguscandidasa.com',
			),
		),
	),
	'social' => array(
		array(
			'label' => 'Facebook',
			'icon' => 'facebook',
			'url' => 'https://www.facebook.com/puribaguscandidasa/',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/ffb-300x300.png.webp',
		),
		array(
			'label' => 'Instagram',
			'icon' => 'instagram',
			'url' => 'https://www.instagram.com/puribaguscandidasa/',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/fig-300x300.png.webp',
		),
		array(
			'label' => 'YouTube',
			'icon' => 'youtube',
			'url' => 'https://www.youtube.com/playlist?list=PLZnx3j6XT6X9nkEP50yZfnzOSxLNquKvZ',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/fyt-300x300.png.webp',
		),
		array(
			'label' => 'TikTok',
			'icon' => 'tiktok',
			'url' => 'https://www.tiktok.com/@puribaguscandidasa.id?_t=8l6RSp1Jw6J&_r=1',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/fdouyin-300x300.png.webp',
		),
		array(
			'label' => 'Douyin',
			'icon' => 'douyin',
			'url' => 'https://www.douyin.com/user/MS4wLjABAAAAlyKhpu-NqxOlRPWKfKjgnJB90wqV16B4LDCxuyhBbpB4ZtIZ8DPoJLkasEKYH2NC',
			'img' => 'https://www.puribaguscandidasa.com/storage/2025/09/icon-douyin-1.png',
		),
		array(
			'label' => 'Xiaohongshu',
			'icon' => 'xiaohongshu',
			'url' => 'https://www.xiaohongshu.com/user/profile/68b7de0d0000000019039ff8?xsec_token=YBmwhEPFCynzdhCRCtn4m0_sMeFNt5bIeTijPgTUFHYv8%3D&xsec_source=app_share&xhsshare=CopyLink&appuid=68b7de0d0000000019039ff8&apptime=1757569710&share_id=fff4061881da4e5aa61c9f3da6ebe2dd&share_channel=copy_link',
			'img' => 'https://www.puribaguscandidasa.com/storage/2025/09/Xiaohongshu-icon-1.png',
		),
	),
	'review_sites' => array(
		array(
			'label' => 'HolidayCheck',
			'url' => 'https://www.holidaycheck.de/hi/puri-bagus-candidasa/4e56e05e-c4c3-3eda-bc13-c573306a3f89',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/fholidaycheck-logo-BW-300x300.png.webp',
		),
		array(
			'label' => 'Tripadvisor',
			'url' => 'https://www.tripadvisor.com/Hotel_Review-g312684-d309677-Reviews-Puri_Bagus_Candidasa-Candidasa_Karangasem_Bali.html',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/ftripadvisor-300x300.png.webp',
		),
		array(
			'label' => 'Google Reviews',
			'url' => 'https://g.page/r/CcpcV2nXjkcyEB0/review',
			'img' => 'https://www.puribaguscandidasa.com/storage/2024/10/fgooglerev-300x300.png.webp',
		),
	),
	'menu' => array(
		array(
			'title' => 'The Resort',
			'url' => 'https://www.puribaguscandidasa.com/the-resort/',
		),
		array(
			'title' => 'Villas',
			'url' => 'https://www.puribaguscandidasa.com/villas/',
		),
		array(
			'title' => 'Offers',
			'url' => 'https://www.puribaguscandidasa.com/special-offers/',
		),
		array(
			'title' => 'Dining',
			'url' => 'https://www.puribaguscandidasa.com/#',
			'children' => array(
				array(
					'title' => 'Geringsing Restaurant',
					'url' => 'https://www.puribaguscandidasa.com/dining/#geringsing',
				),
				array(
					'title' => 'Hasta Putra Bar',
					'url' => 'https://www.puribaguscandidasa.com/dining/#hasta',
				),
				array(
					'title' => 'SEAVIEW GRILL HOUSE',
					'url' => 'https://www.puribaguscandidasa.com/dining/#seaview',
				),
				array(
					'title' => 'ROOM SERVICE',
					'url' => 'https://www.puribaguscandidasa.com/dining/#room',
				),
				array(
					'title' => 'BEACH FRONT GAZEBO PICNIC LUNCH',
					'url' => 'https://www.puribaguscandidasa.com/dining/#beach',
				),
				array(
					'title' => 'PRIVATE ROMANTIC DINNER',
					'url' => 'https://www.puribaguscandidasa.com/dining/#private',
				),
			),
		),
		array(
			'title' => 'Facilities',
			'url' => 'https://www.puribaguscandidasa.com/#',
			'children' => array(
				array(
					'title' => 'Resort Facilities',
					'url' => 'https://www.puribaguscandidasa.com/resort-facilities/#Resort',
				),
				array(
					'title' => 'SPECIAL REQUEST ARRANGEMENTS',
					'url' => 'https://www.puribaguscandidasa.com/resort-facilities/#Special',
				),
				array(
					'title' => 'Other Services',
					'url' => 'https://www.puribaguscandidasa.com/resort-facilities/#Other',
				),
			),
		),
		array(
			'title' => 'Experience',
			'url' => 'https://www.puribaguscandidasa.com/#',
			'children' => array(
				array(
					'title' => 'Diving',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#diving',
				),
				array(
					'title' => 'Cultural Yoga',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#yoga',
				),
				array(
					'title' => 'Rejuvenation Spa',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#spa',
				),
				array(
					'title' => 'Spirititual Healing',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#healing',
				),
				array(
					'title' => 'Adventure Sport',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#sport',
				),
				array(
					'title' => 'Authentic Bali',
					'url' => 'https://www.puribaguscandidasa.com/experiences/#authenticbali',
				),
				array(
					'title' => 'Events',
					'url' => 'https://www.puribaguscandidasa.com/events/',
				),
			),
		),
		array(
			'title' => 'Activities',
			'url' => 'https://www.puribaguscandidasa.com/#',
			'children' => array(
				array(
					'title' => 'Daily Culture & Retreat Activities',
					'url' => 'https://www.puribaguscandidasa.com/puri-bagus-candidasa-activities/#daily',
				),
				array(
					'title' => 'Optional Activities',
					'url' => 'https://www.puribaguscandidasa.com/puri-bagus-candidasa-activities/#optional',
				),
			),
		),
		array(
			'title' => 'Profile',
			'url' => 'https://www.puribaguscandidasa.com/#',
			'children' => array(
				array(
					'title' => 'Media & Blog',
					'url' => 'https://www.puribaguscandidasa.com/media-blog/',
				),
				array(
					'title' => 'Awards',
					'url' => 'https://www.puribaguscandidasa.com/awards/',
				),
				array(
					'title' => 'Gallery',
					'url' => 'https://www.puribaguscandidasa.com/gallery/',
				),
				array(
					'title' => 'Contact Us',
					'url' => 'https://www.puribaguscandidasa.com/contact-us/',
				),
			),
		),
	),
	'hero' => array(
		'title' => 'PURI BAGUS CANDIDASA',
		'subtitle' => 'A HEAVEN OF PEACE & GRACEFUL SERVICE',
		'location' => 'Karangasem 80811',
		'motto' => 'Escape. Breathe. Heal.',
		'video' => 'https://www.youtube.com/watch?v=9g3c0xUMsJY',
		'image' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc7.jpg',
		'image_alt' => 'Puri Bagus Candidasa',
		'actions' => array(
			array(
				'label' => 'WhatsApp',
				'icon' => 'whatsapp',
				'url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
			),
			array(
				'label' => 'Location',
				'icon' => 'pin',
				'url' => 'https://www.google.com/maps/place/Puri+Bagus+Candidasa+Resort/@-8.5137519,115.5766493,17z/data=!4m9!3m8!1s0x2dd2092c99aa7f75:0x32478ed769575cca!5m2!4m1!1i2!8m2!3d-8.5137519!4d115.5792242!16s%2Fg%2F1tdjmyz2?entry=tts&g_ep=EgoyMDI0MDkzMC4wIPu8ASoASAFQAw%3D%3D',
			),
			array(
				'label' => 'Contact Us',
				'icon' => 'mail',
				'url' => 'https://www.puribaguscandidasa.com/contact-us/',
			),
		),
	),
	'quicklinks' => array(
		array(
			'label' => 'Activity',
			'icon' => 'walker',
			'url' => 'https://bagusagropelaga.com/activities/',
		),
		array(
			'label' => 'Experiences',
			'icon' => 'book-open',
			'url' => 'https://bagusagropelaga.com/experiences/',
		),
		array(
			'label' => 'Dining',
			'icon' => 'cloche',
			'url' => 'https://bagusagropelaga.com/dining-bap/',
		),
		array(
			'label' => 'Offers',
			'icon' => 'star-line',
			'url' => 'https://bagusagropelaga.com/special-offers/',
		),
		array(
			'label' => 'Spa Wellness',
			'icon' => 'spa',
			'url' => 'https://bagusagropelaga.com/spa-wellness/',
		),
		array(
			'label' => 'Yoga Meditation',
			'icon' => 'sun',
			'url' => 'https://bagusagropelaga.com/yoga/',
		),
	),
	'booking' => array(
		'title' => 'Best Rate Guarantee',
		'action' => 'https://puribaguscandidasa.reserveonline.id/book/477',
		'button' => 'Check availability',
		'adults' => array( 1, 2, 3 ),
		'children' => array( 0, 1, 2 ),
		'infants' => array( 0, 1, 2 ),
		'note' => 'To ensure you still experience the best of Ball’s stunning coastline and rich heritage, we are providing a complimentary scheduled shuttle service to several premier local destinations. On Tuesdays, Thursdays, Saturdays, and Sundays, our shuttle travels to the pristine Pasir Putih (White Sand Beach) for a perfect day by the water. On Mondays, Wednesdays, and Fridays, we explore the Luwak Coffee Garden and the ancient Tenganan Village, where we provide free entrance tickets to discover this unique “Bali Aga” culture. These experiences are offered while Candidasa Beach undergoes a vital government conservation project dedicated to protecting our coastal ecosystems and ensuring long-term sustainability. For your safety and to support these essential environmental efforts, beach access is currently restricted to authorized personnel. Thank you for your understanding.',
	),
	'resort' => array(
		'kicker' => 'THE RESORT',
		'title' => 'PURI BAGUS CANDIDASA',
		'paragraphs' => array(
			'Wake up to the soothing melody of gentle waves, savor a delicious breakfast while gazing at the sparkling ocean, and stroll on the soft sandy beach to witness a breathtaking sunrise. Puri Bagus Candidasa offers not just relaxation but also serves as a portal to adventure. Guests can delve into nearby ancient temples, plunge into the crystal-clear waters for an unparalleled snorkeling or diving experience, or embark on an unforgettable boat trip to the neighboring Gili islands.',
			'The resort presents various accommodation options, including private villas with either garden or ocean views. Each villa is meticulously designed with authentic Balinese architecture and modern amenities. Puri Bagus Candidasa also serves as a gateway to the best of East Bali, providing easy access to cultural landmarks such as Tenganan Village, the water palaces of Tirta Gangga and Taman Ujung, as well as excellent snorkeling and diving spots around Blue Lagoon and Amed.',
			'What truly distinguishes us is our commitment to the Balinese philosophy of Tri Hita Karana, which underscores the harmony between humans, nature, and the divine. This philosophy influences every resort aspect, from its eco-friendly design and sustainable practices to its dedication to supporting the local community and preserving Balinese traditions. You will feel this balance when you step onto the grounds, with every element designed to promote well-being and tranquility.',
			'We take your taste buds through Bali’s rich culinary heritage. The resort’s Geringsing Restaurant serves a delightful mix of traditional Balinese dishes and international cuisine. Or, if you want to relax with a drink, we have Hasta Putra Bar. Unwind at the Hasta Putra Bar with a wide selection of cocktails, mocktails, and fine spirits. Whether you’re enjoying a seafood feast caught fresh from the local waters or indulging in a light, casual gathering, every meal is an experience of flavors that reflect the soul of Bali.',
			'No stay is complete without pampering at our Jaya Spa. Here, ancient healing techniques blend seamlessly with modern treatments. Imagine unwinding with a Balinese massage, your senses soothed by the aromas of local herbs and spices, or revitalizing your skin with a signature body scrub that leaves you glowing. Every treatment is designed to nourish your body and spirit, perfect for a retreat into relaxation.',
			'For those seeking inner balance, Puri Bagus Candidasa offers a peaceful space for yoga practice. Our yoga pavilion provides the ideal setting to connect with nature while engaging in mindful movement. Whether you’re a seasoned yogi or a beginner, the resort’s yoga sessions cater to all levels, making it the perfect way to begin or end your day.',
			'At Puri Bagus Candidasa, sustainability goes beyond mere practice; it embodies a way of life. The resort incorporates eco-friendly initiatives, including energy-efficient systems and waste reduction programs, promoting cultural preservation and supporting the local community. Guests are invited to fully immerse themselves in this harmonious balance through organic farming, traditional Balinese ceremonies, and yoga sessions designed to foster a connection between mind, body, and soul with nature.',
			'For those seeking to experience the culture and spirit of Bali, Puri Bagus Candidasa offers activities such as cooking classes, Balinese dance performances, and visits to nearby fishing villages. Whether you are planning a romantic getaway, family vacation, or wellness retreat, we offer a serene environment to unwind and explore the natural beauty of Bali.',
			'Puri Bagus Candidasa is more than just a place to stay; it is a sanctuary where you can immerse yourself in Bali’s rich heritage while indulging in modern luxury. With stunning vistas of the Lombok Strait and lush tropical gardens, the resort is perfect for those seeking more than just a holiday—it is a journey into the heart of Bali’s spiritual and natural beauty.',
		),
		'images' => array(
			array(
				'src' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc7.jpg',
				'alt' => 'Puri Bagus Candidasa',
			),
			array(
				'src' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc3.jpg',
				'alt' => 'Puri Bagus Candidasa',
			),
			array(
				'src' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc4.jpg',
				'alt' => 'Puri Bagus Candidasa',
			),
			array(
				'src' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc1.jpg',
				'alt' => 'Puri Bagus Candidasa',
			),
			array(
				'src' => 'https://www.puribaguscandidasa.com/storage/2023/11/pbc2.jpg',
				'alt' => 'Puri Bagus Candidasa',
			),
		),
		'downloads' => array( 'Factsheet', 'E-Brochure', 'Press Release' ),
		'sustain' => array(
			'title' => 'Sustainability Commitment',
			'text' => 'At Puri Bagus Candidasa, sustainability is seamlessly integrated into daily operations through eco-conscious practices such as energy-efficient systems, responsible water usage, and waste reduction, ensuring minimal environmental impact while maintaining guest comfort. The resort also supports local communities by sourcing ingredients and materials locally, collaborating with nearby villages, and empowering local artisans, while promoting cultural experiences that encourage guests to engage with Balinese traditions. We are committed to help preserve the island’s heritage and foster meaningful connections with the destination.',
			'link' => array(
				'label' => 'Discover more',
				'url' => 'https://www.puribaguscandidasa.com/sustainability-commitment/',
			),
		),
	),
	'downloads' => array(
		'title' => 'Download Factsheet, E-Brochure & Press Release!',
		'text' => 'Please provide your email to proceed the file download.',
	),
	'villas' => array(
		'title' => 'VILLAS',
		'items' => array(
			array(
				'name' => 'DELUXE SEA VIEW',
				'url' => 'https://www.puribaguscandidasa.com/villas/deluxe-sea-view/',
				'book' => 'https://reserveonline.id/s/6AE0180',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 100 sqm Include Verandah and Bathroom',
					'Sea View',
					'Verandah and Coffee table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view8.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view7.jpg', 'bathtub and shower' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view3.jpg', 'green garden' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view5.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view2.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view11.jpg', 'coffe table' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view10.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-sea-view9.jpg', 'DELUXE SEA VIEW' ),
				),
			),
			array(
				'name' => 'DELUXE BEACH FRONT',
				'url' => 'https://www.puribaguscandidasa.com/villas/deluxe-beach-front/',
				'book' => 'https://reserveonline.id/s/6AE017A',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 100 sqm Include Verandah and Bathroom',
					'Sea View',
					'Verandah and Coffee table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(
					array(
						'https://www.puribaguscandidasa.com/storage/2026/07/deluxe-beach-front10.jpg.jpeg',
						'DELUXE BEACH FRONT',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front10.jpg', 'green garden' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front9.jpg', 'bad room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front8.jpg', 'bad room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front7.jpg', 'coffe table' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front6.jpg',
						'DELUXE BEACH FRONT',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front5.jpg', 'green garden' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front4.jpg',
						'DELUXE BEACH FRONT',
					),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front3.jpg',
						'DELUXE BEACH FRONT',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front2.jpg', 'bad room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-beach-front.jpg',
						'DELUXE BEACH FRONT',
					),
				),
			),
			array(
				'name' => 'DELUXE GARDEN VIEW',
				'url' => 'https://www.puribaguscandidasa.com/villas/deluxe-garden-view/',
				'book' => 'https://reserveonline.id/s/6AE0182',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 83 sqm Include Bathroom',
					'Green Garden',
					'Working Table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view14-1.jpg', 'garden view' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view13-1.jpg', 'bathroom' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view12-1.jpg', 'garden view' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view11-1.jpg', 'room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view14.jpg',
						'DELUXE GARDEN VIEW',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view2-1.jpg', 'room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view9.jpg',
						'DELUXE GARDEN VIEW',
					),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view10.jpg',
						'DELUXE GARDEN VIEW',
					),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/deluxe-garden-view.jpg',
						'DELUXE GARDEN VIEW',
					),
				),
			),
			array(
				'name' => 'SUPERIOR GARDEN VIEW',
				'url' => 'https://www.puribaguscandidasa.com/villas/superior-garden-view/',
				'book' => 'https://reserveonline.id/s/6AE0184',
				'features' => array(
					'Free Wi-Fi',
					'Twin Bed or King Size Bed',
					'Villa size 83 sqm Include Bathroom',
					'Green Garden',
					'Working Table',
					'Non-Smoking',
					'Shower | Bathtub',
				),
				'images' => array(
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view10.jpg', 'garden view' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view11.jpg', 'bathroom' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view2.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view12.jpg', 'bathroom' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view.jpg', 'room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view-2-1.jpg',
						'SUPERIOR GARDEN VIEW',
					),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view-1-1.jpg',
						'SUPERIOR GARDEN VIEW',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view9.jpg', 'room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view15-1.jpg',
						'garden view',
					),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view8.jpg', 'room' ),
					array( 'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view7.jpg', 'room' ),
					array(
						'https://www.puribaguscandidasa.com/storage/2024/10/superior-garden-view-3-1.jpg',
						'SUPERIOR GARDEN VIEW',
					),
				),
			),
		),
	),
	'retreat' => array(
		'kicker' => 'Puri Bagus Candidasa',
		'title' => 'Group Retreat',
		'text' => 'Discover the ultimate group retreat experience at Puri Bagus Candidasa, where luxury meets serenity in the heart of Bali’s breathtaking natural beauty. Our resort provides an idyllic setting for relaxation, self-discovery, and connection, offering stunning ocean views, lush gardens, and top-of-the-line amenities. Whether you’re planning a Yoga Retreat, Meditation Retreat, Prana Chakra Healing Retreat, Sound Healing Retreat, Spiritual and Healing Retreat, Palm Reading Retreat, or Yoga Teacher Training Course, our personalized services and peaceful surroundings guarantee your group an unforgettable and rejuvenating journey. Break free from the mundane and let Puri Bagus Candidasa be the haven for your extraordinary retreat.',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://www.puribaguscandidasa.com/group-retreat/',
		),
		'images' => array(
			'https://www.puribaguscandidasa.com/storage/2024/10/small-pic-grup-retreat6.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/small-pic-grup-retreat7.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/small-pic-grup-retreat5.jpg',
			'https://www.puribaguscandidasa.com/storage/2026/10/group-retreat-4.jpg',
			'https://www.puribaguscandidasa.com/storage/2026/10/group-retreat-1.jpg',
			'https://www.puribaguscandidasa.com/storage/2026/10/group-retreat-3.jpg',
		),
	),
	'farm' => array(
		'kicker' => 'Puri Bagus Candidasa',
		'title' => 'The Meeting, Event & Wedding',
		'text' => '',
		'link' => array(
			'label' => 'Discover more',
			'url' => 'https://www.puribaguscandidasa.com/wedding-event/',
		),
		'images' => array(
			'https://www.puribaguscandidasa.com/storage/2024/10/wedding-venue3.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/wedding-venue.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/wedding-venue2.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/wedding-venue12.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/main-slide-wedding-event4.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/meeting-venue2.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/meeting-venue6.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/event-venue-and-service8.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/event-venue-and-service9.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/event-venue-and-service3.jpg',
			'https://www.puribaguscandidasa.com/storage/2024/10/event-venue-and-service.jpg',
		),
	),
	'packages' => array(
		'title' => 'EXPERIENCES PACKAGES',
		'items' => array(
			array(
				'name' => 'Diving',
				'url' => 'https://puribaguscandidasa.com/experiences/#diving',
				'image' => 'https://www.puribaguscandidasa.com/storage/2024/10/diving3.jpg',
				'text' => 'Our diving package includes multi-day dive sessions paired with accommodation and complimentary in-house activities, ensuring an unforgettable experience. This package is thoughtfully crafted to showcase the stunning marine diversity in Bali’s tropical waters, with dive spots like the Blue Lagoon, Manta Point, Gili Islands, and more. All diving activities are professionally managed by Orca Dive Clubs, a certified diving operator conveniently located within our resort.',
			),
			array(
				'name' => 'Cultural Yoga',
				'url' => 'https://www.puribaguscandidasa.com/experiences/#yoga',
				'image' => 'https://www.puribaguscandidasa.com/storage/2024/10/main-slide-yoga4-e1768979946466.jpg',
				'text' => 'Surrender to the beauty and healing culture of Puri Bagus Candidasa. Our dedicated team provides expert guidance and a wide array of rejuvenating activities designed to nurture your well-being. This peaceful sanctuary is the perfect setting for a revitalizing retreat, helping you reconnect with nature and restore harmony between body, mind, and soul.',
			),
			array(
				'name' => 'REJUVENATION SPA',
				'url' => 'https://www.puribaguscandidasa.com/experiences/#spa',
				'image' => 'https://www.puribaguscandidasa.com/storage/2024/10/main-slide-spa-n-wellness2.jpg',
				'text' => 'Enjoy beach front a panoramic getaway from the hustle and bustle of every-day life and prepare for some relaxing days of pampering and dining amidst the most beautiful tropical Balinese garden surroundings. Experience our different Rejuvenation spa treatments and spoil your taste buds with delicious healthy prepared meals.',
			),
			array(
				'name' => 'SPIRITUAL HEALING',
				'url' => 'https://www.puribaguscandidasa.com/experiences/#healing',
				'image' => 'https://www.puribaguscandidasa.com/storage/2024/10/main-slide-grup-retreat3.jpg',
				'text' => 'The spiritual journey at Puri Bagus Candidasa is a profound and continuous exploration of inner connection and universal harmony. It invites guests to dive deep into self-awareness, embracing the beauty of reality while fostering a sense of love and compassion for all aspects of life. This journey empowers individuals to align with their true essence, nurturing both personal growth and the well-being of others, creating a ripple effect of peace and balance within and beyond.',
			),
			array(
				'name' => 'ADVENTURE SPORT',
				'url' => 'https://www.puribaguscandidasa.com/experiences/#sport',
				'image' => 'https://www.puribaguscandidasa.com/storage/2026/10/adventure-sport.jpg',
				'text' => 'Puri Bagus Candidasa is dedicated for those who are looking for a relaxing and energetic outdoor activities; it is the perfect choice due its temperate climate. The resort is geared to family and sport friendly guests with an abundance of activities which you can enjoy with our sport package.',
			),
			array(
				'name' => 'Authentic Bali',
				'url' => 'https://www.puribaguscandidasa.com/experiences/#authenticbali',
				'image' => 'https://www.puribaguscandidasa.com/storage/2026/10/exotic-bali-9.jpg',
				'text' => 'This thoughtfully crafted round-trip package is designed to meet your every expectation for an unforgettable holiday experience. Discover the best of Bali by visiting pristine beaches, iconic Hindu temples, lush rice terraces, and awe-inspiring volcanic landscapes. Enjoy guided day tours with plenty of free time to explore at your own pace and special evenings featuring dinner and captivating traditional Balinese dance performances.',
			),
		),
	),
	'reviews' => array(
		'title' => 'Guest Review',
		'image' => 'https://www.puribaguscandidasa.com/storage/2023/08/IMG_7936_for-edit-scaled.jpg',
		'items' => array(
			array(
				'title' => '親切なスタッフと行き届いたサービス',
				'author' => '公恵 八',
				'date' => '2026-09-15',
				'text' => '穏やかな時間が流れるホテル ホテルの目の前の海には、ジュクンという小舟が浮かび、そのままシュノーケリングに行ける立地は素晴らしかったです。 レストランは、とても美味しくホテルとは思えないほど安いですし、心地よい風が吹き抜け、眺めもよくいつまでも座っていたい空間でした。 チャンディダサ周辺の観光地へ送迎してくれるサービスもとてもありがたかったです。テガナン村に連れて行ってもらいました。 スタッフの方は遅れた荷物の対応に、とても一生懸命対応してくださりました。 すべてが素晴らしいホテルでした。',
			),
			array(
				'title' => 'UN SÉJOUR ENCHANTEUR DE 12 JOURS',
				'author' => 'Delphine',
				'date' => '2026-08-16',
				'text' => 'Je suis restée 12 jours dans cet hôtel avec un groupe et j’ai été ravie du début a la fin. Magnifique hôtel, emplacement, chambres, propreté rien à redire. Tout le personnel est extrêmement poli et serviable. Merci pour votre professionnalisme',
			),
			array(
				'title' => 'HERZLICHE GASTFREUNDSCHAFT DIREKT AM MEER',
				'author' => 'Setphan',
				'date' => '2026-07-30',
				'text' => 'Das Hotel bietet einen attraktiven Pool und freundliches Personal. Eine schöne Hotelanlage direkt am Meer, bestehend aus mehreren in einem Park verteilten Häusern. Toller (sehr tiefer) Pool und sehr freundlichen Mitarbeitenden. Eine schöne Hotelanlage direkt am Meer, bestehend aus mehreren in einem Park verteilten Häusern. Toller (sehr tiefer) Pool und sehr freundlichen Mitarbeitenden.',
			),
			array(
				'title' => 'REINE BALINESISCHE GASTFREUNDSCHAFT',
				'author' => 'Christian H',
				'date' => '2026-07-01',
				'text' => 'Drei Nächte: Erinnerungen für immer Wir hatten eine wundervolle Zeit im Hotel Puri Bagus. Alle Angestellten waren sehr zuvorkommend und hilfsbereit, besonders hervorheben möchte ich aber Eka aus dem Restaurant. Sie war ein echter Segen für uns! Nicht nur beim Tischservice, auch beim privaten Tanzkurs haben wir ihre Begleitung sehr genossen. Danke für alles und bis zum nächsten Mal!',
			),
			array(
				'title' => 'PERFECT YOGA & WELLNESS RETREAT',
				'author' => 'Adrienne Edson',
				'date' => '2026-06-21',
				'text' => 'The location, accommodations, and staff are top notch. So gorgeous to have the ocean right there and all of the flowers and dragon statues around. We were here for a yoga retreat, they provided mats and props, the shala was beautiful, and the staff infused it with such care by creating a flower mandala and incense. We enjoyed the Balinese dance performance in the restaurant. The spa and restaurant were wonderful. We got so many treatments, so affordable. Such a wonderful time, will definitely be back.',
			),
			array(
				'title' => 'UNE PAUSE MAGNIFAIQUE À CANDIDASA',
				'author' => 'Marie-Christine Clément',
				'date' => '2026-05-20',
				'text' => 'Splendide! L\'accueil par le personnel était impeccable et charmant. Une pause plus qu\'agréable. Mention spéciale à Susila qui, avec une grande efficacité, a su parfaitement répondre aux demandes.',
			),
			array(
				'title' => 'SUPER STAY IN A SUPER LOCATION',
				'author' => 'Piet D',
				'date' => '2026-04-07',
				'text' => 'We were here for 2 nights during a wonderful Bali/Lombok tour from Bolderman Excursion trip with a group of 18 people, The care was excellent with very friendly staff. The comfortable very spacious rooms are super. Everyone has their own house!!! Furthermore, a super nice pool with terraces etc. Location by the sea with its own beach.',
			),
			array(
				'title' => 'GREAT PLACE, GREAT SERVICE, GREAT FOOD!',
				'author' => 'Annette E',
				'date' => '2026-03-01',
				'text' => 'Puri Bagus Candidasa is a lovely bungalow hotel situated in a nice and quiet neighbourhood. The balinese style bungalows are spacious and clean, the outdoor bathroom is fun. All staff, at reception, restaurant and management, are excellent, extremely friendly and attentive. The restaurant at breakfast and dinner was absolutely wonderful, food was delicious. Definitely at the top end of all our Bali experiences. And when leaving I even got a jar of tamarind jam as a gift because I liked it so much. Only one caveat: Since last year there is a governmental construction project in Candidasa to build a promenade like in Sanur, so there is some construction going on on various, changing parts all over Candidasa and beach access is restricted. Nevertheless, we enjoyed our stay in Candidasa very much, and Puri Bagus is doing a great job to make up for any inconvenience! We loved staying here and we are looking forward to come back. Thank you so much! Annette & Jo',
			),
			array(
				'title' => 'BALINESE CHARM & LOVELY STAFF',
				'author' => 'Frances M',
				'date' => '2026-02-17',
				'text' => 'Balinese charm. Puri Bagus is a wonderful balinese style hotel with spacious bungalow rooms and an exceptional pool. The staff especially, are lovely and attentive. We have stayed here many times, it is a special place. The government project of building an esplanade along the entire seafront of Candidasa will be transformative. There is noise from machinery atm but that is temporary. The essential charm of the hotel remains unchanged.',
			),
			array(
				'title' => 'FEELS LIKE HOME BY THE SEA',
				'author' => 'Debra Lascelles',
				'date' => '2026-01-24',
				'text' => 'What an amazing place to stop. A place where your a person, not a number. This was our 2nd time stopping here & the experience was just as perfect. We were told about the building works happening, before we arrived & we’re given the option to stay at another hotel. So glad we did not change our plans as our stay was so amazing. We hardly noticed any noise from the building works just the occasional truck transporting rocks to construct a 6km walk way on the sea front. The main sound was that of waves crashing (fantastic). I highly recommend this wonderful place & we will definitely be back.',
			),
		),
	),
	'discovery' => array(
		'title' => 'Bagus Discovery',
		'subtitle' => 'FOR QUALITY AND DIVERSITY',
		'items' => array(
			array(
				'name' => 'PURI BAGUS MANGGIS',
				'text' => 'A Villa Resort in a Balinese Village',
				'url' => 'http://www.puribagusmanggis.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/bagus-manggis.jpg',
			),
			array(
				'name' => 'PURI BAGUS CANDIDASA',
				'text' => 'Beach Dive Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguscandidasa.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/candidasa.jpg',
			),
			array(
				'name' => 'BAGUS AGRO PELAGA',
				'text' => 'Wellness Farm Resort & Lifestyle Retreat',
				'url' => 'http://www.bagusagropelaga.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/pelaga.jpg',
			),
			array(
				'name' => 'BAGUS PURI LOVINA',
				'text' => 'Spa Beach Resort & Yoga Meditation Retreat',
				'url' => 'http://www.puribaguslovina.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/lovina.jpg',
			),
			array(
				'name' => 'BAGUS JATI',
				'text' => 'Health & Wellbeing Retreat Resort',
				'url' => 'http://www.bagusjati.com/',
				'image' => 'https://bagusjati.com/wp-content/uploads/2024/06/7-5.jpg',
			),
		),
	),
	'newsletter' => array(
		'title' => 'JOIN OUR MAILING LIST',
		'text' => 'Be the first to know about Our exclusive perks, events and promotions!',
	),
	'welcome' => array(
		'title' => 'Welcome to Puri Bagus Candidasa',
		'promos' => array(),
		'actions' => array(
			array(
				'label' => 'Reserve Now',
				'url' => 'https://puribaguscandidasa.reserveonline.id/book/477?promotions%5B%5D=9619&promotions%5B%5D=12099&promotions%5B%5D=12100',
				'style' => 'primary',
			),
			array(
				'label' => 'Chat With Us',
				'url' => 'https://api.whatsapp.com/send/?phone=6285956688142&text&type=phone_number&app_absent=0',
				'style' => 'ghost',
			),
			array(
				'label' => 'I Already Have a Reservation',
				'url' => 'https://puribaguscandidasa.reserveonline.id/book/477/check-bookings?promotions%5B%5D=9619&promotions%5B%5D=12099&promotions%5B%5D=12100',
				'style' => 'link',
			),
		),
	),
);
