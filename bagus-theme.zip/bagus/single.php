<?php
/**
 * Single post.
 *
 * @package Bagus
 */

get_header();

while ( have_posts() ) :
	the_post();
	ob_start();
	bagus_posted_on();
	$meta = ob_get_clean();
	$cats = get_the_category_list( ', ' );
	get_template_part( 'template-parts/page-hero', null, array( 'subtitle' => $meta . ( $cats ? ' · ' . $cats : '' ) ) );
	?>
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-flow' ); ?>>
		<div class="wrap wrap--content prose entry-content">
			<?php the_content(); ?>
			<?php wp_link_pages( array( 'before' => '<nav class="page-links">', 'after' => '</nav>' ) ); ?>
		</div>
		<footer class="wrap wrap--content entry-footer">
			<?php the_tags( '<p class="tags">', '', '</p>' ); ?>
			<?php
			the_post_navigation(
				array(
					'prev_text' => '<span class="kicker">' . esc_html__( 'Previous', 'bagus' ) . '</span><span>%title</span>',
					'next_text' => '<span class="kicker">' . esc_html__( 'Next', 'bagus' ) . '</span><span>%title</span>',
				)
			);
			?>
		</footer>
	</article>
	<?php
	if ( comments_open() || get_comments_number() ) {
		echo '<div class="wrap wrap--content">';
		comments_template();
		echo '</div>';
	}
endwhile;

get_footer();
