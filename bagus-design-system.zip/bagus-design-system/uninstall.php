<?php
// Removes the plugin's settings when it is deleted from Plugins → Installed Plugins.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'bagus_ds_settings' );
delete_option( 'bagus_ds_site' );
delete_site_transient( 'bagus_ds_update_info' );
