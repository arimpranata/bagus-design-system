=== Bagus Design System ===
Contributors: bagusgroup
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 4.0.0
License: GPLv2 or later

One design layer for bagusjati.com, bagusagropelaga.com, puribaguscandidasa.com, puribaguslovina.com and puribagusmanggis.com.

== Description ==

Replaces the long "Bagus" Additional CSS with a light, cached plugin. Fonts, colours and content are not changed;
each site keeps its own brand colours.

* Typography standard (Cinzel headings, Montserrat 14px body), per-page spacing aligned to Bagus Jati.
* One header height (Bagus Jati: 69 px, 63 px on phones) and one banner height (55vh on every page, homepage 75vh).
* Headings: main heading in the brand primary colour, sub heading in Bagus gold, short gold line under each heading group.
* 5 px rounded corners on images, cards and tabs (not on the hero banner); long paragraphs left-aligned.
* Buttons: brand primary, accent on hover, single line, never wider than their column.
* Footer newsletter, popup menu, logos and contact icons standard.
* Special Offers cards in an equal grid (4 = 2 x 2, 6 = 3 x 2) + automatic "Read More" links (sites/<site>/offers.json).
* Read More buttons: small, with a right chevron.
* Mobile: no sideways scrolling, button rows wrap, footer 20 px padding.
* Footer Icons post type: Review Us / Follow Us icons managed in the dashboard, one size for all.

Loads: core.min.css (shared, cached), site.min.css (2–8 KB), and only the current page's rules inline (≈3–8 KB).
No JavaScript on normal pages; the Read More script (1 KB) loads on the Special Offers page only.

== Installation ==

1. Plugins → Add New → Upload Plugin → bagus-design-system.zip → Install → Activate.
2. Settings → Bagus Design System: check the detected site (choose it manually on staging).
3. Remove the old Bagus CSS from Appearance → Customize → Additional CSS.
4. Remove the old Special Offers "Read More" snippet from Elementor → Custom Code.
5. Elementor → Tools → Regenerate CSS & Data, then clear the cache plugin / CDN.

Bagus Jati and Puri Bagus Manggis: the plugin hides their old dark-mode buttons and always shows the light design.
Their old dark-mode snippets (Elementor → Custom Code / Code Snippets) can be deleted.

== Changelog ==

= 4.0.0 =
* New look for all five sites and all pages, following the "Bagus Theme" design (each site keeps its own colours):
  Jost body text 16/28, Cinzel titles with a 64px gold rule, 46px buttons with a light sweep, 64/76px header with a shadow when scrolled,
  dark slide-in drawer menu, rounded popups, large tracked hero title with glass link chips, glass hero tiles that lift on hover (swipe row on phones),
  green booking card with gold glow and a gold pill button, villa cards with gold border and amenity icon circles, photo bands with a gradient veil,
  chip tabs, dark footer with gold column titles, 3:4 Discovery cards (swipe row on phones), phone app bar (Call, WhatsApp, Book, Menu),
  reveal motion (26px / .9s), 2px gold progress bar, soft page transitions.

= 3.9.1 =
* Photo sections (Group Retreat, Wellness Farm, Meeting & Wedding, Organic Farm…): label, title, line and text left-aligned on desktop/tablet, as in the Bagus Jati layout; title centred on phones.

= 3.9.0 =
* Homepage "The Resort" title block in the Bagus Jati style on every site: gold label 20px, title 45px in the brand colour, 60px gold line; left-aligned on desktop/tablet, centred on phones (title 36px).

= 3.8.0 =
* Light motion on every site (assets/motion.min.js, about 2 KB gzipped, loaded in the footer):
  content below the fold fades up as it scrolls into view; gold reading-progress bar at the top;
  scroll cue on inner-page banners (click scrolls to the content, hides after scrolling);
  slider dots in one style (active dot = gold pill), simple clickable dots for sliders that had none.
* Off automatically for visitors who prefer reduced motion; everything stays visible without the script.
* Settings → Bagus Design System → Motion (on by default).

= 3.7.0 =
* Homepage hero tiles: no inner box (Happy Addons icon box shadow removed).
* Booking bar: Bagus Jati spacing on every site (25px fields, 35px inputs, 40/20px around the button; phone values from Bagus Jati). Puri Bagus Manggis bar as wide as the other sites.
* Titles: small gold sub title + brand-colour title + gold line on every site (also The Resort on Bagus Agro Pelaga and Puri Bagus Lovina).
* Villas / Rooms: the full-width divider under the heading is replaced by the standard 60px gold line.
* Photo sections (Group Retreat, Wellness, Meeting & Wedding…): Bagus Jati style on every site: white label 16px, white title 28px, gold line, white text, white outline button; dark shade on phones so the text stays readable.
* Page rules regenerated from a fresh crawl of all 169 pages (homepages were edited).
* Bagus Discovery footer cards: description and button appear on mouse hover again (always visible on touch screens).
* Destination tables (The Resort): Puri Bagus Candidasa table style on every site.
* List items (Destinations, Dining…): Bagus Jati style: title 21px, text 14/23, button left under the text, light-gold line between items.
* Tabs: one style on every site (light grey, active in the brand colour, Montserrat 16px uppercase).
* Every gold title line is centred, and so is its title, on desktop and phones.

= 3.6.0 =
* Automatic updates: the plugin checks update.json in the GitHub repository arimpranata/bagus-design-system (every 6 hours) and WordPress shows/installs new versions like any other plugin.
* Settings → Bagus Design System: "Automatic updates" (on by default), installed/latest version and a "Check for updates now" button.

= 3.5.0 =
* Menu windows (popup menu) on phones are no longer transparent; the banner-popup rule only applies to banner/slideshow popups without a menu.
* Promo banner popups on phones: Puri Bagus Candidasa size and style on every site (78% wide, max 340px, 305:470, square corners, centred).
* Footer Review Us / Follow Us icons: Bagus Agro Pelaga standard on every site (36px, 33px on phones, 6-column grid; Qi slider, Social Icons and Happy feature list). Fixes the Puri Bagus Manggis Follow Us row sliding off to the left.
* Puri Bagus Manggis: the old "pbm" snippet no longer forces Cormorant Garamond on headings (Cinzel like the other sites).

= 3.4.0 = (phones)
* Section separators: the divider above a section becomes a 40px gap and the gold line moves under the section heading (e.g. Sustainability Commitment, Villas).
* Read More + Book Now (and Book Now + Download E-Menu) on one line, at the left and right edge.
* Photo sections with text on the image (Group Retreat, Organic Farm…): full width, 30px padding inside.
* Photo + text lists (Experiences Packages…): photos run to the screen edges.
* Language switcher centred near the bottom; the area below the footer has the footer bar colour (no white strip).
* Promo popups with a banner/slideshow: no white panel below the banner.

= 3.3.0 =
* One button font everywhere (Cinzel 12px, 600, uppercase): Elementor, Unlimited Elements, PowerPack, form buttons.
* Book Now styled like Read More (small, right chevron). Buttons on a photo: transparent with a white outline.
* Line under headings follows the heading's real alignment (centred headings get a centred line, also on phones); dividers next to it are hidden (no double lines).
* Bagus Discovery footer cards: title, text and button always on the photo, 250px high on every screen.
* Footer: same top/bottom spacing on all sites, white text links.
* Homepage hero bar: text column 35%, tiles 65%; tiles same size and colour on all sites (primary, accent on hover).
* Body text 14px; paragraphs without padding; 20px between a heading and its text.
* Phone header: menu button on the right, 20px on both sides.
* No arrow buttons on hero sliders.
* Listing pages (Dining, Activities…): buttons on the right.

= 3.2.0 =
* Dark mode and its button removed on all sites (also the old Bagus Jati / Puri Bagus Manggis buttons); saved dark choices are cleared.
* Header height = Bagus Jati; one banner height for every page except the homepage.
* Body text 15 px (+2 px); long paragraphs left-aligned.
* 5 px rounded images, cards and tab buttons (hero excluded).
* Read More buttons smaller with a right chevron.
* Special Offers: equal cards; 4 offers = 2 rows x 2, 6 offers = 2 rows x 3 (2 per row on tablet, 1 on phone).
* Headings: primary + gold two-colour scheme and a gold line under each heading group (replaces the old divider).
* Footer: 20 px padding on phones.
* Faster: no theme script any more, Google Fonts preconnect.

= 3.1.0 =
* New "Footer Icons" post type for the Review Us / Follow Us icons, shortcode [bagus_icons group="review|follow"], one-click import of the current icons, equal icon size (Settings, default 36 px = current Follow Us size).
* "Open Website" buttons in the footer Bagus Discovery cards: outlined white button (1px white border), visible on touch screens.

= 3.0.1 =
* Puri Bagus Candidasa Special Offers: 60px between hero and intro, 10px heading/divider/text spacing, 90px before Accommodation Offers (as on Bagus Jati).

= 3.0.0 =
* First plugin release; packages the v2.7 standard, adds dark mode for all sites, per-page CSS loading.
