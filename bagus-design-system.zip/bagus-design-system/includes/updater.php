<?php
/**
 * Self-update for Bagus Design System.
 *
 * Reads a small JSON file (default: update.json in the public GitHub repository arimpranata/bagus-design-system):
 *   { "version": "3.6.0", "download_url": "https://…/bagus-design-system.zip", "requires": "6.0", "tested": "6.8",
 *     "requires_php": "7.4", "changelog": "<ul><li>…</li></ul>" }
 * When "version" is newer than the installed one, WordPress shows the normal "Update available" notice and can install it
 * (also automatically when "Automatic updates" is on in Settings → Bagus Design System).
 * Override the address with define( 'BAGUS_DS_UPDATE_URL', 'https://…/update.json' ); in wp-config.php.
 */
defined( 'ABSPATH' ) || exit;

if ( ! defined( 'BAGUS_DS_UPDATE_URL' ) ) {
	define( 'BAGUS_DS_UPDATE_URL', 'https://raw.githubusercontent.com/arimpranata/bagus-design-system/main/update.json' );
}

/** Plugin basename, e.g. bagus-design-system/bagus-design-system.php */
function bagus_ds_basename() {
	return plugin_basename( BAGUS_DS_FILE );
}

/**
 * Fetch and validate the update info (cached for 6 hours; a failed check is cached for 1 hour so the site never slows down).
 *
 * @param bool $force Skip the cache.
 * @return array|null
 */
function bagus_ds_remote_info( $force = false ) {
	$key = 'bagus_ds_update_info';
	if ( ! $force ) {
		$cached = get_site_transient( $key );
		if ( false !== $cached ) {
			return is_array( $cached ) ? $cached : null;
		}
	}
	$res  = wp_remote_get( BAGUS_DS_UPDATE_URL, array( 'timeout' => 8, 'headers' => array( 'Accept' => 'application/json' ) ) );
	$info = null;
	if ( ! is_wp_error( $res ) && 200 === (int) wp_remote_retrieve_response_code( $res ) ) {
		$data = json_decode( wp_remote_retrieve_body( $res ), true );
		if ( is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['download_url'] )
			&& preg_match( '/^\d+(\.\d+){0,3}$/', (string) $data['version'] )
			&& 0 === strpos( (string) $data['download_url'], 'https://' ) ) {
			$info = array(
				'version'      => (string) $data['version'],
				'download_url' => esc_url_raw( (string) $data['download_url'] ),
				'requires'     => isset( $data['requires'] ) ? sanitize_text_field( (string) $data['requires'] ) : '',
				'tested'       => isset( $data['tested'] ) ? sanitize_text_field( (string) $data['tested'] ) : '',
				'requires_php' => isset( $data['requires_php'] ) ? sanitize_text_field( (string) $data['requires_php'] ) : '',
				'changelog'    => isset( $data['changelog'] ) ? wp_kses_post( (string) $data['changelog'] ) : '',
			);
		}
	}
	set_site_transient( $key, $info ? $info : 'none', $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $info;
}

/** Tell WordPress about a newer version. */
add_filter( 'pre_set_site_transient_update_plugins', 'bagus_ds_check_update' );
function bagus_ds_check_update( $transient ) {
	if ( ! is_object( $transient ) ) {
		$transient = new stdClass();
	}
	$info = bagus_ds_remote_info();
	$base = bagus_ds_basename();
	$item = (object) array(
		'id'          => 'bagus-design-system',
		'slug'        => 'bagus-design-system',
		'plugin'      => $base,
		'new_version' => $info ? $info['version'] : BAGUS_DS_VERSION,
		'url'         => 'https://github.com/arimpranata/bagus-design-system',
		'package'     => $info ? $info['download_url'] : '',
		'tested'      => $info ? $info['tested'] : '',
		'requires'    => $info ? $info['requires'] : '',
		'requires_php'=> $info ? $info['requires_php'] : '',
		'icons'       => array(),
	);
	if ( $info && version_compare( $info['version'], BAGUS_DS_VERSION, '>' ) ) {
		$transient->response[ $base ] = $item;
		unset( $transient->no_update[ $base ] );
	} else {
		$transient->no_update[ $base ] = $item;   // lets the Plugins screen show the auto-update toggle
		unset( $transient->response[ $base ] );
	}
	return $transient;
}

/** "View details" popup on the Plugins / Updates screen. */
add_filter( 'plugins_api', 'bagus_ds_plugins_api', 20, 3 );
function bagus_ds_plugins_api( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || empty( $args->slug ) || 'bagus-design-system' !== $args->slug ) {
		return $result;
	}
	$info = bagus_ds_remote_info();
	return (object) array(
		'name'          => 'Bagus Design System',
		'slug'          => 'bagus-design-system',
		'version'       => $info ? $info['version'] : BAGUS_DS_VERSION,
		'author'        => 'Bagus Group',
		'homepage'      => 'https://github.com/arimpranata/bagus-design-system',
		'requires'      => $info ? $info['requires'] : '6.0',
		'tested'        => $info ? $info['tested'] : '',
		'requires_php'  => $info ? $info['requires_php'] : '7.4',
		'download_link' => $info ? $info['download_url'] : '',
		'sections'      => array(
			'description' => 'One design layer for the five Bagus websites.',
			'changelog'   => $info && $info['changelog'] ? $info['changelog'] : 'See readme.txt.',
		),
	);
}

/** Keep the folder name "bagus-design-system" whatever the zip's top folder is called. */
add_filter( 'upgrader_source_selection', 'bagus_ds_fix_source_dir', 10, 4 );
function bagus_ds_fix_source_dir( $source, $remote_source, $upgrader, $hook_extra = array() ) {
	global $wp_filesystem;
	if ( empty( $hook_extra['plugin'] ) || bagus_ds_basename() !== $hook_extra['plugin'] || ! $wp_filesystem ) {
		return $source;
	}
	$wanted = trailingslashit( $remote_source ) . 'bagus-design-system/';
	if ( untrailingslashit( $source ) === untrailingslashit( $wanted ) ) {
		return $source;
	}
	if ( $wp_filesystem->move( $source, $wanted, true ) ) {
		return $wanted;
	}
	return new WP_Error( 'bagus_ds_rename', 'Bagus Design System: could not rename the update folder.' );
}

/** Automatic updates (Settings → Bagus Design System → Automatic updates, on by default). */
add_filter( 'auto_update_plugin', 'bagus_ds_auto_update', 10, 2 );
function bagus_ds_auto_update( $update, $item ) {
	if ( is_object( $item ) && isset( $item->plugin ) && bagus_ds_basename() === $item->plugin ) {
		$s = get_option( 'bagus_ds_settings', array() );
		return ! isset( $s['auto_update'] ) || ! empty( $s['auto_update'] );
	}
	return $update;
}

/** Fresh check after an update and from the settings page button. */
add_action( 'upgrader_process_complete', 'bagus_ds_clear_update_cache' );
function bagus_ds_clear_update_cache() {
	delete_site_transient( 'bagus_ds_update_info' );
}

add_action( 'admin_post_bagus_ds_check_now', 'bagus_ds_check_now_handler' );
function bagus_ds_check_now_handler() {
	if ( ! current_user_can( 'update_plugins' ) ) {
		wp_die( esc_html__( 'Not allowed.', 'bagus-ds' ) );
	}
	check_admin_referer( 'bagus_ds_check_now' );
	bagus_ds_remote_info( true );
	delete_site_transient( 'update_plugins' );
	wp_update_plugins();
	wp_safe_redirect( admin_url( 'options-general.php?page=bagus-ds&checked=1' ) );
	if ( ! defined( 'BAGUS_DS_TESTING' ) ) {
		exit;
	}
}

/** Small block for the settings page. */
function bagus_ds_updater_admin_block() {
	$info = bagus_ds_remote_info();
	$s    = get_option( 'bagus_ds_settings', array() );
	$on   = ! isset( $s['auto_update'] ) || ! empty( $s['auto_update'] );
	echo '<h2>' . esc_html__( 'Updates', 'bagus-ds' ) . '</h2><p>';
	printf( esc_html__( 'Installed: %s.', 'bagus-ds' ), esc_html( BAGUS_DS_VERSION ) );
	echo ' ';
	if ( $info ) {
		printf( esc_html__( 'Latest: %s.', 'bagus-ds' ), esc_html( $info['version'] ) );
	} else {
		esc_html_e( 'Update server not reachable yet.', 'bagus-ds' );
	}
	echo ' ' . ( $on ? esc_html__( 'Automatic updates are on.', 'bagus-ds' ) : esc_html__( 'Automatic updates are off.', 'bagus-ds' ) ) . '</p>';
	echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
	wp_nonce_field( 'bagus_ds_check_now' );
	echo '<input type="hidden" name="action" value="bagus_ds_check_now"><button class="button">' . esc_html__( 'Check for updates now', 'bagus-ds' ) . '</button></form>';
}
