<?php
/**
 * Footer icons (Review Us / Follow Us) as their own post type.
 *
 * Dashboard: "Footer Icons" menu — one entry per icon (title, icon image, link, group, order).
 * Output:    [bagus_icons group="review"]  and  [bagus_icons group="follow"]
 *            (Elementor: add a Shortcode widget under the "Review Us" / "Follow Us" headings).
 * All icons render at the same size (Settings → Bagus Design System → Icon size, default 36 px,
 * the size of the current Follow Us icons).
 */

defined( 'ABSPATH' ) || exit;

const BAGUS_ICON_PT = 'bagus_icon';

add_action( 'init', 'bagus_ds_register_icons' );
function bagus_ds_register_icons() {
	register_post_type(
		BAGUS_ICON_PT,
		array(
			'labels'          => array(
				'name'               => 'Footer Icons',
				'singular_name'      => 'Footer Icon',
				'add_new'            => 'Add Icon',
				'add_new_item'       => 'Add Footer Icon',
				'edit_item'          => 'Edit Footer Icon',
				'new_item'           => 'New Footer Icon',
				'search_items'       => 'Search Footer Icons',
				'not_found'          => 'No footer icons yet — use "Import current icons" on Settings → Bagus Design System.',
				'featured_image'     => 'Icon image (square)',
				'set_featured_image' => 'Set icon image',
				'menu_name'          => 'Footer Icons',
			),
			'public'          => false,
			'show_ui'         => true,
			'show_in_menu'    => true,
			'show_in_rest'    => false,
			'menu_position'   => 58,
			'menu_icon'       => 'dashicons-share',
			'supports'        => array( 'title', 'thumbnail', 'page-attributes' ),
			'capability_type' => 'post',
			'map_meta_cap'    => true,
			'rewrite'         => false,
			'query_var'       => false,
		)
	);
	// make sure featured images are available for this post type even if the theme limits them
	$support = get_theme_support( 'post-thumbnails' );
	if ( true !== $support ) {
		$types   = ( is_array( $support ) && isset( $support[0] ) ) ? (array) $support[0] : array();
		$types[] = BAGUS_ICON_PT;
		add_theme_support( 'post-thumbnails', $types );
	}
}

function bagus_ds_icon_groups() {
	return array( 'review' => 'Review Us', 'follow' => 'Follow Us' );
}

/* ---------- edit screen ---------- */
add_action( 'add_meta_boxes_' . BAGUS_ICON_PT, function () {
	add_meta_box( 'bagus_icon_details', 'Icon details', 'bagus_ds_icon_metabox', BAGUS_ICON_PT, 'normal', 'high' );
} );

function bagus_ds_icon_metabox( $post ) {
	wp_nonce_field( 'bagus_icon_save', 'bagus_icon_nonce' );
	$group  = get_post_meta( $post->ID, '_bagus_icon_group', true ) ?: 'follow';
	$url    = get_post_meta( $post->ID, '_bagus_icon_url', true );
	$newtab = get_post_meta( $post->ID, '_bagus_icon_newtab', true );
	$newtab = ( '' === $newtab ) ? '1' : $newtab;
	$img    = get_post_meta( $post->ID, '_bagus_icon_image', true );
	?>
	<table class="form-table" role="presentation">
		<tr><th scope="row"><label for="bagus_icon_group">Group</label></th><td>
			<select id="bagus_icon_group" name="bagus_icon_group">
				<?php foreach ( bagus_ds_icon_groups() as $k => $label ) : ?>
					<option value="<?php echo esc_attr( $k ); ?>" <?php selected( $group, $k ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</td></tr>
		<tr><th scope="row"><label for="bagus_icon_url">Link</label></th><td>
			<input type="url" class="large-text" id="bagus_icon_url" name="bagus_icon_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://www.tripadvisor.com/…">
			<p class="description">Leave empty to show the icon without a link.</p>
		</td></tr>
		<tr><th scope="row">Open in new tab</th><td><label><input type="checkbox" name="bagus_icon_newtab" value="1" <?php checked( $newtab, '1' ); ?>> Yes</label></td></tr>
		<tr><th scope="row"><label for="bagus_icon_image">Image URL (optional)</label></th><td>
			<input type="url" class="large-text" id="bagus_icon_image" name="bagus_icon_image" value="<?php echo esc_attr( $img ); ?>">
			<p class="description">Used only when no icon image (right column) is set — e.g. an SVG that the Media Library does not accept.</p>
		</td></tr>
		<tr><th scope="row">Order</th><td><p class="description">Use "Order" in the Page Attributes box (lower numbers first).</p></td></tr>
	</table>
	<?php
}

add_action( 'save_post_' . BAGUS_ICON_PT, function ( $post_id ) {
	if ( ! isset( $_POST['bagus_icon_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bagus_icon_nonce'] ) ), 'bagus_icon_save' ) ) {
		return;
	}
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	$group = isset( $_POST['bagus_icon_group'] ) ? sanitize_key( wp_unslash( $_POST['bagus_icon_group'] ) ) : 'follow';
	update_post_meta( $post_id, '_bagus_icon_group', array_key_exists( $group, bagus_ds_icon_groups() ) ? $group : 'follow' );
	update_post_meta( $post_id, '_bagus_icon_url', isset( $_POST['bagus_icon_url'] ) ? esc_url_raw( wp_unslash( $_POST['bagus_icon_url'] ) ) : '' );
	update_post_meta( $post_id, '_bagus_icon_newtab', empty( $_POST['bagus_icon_newtab'] ) ? '0' : '1' );
	update_post_meta( $post_id, '_bagus_icon_image', isset( $_POST['bagus_icon_image'] ) ? esc_url_raw( wp_unslash( $_POST['bagus_icon_image'] ) ) : '' );
	bagus_ds_icons_flush();
} );
add_action( 'deleted_post', 'bagus_ds_icons_flush' );
add_action( 'trashed_post', 'bagus_ds_icons_flush' );

/* ---------- list screen ---------- */
add_filter( 'manage_' . BAGUS_ICON_PT . '_posts_columns', function ( $cols ) {
	return array(
		'cb'               => $cols['cb'] ?? '',
		'bagus_icon_img'   => 'Icon',
		'title'            => 'Name',
		'bagus_icon_group' => 'Group',
		'bagus_icon_url'   => 'Link',
		'bagus_icon_order' => 'Order',
	);
} );
add_action( 'manage_' . BAGUS_ICON_PT . '_posts_custom_column', function ( $col, $id ) {
	switch ( $col ) {
		case 'bagus_icon_img':
			$src = bagus_ds_icon_src( $id );
			echo $src ? '<img src="' . esc_url( $src ) . '" width="36" height="36" style="object-fit:contain;background:#fff;border:1px solid #ddd" alt="">' : '—';
			break;
		case 'bagus_icon_group':
			$g = get_post_meta( $id, '_bagus_icon_group', true );
			echo esc_html( bagus_ds_icon_groups()[ $g ] ?? '—' );
			break;
		case 'bagus_icon_url':
			$u = get_post_meta( $id, '_bagus_icon_url', true );
			echo $u ? '<a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( wp_parse_url( $u, PHP_URL_HOST ) ?: $u ) . '</a>' : '<span style="color:#b32d2e">⚠ no link yet</span>';
			break;
		case 'bagus_icon_order':
			echo (int) get_post_field( 'menu_order', $id );
			break;
	}
}, 10, 2 );
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() && $q->is_main_query() && BAGUS_ICON_PT === $q->get( 'post_type' ) && ! $q->get( 'orderby' ) ) {
		$q->set( 'orderby', array( 'meta_value' => 'ASC', 'menu_order' => 'ASC' ) );
		$q->set( 'meta_key', '_bagus_icon_group' );
	}
} );

/* ---------- output ---------- */
function bagus_ds_icon_src( $id ) {
	$thumb = get_the_post_thumbnail_url( $id, 'thumbnail' );
	return $thumb ? $thumb : (string) get_post_meta( $id, '_bagus_icon_image', true );
}

function bagus_ds_icons_flush() {
	foreach ( array_keys( bagus_ds_icon_groups() ) as $g ) {
		delete_transient( 'bagus_icons_' . $g );
	}
}

function bagus_ds_icons_html( $group ) {
	$group = array_key_exists( $group, bagus_ds_icon_groups() ) ? $group : 'follow';
	$html  = get_transient( 'bagus_icons_' . $group );
	if ( false !== $html ) {
		return $html;
	}
	$posts = get_posts(
		array(
			'post_type'        => BAGUS_ICON_PT,
			'post_status'      => 'publish',
			'numberposts'      => 50,
			'orderby'          => array( 'menu_order' => 'ASC', 'title' => 'ASC' ),
			'meta_key'         => '_bagus_icon_group',
			'meta_value'       => $group,
			'no_found_rows'    => true,
			'suppress_filters' => false,
		)
	);
	$size  = (int) bagus_ds_settings()['icon_size'];
	$items = '';
	foreach ( $posts as $p ) {
		$src = bagus_ds_icon_src( $p->ID );
		if ( ! $src ) {
			continue;
		}
		$name = get_the_title( $p );
		$img  = sprintf( '<img src="%s" width="%d" height="%d" alt="%s" loading="lazy" decoding="async">', esc_url( $src ), $size, $size, esc_attr( $name ) );
		$url  = get_post_meta( $p->ID, '_bagus_icon_url', true );
		if ( $url && '#' !== $url ) {
			$tab   = '0' !== get_post_meta( $p->ID, '_bagus_icon_newtab', true );
			$item  = sprintf( '<a href="%s"%s aria-label="%s">%s</a>', esc_url( $url ), $tab ? ' target="_blank" rel="noopener"' : '', esc_attr( $name ), $img );
		} else {
			$item = '<span>' . $img . '</span>';
		}
		$items .= '<li>' . $item . '</li>';
	}
	$html = $items ? sprintf( '<ul class="bagus-icons bagus-icons--%1$s" style="--bagus-icon-size:%2$dpx" aria-label="%3$s">%4$s</ul>', esc_attr( $group ), $size, esc_attr( bagus_ds_icon_groups()[ $group ] ), $items ) : '';
	set_transient( 'bagus_icons_' . $group, $html, DAY_IN_SECONDS );
	return $html;
}

function bagus_ds_icons_shortcode( $atts ) {
	$atts = shortcode_atts( array( 'group' => 'follow' ), $atts, 'bagus_icons' );
	return bagus_ds_icons_html( sanitize_key( $atts['group'] ) );
}
add_action( 'init', function () {
	add_shortcode( 'bagus_icons', 'bagus_ds_icons_shortcode' );
} );

/* ---------- one-click import of the icons that are on the site today ---------- */
add_action( 'admin_post_bagus_ds_import_icons', 'bagus_ds_import_icons_handler' );
function bagus_ds_import_icons_handler() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed.' );
	}
	check_admin_referer( 'bagus_ds_import_icons' );
	$site = bagus_ds_current_site();
	$seed = $site ? json_decode( bagus_ds_file( 'seed/' . $site . '.json' ), true ) : null;
	$done = 0;
	$skip = 0;
	if ( is_array( $seed ) ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		$existing = get_posts( array( 'post_type' => BAGUS_ICON_PT, 'post_status' => 'any', 'numberposts' => 200, 'fields' => 'ids' ) );
		$have     = array();
		foreach ( $existing as $id ) {
			$have[ get_post_meta( $id, '_bagus_icon_group', true ) . '|' . strtolower( get_the_title( $id ) ) ] = true;
		}
		foreach ( $seed as $row ) {
			$key = $row['group'] . '|' . strtolower( $row['title'] );
			if ( isset( $have[ $key ] ) ) { // never duplicates: running the import twice is safe
				$skip++;
				continue;
			}
			$id = wp_insert_post(
				array(
					'post_type'   => BAGUS_ICON_PT,
					'post_status' => 'publish',
					'post_title'  => sanitize_text_field( $row['title'] ),
					'menu_order'  => (int) $row['order'],
				),
				true
			);
			if ( is_wp_error( $id ) ) {
				continue;
			}
			update_post_meta( $id, '_bagus_icon_group', 'review' === $row['group'] ? 'review' : 'follow' );
			update_post_meta( $id, '_bagus_icon_url', esc_url_raw( $row['url'] ) );
			update_post_meta( $id, '_bagus_icon_newtab', '1' );
			update_post_meta( $id, '_bagus_icon_image', esc_url_raw( $row['image'] ) );
			// re-use the image if it is already in this site's Media Library, otherwise copy it in
			$att = attachment_url_to_postid( preg_replace( '/-\d+x\d+(?=\.\w+$)/', '', $row['image'] ) );
			if ( ! $att ) {
				$att = media_sideload_image( $row['image'], $id, $row['title'], 'id' );
			}
			if ( $att && ! is_wp_error( $att ) ) {
				set_post_thumbnail( $id, (int) $att );
			}
			$done++;
		}
		bagus_ds_icons_flush();
	}
	wp_safe_redirect( add_query_arg( array( 'page' => 'bagus-ds', 'bagus_imported' => $done, 'bagus_skipped' => $skip ), admin_url( 'options-general.php' ) ) );
	if ( ! defined( 'BAGUS_DS_TESTING' ) ) {
		exit;
	}
}

/* settings-page block (called from bagus_ds_settings_page) */
function bagus_ds_icons_admin_block() {
	$count = (int) ( wp_count_posts( BAGUS_ICON_PT )->publish ?? 0 );
	if ( isset( $_GET['bagus_imported'] ) ) {
		printf( '<div class="notice notice-success"><p>Imported %d icon(s); %d already existed.</p></div>', (int) $_GET['bagus_imported'], (int) ( $_GET['bagus_skipped'] ?? 0 ) );
	}
	?>
	<h2>Footer icons (Review Us / Follow Us)</h2>
	<p><?php echo esc_html( $count ); ?> icon(s) published. Manage them under <a href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . BAGUS_ICON_PT ) ); ?>">Footer Icons</a>.</p>
	<ol>
		<li>Click <strong>Import current icons</strong> once: it adds the icons now shown in the footer (safe to run again; nothing is duplicated).</li>
		<li>In Elementor, open the Footer template and replace the icon widgets under the headings with a <strong>Shortcode</strong> widget:
			<code>[bagus_icons group="review"]</code> and <code>[bagus_icons group="follow"]</code>.</li>
		<li>Fill in the links marked "⚠ no link yet" in the Footer Icons list.</li>
	</ol>
	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="bagus_ds_import_icons">
		<?php wp_nonce_field( 'bagus_ds_import_icons' ); ?>
		<?php submit_button( 'Import current icons', 'secondary', 'submit', false ); ?>
	</form>
	<?php
}
