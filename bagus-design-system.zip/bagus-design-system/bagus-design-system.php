<?php
/**
 * Plugin Name:       Bagus Design System
 * Description:       Shared typography, spacing, hero, button, footer and Special Offers standard for the five Bagus Group websites, on light mode. Fonts, colours and content stay as each site has them.
 * Version:           3.8.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Bagus Group
 * License:           GPL-2.0-or-later
 * Text Domain:       bagus-ds
 */

defined( 'ABSPATH' ) || exit;

define( 'BAGUS_DS_VERSION', '3.8.0' );
define( 'BAGUS_DS_DIR', plugin_dir_path( __FILE__ ) );
define( 'BAGUS_DS_URL', plugin_dir_url( __FILE__ ) );
define( 'BAGUS_DS_FILE', __FILE__ );

require_once BAGUS_DS_DIR . 'includes/footer-icons.php';
require_once BAGUS_DS_DIR . 'includes/updater.php';

/**
 * Site registry: host => folder in /sites. The Elementor kit id is a second way
 * to recognise the site (staging copies on another domain still match).
 */
function bagus_ds_sites() {
	return array(
		'bagusjati.com'          => array( 'slug' => 'bagusjati',          'kit' => 4804 ),
		'bagusagropelaga.com'    => array( 'slug' => 'bagusagropelaga',    'kit' => 5079 ),
		'puribaguscandidasa.com' => array( 'slug' => 'puribaguscandidasa', 'kit' => 8175 ),
		'puribaguslovina.com'    => array( 'slug' => 'puribaguslovina',    'kit' => 1494 ),
		'puribagusmanggis.com'   => array( 'slug' => 'puribagusmanggis',   'kit' => 1399 ),
	);
}

/** Which Bagus site is this? Settings override > domain > Elementor kit. */
function bagus_ds_current_site() {
	static $slug = null;
	if ( null !== $slug ) {
		return $slug;
	}
	$sites    = bagus_ds_sites();
	$override = get_option( 'bagus_ds_site', '' );
	foreach ( $sites as $site ) {
		if ( $override === $site['slug'] ) {
			return $slug = $site['slug'];
		}
	}
	$host = strtolower( (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
	$host = preg_replace( '/^www\./', '', $host );
	if ( isset( $sites[ $host ] ) ) {
		return $slug = $sites[ $host ]['slug'];
	}
	$kit = (int) get_option( 'elementor_active_kit', 0 );
	foreach ( $sites as $site ) {
		if ( $kit && $kit === $site['kit'] ) {
			return $slug = $site['slug'];
		}
	}
	return $slug = '';
}

function bagus_ds_settings() {
	return wp_parse_args(
		(array) get_option( 'bagus_ds_settings', array() ),
		array(
			'fonts'        => 1,       // load Cinzel + Montserrat from Google Fonts
			'icon_size'    => 36,      // Review Us / Follow Us icon size in px (current Follow Us size)
			'auto_update'  => 1,       // install new versions automatically
			'motion'       => 1,       // light motion (fade-up, slider dots, scroll progress)
		)
	);
}

/** Read a bundled file (CSS/JSON) safely. */
function bagus_ds_file( $relative ) {
	$path = BAGUS_DS_DIR . ltrim( $relative, '/' );
	return is_readable( $path ) ? (string) file_get_contents( $path ) : '';
}

/* -------------------------------------------------------------------------
 * Front-end assets
 * ---------------------------------------------------------------------- */
add_action( 'wp_enqueue_scripts', 'bagus_ds_enqueue', 20 );
function bagus_ds_enqueue() {
	$site = bagus_ds_current_site();
	if ( ! $site || is_admin() ) {
		return;
	}
	$opt = bagus_ds_settings();

	if ( $opt['fonts'] ) {
		wp_enqueue_style( 'bagus-ds-fonts', 'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;500;600&family=Montserrat:wght@400;500&display=swap', array(), null );
	}
	// core (shared) + site stylesheet, loaded after Elementor so they win without extra specificity
	$deps = wp_style_is( 'elementor-frontend', 'registered' ) ? array( 'elementor-frontend' ) : array();
	wp_enqueue_style( 'bagus-ds-core', BAGUS_DS_URL . 'assets/core.min.css', $deps, BAGUS_DS_VERSION );
	wp_enqueue_style( 'bagus-ds-site', BAGUS_DS_URL . 'sites/' . $site . '/site.min.css', array( 'bagus-ds-core' ), BAGUS_DS_VERSION );

	// per-page rules (spacing, typography, hero, layout fixes): only the current page's file is printed
	$page_css = bagus_ds_page_css( $site );
	if ( '' !== $page_css ) {
		wp_add_inline_style( 'bagus-ds-site', $page_css );
	}

	// "Read More" buttons on the Special Offers page
	$offers = json_decode( bagus_ds_file( 'sites/' . $site . '/offers.json' ), true );
	if ( is_array( $offers ) && ! empty( $offers['page'] ) && bagus_ds_is_page_class( $offers['page'] ) ) {
		wp_enqueue_script( 'bagus-ds-offers', BAGUS_DS_URL . 'assets/offers.min.js', array(), BAGUS_DS_VERSION, true );
		wp_add_inline_script( 'bagus-ds-offers', 'window.BagusOffers=' . wp_json_encode( $offers['links'] ) . ';', 'before' );
	}

	// light motion: entrance fade-up, slider dots, scroll progress, banner scroll cue (≈2 KB, loaded in the footer)
	if ( $opt['motion'] ) {
		wp_enqueue_script( 'bagus-ds-motion', BAGUS_DS_URL . 'assets/motion.min.js', array(), BAGUS_DS_VERSION, true );
	}
}

/** body class of the current singular page, e.g. "page-id-7308". */
function bagus_ds_page_class() {
	$id = get_queried_object_id();
	if ( ! $id ) {
		return '';
	}
	return ( is_page() ? 'page-id-' : 'postid-' ) . $id;
}

function bagus_ds_is_page_class( $class ) {
	return $class === bagus_ds_page_class();
}

function bagus_ds_page_css( $site ) {
	$class = bagus_ds_page_class();
	if ( ! $class || ! preg_match( '/^(page-id|postid)-\d+$/', $class ) ) {
		return '';
	}
	return bagus_ds_file( 'sites/' . $site . '/pages/' . $class . '.css' );
}

/* Fonts preconnect + light mode only: the old dark modes of Bagus Jati / Puri Bagus Manggis are switched off
   (saved choices cleared, light attributes forced) so no visitor stays stuck in dark mode. */
add_action( 'wp_head', 'bagus_ds_head', 1 );
function bagus_ds_head() {
	if ( ! bagus_ds_current_site() ) {
		return;
	}
	echo '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' . "\n";
	echo "<script id=\"bagus-ds-light\">(function(d){try{['bagus-theme','bj-theme-preference','pbm-site-theme'].forEach(function(k){localStorage.removeItem(k);});}catch(e){}"
		. "function L(){var r=d.documentElement;r.setAttribute('data-bj-theme','light');r.removeAttribute('data-bagus-theme');r.classList.remove('pbm-dark');}"
		. "L();d.addEventListener('DOMContentLoaded',L);window.addEventListener('load',L);})(document);</script>\n";
}

/* -------------------------------------------------------------------------
 * Settings (Settings → Bagus Design System)
 * ---------------------------------------------------------------------- */
add_action( 'admin_menu', function () {
	add_options_page( 'Bagus Design System', 'Bagus Design System', 'manage_options', 'bagus-ds', 'bagus_ds_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'bagus_ds', 'bagus_ds_site', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_key', 'default' => '' ) );
	register_setting( 'bagus_ds', 'bagus_ds_settings', array( 'type' => 'array', 'sanitize_callback' => 'bagus_ds_sanitize', 'default' => array() ) );
} );

function bagus_ds_sanitize( $in ) {
	$in = (array) $in;
	return array(
		'fonts'        => empty( $in['fonts'] ) ? 0 : 1,
		'icon_size'    => max( 20, min( 80, (int) ( $in['icon_size'] ?? 36 ) ) ),
		'auto_update'  => empty( $in['auto_update'] ) ? 0 : 1,
		'motion'       => empty( $in['motion'] ) ? 0 : 1,
	);
}

function bagus_ds_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$opt      = bagus_ds_settings();
	$detected = bagus_ds_current_site();
	$override = get_option( 'bagus_ds_site', '' );
	?>
	<div class="wrap">
		<h1>Bagus Design System <small style="font-weight:400">v<?php echo esc_html( BAGUS_DS_VERSION ); ?></small></h1>
		<p><?php echo $detected ? 'Site detected: <strong>' . esc_html( $detected ) . '</strong>' : '<strong style="color:#b32d2e">No Bagus site detected — choose one below.</strong>'; ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'bagus_ds' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="bagus_ds_site">Site</label></th><td>
					<select id="bagus_ds_site" name="bagus_ds_site">
						<option value="">Automatic (by domain)</option>
						<?php foreach ( bagus_ds_sites() as $host => $site ) : ?>
							<option value="<?php echo esc_attr( $site['slug'] ); ?>" <?php selected( $override, $site['slug'] ); ?>><?php echo esc_html( $host ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description">Only needed on staging or another domain.</p>
				</td></tr>
				<tr><th scope="row"><label for="bagus_icon_size">Footer icon size</label></th><td><input type="number" id="bagus_icon_size" min="20" max="80" name="bagus_ds_settings[icon_size]" value="<?php echo esc_attr( $opt['icon_size'] ); ?>" class="small-text"> px <p class="description">Same size for every Review Us and Follow Us icon.</p></td></tr>
				<tr><th scope="row">Automatic updates</th><td><label><input type="checkbox" name="bagus_ds_settings[auto_update]" value="1" <?php checked( $opt['auto_update'], 1 ); ?>> Install new Bagus Design System versions automatically</label></td></tr>
				<tr><th scope="row">Motion</th><td><label><input type="checkbox" name="bagus_ds_settings[motion]" value="1" <?php checked( $opt['motion'], 1 ); ?>> Light motion: content fades in on scroll, slider dots, scroll progress bar, scroll cue on banners (off automatically for visitors who prefer reduced motion)</label></td></tr>
				<tr><th scope="row">Fonts</th><td><label><input type="checkbox" name="bagus_ds_settings[fonts]" value="1" <?php checked( $opt['fonts'], 1 ); ?>> Load Cinzel &amp; Montserrat (turn off only if another plugin already loads them)</label></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
		<?php bagus_ds_updater_admin_block(); ?>
		<?php bagus_ds_icons_admin_block(); ?>
		<h2>After activating</h2>
		<ol>
			<li>Remove the old "Bagus" CSS from Appearance → Customize → Additional CSS.</li>
			<li>Remove the old Special Offers "Read More" script from Elementor → Custom Code (the plugin adds it now).</li>
			<li>Elementor → Tools → Regenerate CSS &amp; Data, then clear the cache plugin / CDN.</li>
		</ol>
	</div>
	<?php
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=bagus-ds' ) ) . '">Settings</a>' );
	return $links;
} );
