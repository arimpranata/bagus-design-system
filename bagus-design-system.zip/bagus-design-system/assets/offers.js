/* Bagus Design System — adds "Read More" to Special Offers cards. Links come from sites/<site>/offers.json. */
(function () {
  var MAP = window.BagusOffers || {};
  function key(t) { return (t || '').toUpperCase().replace(/[^A-Z0-9]+/g, ' ').trim(); }
  function link(slug, cls) {
    var a = document.createElement('a');
    a.href = location.origin + '/' + slug + '/';
    a.className = cls + ' bagus-readmore';
    a.textContent = 'Read More';
    return a;
  }
  function add(scope, titleSel, rowSel, cls) {
    document.querySelectorAll(scope).forEach(function (card) {
      var t = card.querySelector(titleSel), row = card.querySelector(rowSel);
      if (!t || !row || row.querySelector('.bagus-readmore')) return;
      var slug = MAP[key(t.textContent)];
      if (slug) row.appendChild(link(slug, cls));
    });
  }
  function run() {
    add('.uc_long_content_box', '.uc_title', '.uc_hidden_content', 'uc_btn');
    add('.pp-image-accordion-item', '.pp-image-accordion-title', '.pp-image-accordion-button-wrap', 'pp-image-accordion-button elementor-button elementor-size-sm');
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run); else run();
})();
